import SwiftUI
import AppKit
import Foundation
import Darwin

struct Tool: Identifiable {
    let id: String
    let title: String
    let category: String
    let detail: String
    let script: String
    let arguments: [String]
    let terminal: Bool
}
let catalog: [Tool] = [
    Tool(id: "ios-module", title: "Soporte experto iPhone / iPad", category: "iPhone / iPad", detail: "Panel iOS/iPadOS: conexión, inventario USB/Configurator, respaldo, recuperación, mantenimiento y expediente técnico.", script: "ios.sh", arguments: ["inventory"], terminal: false),
    Tool(id: "remotedisk", title: "Leer disco de otra Mac", category: "Recuperación", detail: "Compartir disco (Apple Silicon), disco de destino (Intel), unidades externas, inventario y copia de documentos. DFU no permite leer archivos.", script: "RemoteDisk.command", arguments: [], terminal: true),
    Tool(id: "cases", title: "Diagnóstico y expedientes", category: "Expedientes", detail: "Síntomas, capturas antes/después, estados estructurados, notas, comparación e informe PDF. Las capturas miden esta Mac.", script: "CaseAssistant.command", arguments: [], terminal: true),
    Tool(id: "recoveryassistant", title: "Revivir MacBook — asistente", category: "Recuperación", detail: "Triage de alimentación, firmware y sistema. Guía DFU con Finder, Revive primero y reinstalación desde Recovery sin borrar. No repara averías físicas.", script: "RecoveryAssistant.command", arguments: [], terminal: true),
    Tool(id: "diag", title: "Diagnóstico hardware", category: "Diagnóstico", detail: "Batería, almacenamiento, chip y datos térmicos disponibles de esta Mac.", script: "diagnose.sh", arguments: [], terminal: false),
    Tool(id: "all", title: "Informe TI completo", category: "Diagnóstico", detail: "Inventario, red local, seguridad, rendimiento, registros e impresoras. Puede tardar varios minutos.", script: "it.sh", arguments: ["all"], terminal: false),
    Tool(id: "inventory", title: "Inventario y aplicaciones", category: "Diagnóstico", detail: "Hardware, periféricos, aplicaciones, paquetes y usuarios locales.", script: "it.sh", arguments: ["inventory"], terminal: false),
    Tool(id: "performance", title: "Rendimiento", category: "Diagnóstico", detail: "Muestra de CPU, memoria, swap, espacio y estado térmico.", script: "it.sh", arguments: ["performance"], terminal: false),
    Tool(id: "network", title: "Red y conectividad", category: "Red", detail: "Interfaces, DNS, proxy, ruta y puertos locales en escucha. Host opcional para DNS/ping; sin escaneo de subredes.", script: "it.sh", arguments: ["network"], terminal: false),
    Tool(id: "printers", title: "Impresoras", category: "Red", detail: "Colas, trabajos y configuración de impresoras; no cancela trabajos.", script: "it.sh", arguments: ["printers"], terminal: false),
    Tool(id: "security", title: "Postura de seguridad", category: "Seguridad", detail: "FileVault, SIP, Gatekeeper, firewall y estado de inscripción MDM. No modifica protecciones.", script: "it.sh", arguments: ["security"], terminal: false),
    Tool(id: "hash", title: "SHA-256 de archivo", category: "Seguridad", detail: "Calcular y comparar con un hash esperado opcional de una fuente confiable.", script: "check-file.sh", arguments: [], terminal: false),
    Tool(id: "signature", title: "Firma de una aplicación", category: "Seguridad", detail: "Validar firma y evaluación Gatekeeper. No sustituye un análisis antimalware.", script: "signature.sh", arguments: [], terminal: false),
    Tool(id: "services", title: "Servicios y agentes", category: "Soporte", detail: "Inventario de agentes y archivos de servicios, sin detenerlos.", script: "it.sh", arguments: ["services"], terminal: false),
    Tool(id: "logs", title: "Errores y registros", category: "Soporte", detail: "Errores de los últimos cinco minutos y listado de informes de fallos. Puede contener información privada.", script: "it.sh", arguments: ["logs"], terminal: false),
    Tool(id: "updates", title: "Actualizaciones disponibles", category: "Soporte", detail: "Consulta softwareupdate; necesita Internet y puede actualizar metadatos. No instala actualizaciones.", script: "it.sh", arguments: ["updates"], terminal: false),
    Tool(id: "backupstatus", title: "Estado de respaldos", category: "Respaldo", detail: "Estado y destinos de Time Machine e inventario APFS.", script: "it.sh", arguments: ["backup-status"], terminal: false),
    Tool(id: "backup", title: "Copiar documentos", category: "Respaldo", detail: "Copia a una carpeta nueva sin borrar el destino. Cierre aplicaciones y verifique restauración.", script: "BackupFiles.command", arguments: [], terminal: true),
    Tool(id: "cache", title: "Caché de una aplicación", category: "Mantenimiento", detail: "Mueve una caché del usuario a cuarentena, tras cerrar la aplicación.", script: "CacheUser.command", arguments: [], terminal: true),
    Tool(id: "verify", title: "Verificar volumen APFS", category: "Mantenimiento", detail: "Seleccionar volumen en Terminal y ejecutar verifyVolume.", script: "APFSVerify.command", arguments: [], terminal: true),
    Tool(id: "repair", title: "Reparación APFS", category: "Mantenimiento", detail: "Flujo de Terminal para Recovery. Esta GUI no funciona en todos los entornos Recovery; allí utilice los scripts o Disk Utility.", script: "APFSRepair.command", arguments: [], terminal: true),
    Tool(id: "erase", title: "Formatear disco externo", category: "Avanzado", detail: "Destruye todas las particiones del objetivo. Verificación de identidad y confirmación en Terminal.", script: "EraseExternal.command", arguments: [], terminal: true),
    Tool(id: "reset", title: "Full Factory Reset — ESTA Mac", category: "Avanzado", detail: "Pre-check de elegibilidad y apertura del Erase Assistant oficial. BORRA todos los datos sólo después de confirmación y autenticación de Apple. No automatiza diskutil sobre el disco interno.", script: "FactoryReset.command", arguments: [], terminal: true),
    Tool(id: "externaldetect", title: "Auto-detectar USB / Thunderbolt / DFU", category: "DFU", detail: "Monitor de sólo lectura durante dos minutos. Detecta cambios USB/Thunderbolt/USB4 y candidatos Apple DFU/Recovery sin modificar el dispositivo.", script: "external-device-detect.sh", arguments: ["watch"], terminal: false),
    Tool(id: "externalscan", title: "Escanear dispositivos externos ahora", category: "DFU", detail: "Inventario inmediato y de sólo lectura de USB, Thunderbolt/USB4, Configurator y candidatos DFU/Recovery.", script: "external-device-detect.sh", arguments: ["scan"], terminal: false),
    Tool(id: "dfuentry", title: "Entrar / reiniciar en modo DFU", category: "DFU", detail: "Asistente guiado para Mac, iPhone y iPad. DFU requiere una secuencia física específica; este botón abre la guía y herramientas oficiales, pero no fuerza DFU ni borra el dispositivo.", script: "DFUEntryAssistant.command", arguments: [], terminal: true),
    Tool(id: "dfuinventory", title: "Inventario Configurator", category: "DFU", detail: "Requiere Apple Configurator Automation Tools instaladas en esta Mac.", script: "DFUInventory.command", arguments: [], terminal: true),
    Tool(id: "revive", title: "Revive — objetivo DFU", category: "DFU", detail: "Adaptador experimental cfgutil. Validar versión, modelo y ECID antes de continuar.", script: "DFURevive.command", arguments: [], terminal: true),
    Tool(id: "restore", title: "Restore — objetivo DFU", category: "DFU", detail: "BORRA la Mac objetivo. Adaptador cfgutil pendiente de validación; alternativa oficial Finder.", script: "DFURestore.command", arguments: [], terminal: true)
]

final class Runner: ObservableObject {
    @Published var externalJob = false
    @Published var terminalOpening = false
    var jobInProgress: Bool { busy || externalJob || terminalOpening || FileManager.default.fileExists(atPath: "/tmp/mactech-job-\(getuid())") }
    private var jobMonitor: Timer?
    @Published var busy = false
    @Published var output = "Seleccione una herramienta y un destino para los informes.\n"
    @Published var reportFolder: URL?
    @Published var latestReport: URL?
    @Published var selectedFile: URL?
    @Published var notice = ""
    private var pendingOutputLine = ""
    let root: URL
    init() {
        root = Bundle.main.resourceURL!.appendingPathComponent("toolkit", isDirectory: true)
        let base = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            .appendingPathComponent("MacTech IT Reports", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        reportFolder = base
        jobMonitor = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            self?.externalJob = FileManager.default.fileExists(atPath: "/tmp/mactech-job-\(getuid())")
        }
    }
    func chooseReports() {
        let panel = NSOpenPanel(); panel.canChooseDirectories = true
        panel.canChooseFiles = false; panel.canCreateDirectories = true
        panel.prompt = "Guardar informes aquí"
        if panel.runModal() == .OK { reportFolder = panel.url }
    }
    func chooseFile(app: Bool) {
        let panel = NSOpenPanel(); panel.canChooseDirectories = app
        panel.canChooseFiles = !app; panel.treatsFilePackagesAsDirectories = false
        if panel.runModal() == .OK { selectedFile = panel.url }
    }
    func append(_ value: String) {
        output += value
        // Process puede dividir una línea en varias lecturas del pipe.
        pendingOutputLine += value
        while let newline = pendingOutputLine.firstIndex(of: "\n") {
            let line = String(pendingOutputLine[..<newline])
            pendingOutputLine.removeSubrange(...newline)
            for prefix in ["Informe: ", "Informe guardado: "] where line.hasPrefix(prefix) {
                let path = String(line.dropFirst(prefix.count))
                if path.hasPrefix("/"), FileManager.default.fileExists(atPath: path) {
                    latestReport = URL(fileURLWithPath: path)
                }
            }
        }
        if pendingOutputLine.count > 150_000 { pendingOutputLine = "" }
        if output.count > 150_000 { output = "[Salida anterior recortada; revisar informes]\n" + String(output.suffix(120_000)) }
    }
    func run(_ tool: Tool, host: String, expectedHash: String) {
        guard !jobInProgress else { notice = "Un trabajo GUI/Terminal mantiene el bloqueo. Espere; no se elimina automáticamente."; return }
        if tool.terminal {
            let path = root.appendingPathComponent("launchers/" + tool.script)
            guard FileManager.default.fileExists(atPath: path.path) else { notice = "Falta launcher."; return }
            // Launchers fijos. Los argumentos se introducen en Terminal, nunca en AppleScript.
            terminalOpening = true
            NSWorkspace.shared.open(path)
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { self.terminalOpening = false }
            notice = "Flujo abierto en Terminal. Complete allí las confirmaciones. No ejecute otros trabajos simultáneos."
            return
        }
        guard let reports = reportFolder else { notice = "Seleccione primero una carpeta de informes."; return }
        var arguments = tool.arguments
        if tool.id == "network", !host.isEmpty {
            guard validSnippetParameter(host, kind: "host") else { notice = "Destino DNS/IPv4 inválido."; return }
            arguments.append(host)
        }
        if tool.id == "hash" || tool.id == "signature" {
            guard let file = selectedFile else { notice = "Seleccione un archivo o una aplicación."; return }
            arguments.append(file.path)
            if tool.id == "hash", !expectedHash.isEmpty { arguments.append(expectedHash) }
        }
        let script = root.appendingPathComponent("scripts/" + tool.script)
        let workingRoot = root
        latestReport = nil; pendingOutputLine = ""
        busy = true; notice = "Ejecutando en ESTA Mac"; output = "Iniciando \(tool.title)…\n"
        DispatchQueue.global(qos: .userInitiated).async {
            let task = Process(); let pipe = Pipe()
            task.executableURL = URL(fileURLWithPath: "/bin/bash")
            task.arguments = [script.path] + arguments
            task.currentDirectoryURL = workingRoot
            var environment = ProcessInfo.processInfo.environment
            environment["MACTECH_REPORTS"] = reports.path
            task.environment = environment
            task.standardOutput = pipe; task.standardError = pipe
            task.standardInput = FileHandle.nullDevice
            do {
                try task.run()
                // Lectura fuera del hilo de UI, drenando el pipe para evitar bloqueo.
                while true {
                    let data = pipe.fileHandleForReading.availableData
                    if data.isEmpty { break }
                    let chunk = String(decoding: data, as: UTF8.self)
                    DispatchQueue.main.async { self.append(chunk) }
                }
                task.waitUntilExit()
                let code = task.terminationStatus
                DispatchQueue.main.async {
                    self.busy = false
                    self.notice = "Finalizado: código \(code). Revise los estados de cada proveedor."
                }
            } catch {
                DispatchQueue.main.async {
                    self.busy = false; self.notice = error.localizedDescription
                }
            }
        }
    }
}

struct ContentView: View {
    @ObservedObject var runner: Runner
    @State private var selected: String? = "diag"
    @State private var host = ""
    @State private var expectedHash = ""
    @State private var showSnippets = false
    @State private var showMacBook = false
    @State private var showIOS = false
    @State private var showExpert = false
    private var tool: Tool { catalog.first(where: { $0.id == selected }) ?? catalog[0] }
    var body: some View {
        HSplitView {
            List(selection: $selected) {
                ForEach(["iPhone / iPad", "Expedientes", "Diagnóstico", "Red", "Seguridad", "Soporte", "Respaldo", "Mantenimiento", "Recuperación", "DFU", "Avanzado"], id: \.self) { category in
                    Section(header: Text(category)) {
                        ForEach(catalog.filter { $0.category == category }) { item in
                            Text(item.title).tag(item.id)
                        }
                    }
                }
            }.frame(minWidth: 230, idealWidth: 270, maxWidth: 330)
            VStack(alignment: .leading, spacing: 14) {
                Group {
                    HStack {
                        Text("MacTech IT").font(.largeTitle.bold())
                        Spacer()
                        Button("Centro TI") { showExpert = true }
                        Button("iPhone / iPad") { showIOS = true }
                        Button("Macbook") { showMacBook = true }
                        Button("Snippets TI") { showSnippets = true }
                    }
                    Text("Host: ESTA Mac · Firmware: equipo objetivo conectado").foregroundColor(.secondary)
                    Divider()
                    Text(tool.title).font(.title2.bold())
                    Text(tool.detail).fixedSize(horizontal: false, vertical: true)
                    if tool.id == "network" {
                        TextField("Host DNS o IPv4 opcional — un único destino autorizado", text: $host)
                    }
                }
                if tool.id == "hash" || tool.id == "signature" {
                    Button(tool.id == "signature" ? "Seleccionar .app" : "Seleccionar archivo") { runner.chooseFile(app: tool.id == "signature") }
                    Text(runner.selectedFile?.path ?? "Sin selección").font(.caption)
                    if tool.id == "hash" { TextField("SHA-256 esperado opcional", text: $expectedHash) }
                }
                HStack {
                    Button("Destino de informes") { runner.chooseReports() }.disabled(runner.jobInProgress)
                    Button("Abrir informes") {
                        if let url = runner.reportFolder { NSWorkspace.shared.open(url) }
                    }.disabled(runner.reportFolder == nil)
                    Button("Abrir último resultado") {
                        if let url = runner.latestReport { NSWorkspace.shared.open(url) }
                    }.disabled(runner.latestReport == nil)
                }
                Text(runner.reportFolder?.path ?? "Seleccione una carpeta escribible, preferiblemente en un soporte protegido.").font(.caption).foregroundColor(.secondary)
                HStack {
                    Button(tool.terminal ? "Abrir flujo en Terminal" : "Ejecutar") {
                        if tool.id == "ios-module" { showIOS = true } else {
                            runner.run(tool, host: host.trimmingCharacters(in: .whitespaces), expectedHash: expectedHash.trimmingCharacters(in: .whitespaces))
                        }
                    }.disabled(runner.jobInProgress)
                    if runner.busy { ProgressView().scaleEffect(0.7); Text("Trabajo en curso") }
                }
                Text(runner.notice).font(.caption)
                ScrollView {
                    Text(runner.output).font(.system(.caption, design: .monospaced))
                        .textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding(10)
                }.background(Color(NSColor.textBackgroundColor)).cornerRadius(8)
                Text("MacTech IT 0.11.1 · Macbook · Snippets macOS experto").font(.caption).foregroundColor(.secondary)
            }.padding(22).frame(minWidth: 620)
        }.frame(minWidth: 920, minHeight: 680)
        .sheet(isPresented: $showSnippets) { SnippetsView(root: runner.root) }
        .sheet(isPresented: $showMacBook) { MacBookSupportView(runner: runner) }
        .sheet(isPresented: $showIOS) { IOSSupportView(runner: runner) }
        .sheet(isPresented: $showExpert) { ExpertWorkbenchView(runner: runner) }
    }
}
@main
struct MacTechITApp: App {
    @StateObject private var runner = Runner()
    var body: some Scene {
        WindowGroup { ContentView(runner: runner) }
    }
}
