#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
read -r -p "Disco externo completo (diskN): " disk
read -r -p "Formato exacto [APFS o ExFAT]: " format
case "$format" in APFS|ExFAT) ;; *) echo "Formato no permitido." >&2; exit 1 ;; esac
/bin/bash "$ROOT/scripts/erase-external.sh" "$disk" "$format"
