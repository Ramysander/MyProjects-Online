# Snippets TI experto para Mac — 0.11.1

Catálogo: **82 entradas**, **72 macOS experto** y **10 iPhone / iPad**. Colección macOS con nueve categorías: inventario/batería, discos/APFS, seguridad, red/DNS, rendimiento/procesos, registros/servicios, respaldos, firma y recuperación/firmware.

## Uso
1. Abra **Snippets TI** o **Snippets macOS experto** desde Macbook.
2. Busque por título, comando, categoría o interpretación; filtre colección, categoría, riesgo y arquitectura.
3. Lea descripción, requisitos, compatibilidad, interpretación y referencia. La presencia de un ejecutable en ESTA Mac no prueba sus opciones, permisos ni disponibilidad en otra sesión Terminal.
4. Revise la plantilla completa; introduzca DNS/IPv4, diskN/diskNsM, interfaz, nombre de servicio, bundle ID o ruta absoluta según se pida. Rutas no prueban existencia ni permiso de lectura. Sin URL/puerto en destinos de red; sólo un destino autorizado.
5. Revise el **comando preparado**, copie o arrastre como texto a un prompt vacío. No contiene salto final, no pulsa Enter y no ejecuta automáticamente.
6. Confirme qué equipo ejecutará la sesión receptora. Una sesión SSH no es necesariamente el anfitrión de la app. Los wrappers usan rutas del paquete local, no rutas transferidas a un host remoto.
7. En su Mac de laboratorio contraste cada opción con `man`/ayuda local. Un comando que falla o no publica datos no permite concluir que el equipo está sano.

## Parámetros y riesgo
Controles/saltos se rechazan. DNS valida etiquetas y IPv4 valida octetos; discos/interfaces usan patrones cerrados. Los servicios permiten nombres con espacios y rechazan opciones que empiecen por guion. Rutas se citan como un argumento shell escapando apóstrofes. Marcadores introducidos como parte del parámetro no se reexpanden. No use contraseñas, PIN, claves ni tokens.

Lectura consulta datos; puede mostrar seriales, rutas, nombres de usuario o generar tráfico de red. Supervisado incluye verificaciones y guías; abrir una guía no completa un respaldo ni recuperación. Modifica/Destructivo están ocultos hasta habilitar avanzados; requieren reconocimiento del objetivo y los wrappers conservan confirmaciones. Cambiar el parámetro reinicia ese reconocimiento. No hay borrado directo del arranque, bucles ilimitados de reparación ni bypass de FileVault/Activation Lock/SIP/Apple.

El catálogo empaquetado es código confiable, no configuración externa inocua. La validación rechaza IDs duplicados, tipos/riesgos no admitidos, marcadores inválidos y acciones Modifica/Destructivo sin wrappers del catálogo protegido. No trata un catálogo alterado como una fuente segura por defecto.

## Compatibilidad y documentación
Baseline macOS 12, Intel/Apple silicon, con diferencias de modelo, permisos y macOS. `system_profiler`, `sysctl`, `ioreg`, `diskutil`, `pmset`, `networksetup`, `scutil`, `vm_stat`, `tmutil`, `codesign`, `spctl` y `log` son proveedores nativos. `sysctl hw.machine`/el contexto del proceso pueden diferir bajo Rosetta: confirme chip/modelo con system_profiler. `codesign -dv` escribe metadatos en stderr y no verifica firma; use la consulta de verificación. `spctl --assess` depende de política/versión, no es análisis antimalware. Snapshots y respaldos listados no acreditan restaurabilidad.

Manuales locales a contrastar: `man system_profiler`, `man sysctl`, `man ioreg`, `man diskutil`, `man pmset`, `man networksetup`, `man scutil`, `man vm_stat`, `man tmutil`, `man codesign`, `man spctl`, `man log`, `man netstat` y `man ifconfig`. Este entorno Linux no dispone de ellos ni puede certificar disponibilidad/opciones nativas del Mac del usuario. La descarga de documentación Apple en vivo recibió 403; las referencias se incluyen sin afirmar haberlas consultado en esta revisión.

Referencias:
- Manuales en Terminal: https://support.apple.com/guide/terminal/reading-unix-manual-pages-trml1022/mac
- Arrastrar a Terminal: https://support.apple.com/guide/terminal/drag-items-into-a-terminal-window-trml106/mac
- Revive/Restore de Mac Apple silicon/T2: https://support.apple.com/108900
- NSItemProvider: https://developer.apple.com/documentation/foundation/nsitemprovider

Firmware: Intel sin T2 no tiene este flujo DFU; Apple silicon/T2 requiere secuencia física, cable/puerto y host compatible. Finder requiere macOS 14+ en el host. Revive primero; Restore borra y se confirma en la herramienta oficial. Los snippets de firmware abren guías/launchers, no prometen recuperación automática.

## Pruebas
`python3 tools/check_source.py` y `python3 tools/check_macbook_catalog.py` sólo inspeccionan catálogo/fuentes, preparan comandos para `bash -n` y comprueban argumentos sintéticos mediante printf. No ejecutan snippets. `tools/check_swift_structure.py` es inspección opcional con tree-sitter 0.25.2/tree-sitter-swift 0.7.4, no compilación.

En macOS, el build compila los core compartidos y `caseengine selftest docs/snippets.json` prueba tipos/quoting/IDs/ámbitos/wrappers con fixtures y el catálogo real, sin operaciones de dispositivos. Compilación/Swift selftests/clipboard/arrastre real aún pendientes en esta entrega.
