# PROJECT_STATUS — MacTech IT 0.11.1

## Current scope
MacTech IT 0.11.0 adds the Macbook support panel and expert macOS snippets, reusing the Runner, supervised workflows and case engine. This source revision is not yet compiled or validated on macOS.

## Full Factory Reset
- `factory-reset-precheck.sh` is read-only and assesses macOS version, Apple silicon/T2 eligibility, Erase Assistant availability, power source, basic Internet reachability, and the macOS 26+ Repair Assistant advisory.
- The pre-check never treats backup presence as proven; the operator must verify a restorable backup.
- Eligible Apple silicon/T2 Macs on macOS 12+ are routed to Apple's Erase Assistant / Erase All Content and Settings.
- The destructive stage requires the exact interactive phrase `ERASE THIS MAC`, then opens Apple's Erase Assistant. Apple retains administrator/Apple Account authentication and final confirmation.
- Unsupported Macs are stopped and directed to the official macOS Recovery + Disk Utility + Reinstall macOS workflow. MacTech IT does not automate `diskutil eraseDisk` against the startup disk.
- No destructive/device-changing workflow is used by automated validation.

## Diagnostic engine retained
- Default reports: `~/Documents/MacTech IT Reports`.
- `summary.txt` uses PASS / WARNING / FAIL / UNKNOWN / UNAVAILABLE / COLLECTED semantics.
- Security interpretation: FileVault, SIP, Gatekeeper and firewall when available.
- Hardware/performance interpretation includes battery condition and startup-volume utilization.

## Validation required on macOS
Run `/bin/bash Build_DMG.command`. It must compile universal helpers and GUI, run `caseengine selftest`, verify signatures/architectures, create/verify `MacTech_IT_v0.11.1.dmg`, and generate SHA-256. Automated validation must not invoke Factory Reset, erase, repair, restore, DFU, unmount, or other device-changing flows.

## Distribution
Ad-hoc signing is for local testing. Public distribution requires Developer ID signing, notarization, and validation on a clean Mac.


## 0.8.1 device detection
Added read-only USB/Thunderbolt/USB4 auto-detection, conservative DFU/Recovery classification, and a guided DFU-entry action for Mac/iPhone/iPad. The app does not claim to force DFU in software.

## 0.8.2 source review — 2026-10-06
- Baseline: latest 0.8.1 source, not the older 0.7.0 handoff. Read AGENTS.md and this status before editing.
- DMG filename now derives from Info.plist, avoiding hardcoded release mismatch. Expected MacTech_IT_v0.9.0.dmg. Added SDK preflight.
- Build_DMG.command pauses/opens Finder only with an interactive stdin; EOF no longer masks the actual build exit code.
- GUI report parsing buffers complete lines across pipe chunks and clears the previous report when a new job begins.
- Added tools/check_source.py for syntax, plist/version, snippet templates and source-resource references. This tool never runs operational scripts.
- PASS in Linux: Bash syntax for 42 scripts, 60 unique snippets, plist/version and build/resource references. ZIP integrity and extraction checked.
- NOT RUN: Swift compilation, caseengine selftest, code signing, universal architecture checks, DMG creation/verification or physical-device tests. This execution environment is Linux and does not have access to the owner's Mac. No real device or user-data operation performed.
- Changes require actual macOS compilation and GUI verification; static checks do not establish successful compilation.

## 0.9.0 — Centro TI experto
- Native SwiftUI panel accessible from the main app and iOS/iPadOS module.
- Manual read-only USB/Thunderbolt inventory parsed from system_profiler JSON records, never headings. Apple DFU/Recovery strings are candidates, not proof of mode or identity. Missing inventory is explicit; refresh clears stale data.
- Dependency presence checks: system_profiler, bundled macprobe/caseengine, optional cfgutil. No installation, download, or compatibility claim based on presence alone.
- Unified manual case notes for Mac/iPhone/iPad, optional dated inventory attachment, revisioned JSON/HTML export, JSON import with size/schema checks, and AppKit Print/PDF dialogue.
- Existing external-device scan classification now uses the same JSON parser. Shared core includes synthetic selftests for bus false positives, vendor gating, HTML escaping, and case serialization.
- CaseEngine uses an @main entry point for compilation with shared sources.
- Development verification: static Bash/JSON/plist/resource checks only on Linux. Swift compilation and selftests must run through Build_DMG.command on macOS. No physical-device operation executed.


## Revisión Centro TI — 2026-10-06 (fuente 0.9.0)
- Carpeta de trabajo: `/workspace/mactech-source/MacTechPortable`, extraída de `MacTechIT_v0.9.0_Expert_Workbench_Source.zip`. El archivo recibido no contiene metadatos Git; no se puede inferir un diff previo ni un commit. Se conserva la versión 0.9.0.
- Importación JSON: `NSOpenPanel.allowedContentTypes = [.json]` y selección de directorios deshabilitada; sustituye la API obsoleta indicada en BUILD_DMG_LOG.txt.
- Borradores: comparación completa con el expediente inicial, importado o guardado. Cerrar/Nuevo/Abrir sólo pide confirmación si existen cambios sin guardar, incluyendo plataforma, resultado e inventario. Guardados fallidos no marcan el borrador como guardado.
- Inventario: rechaza raíces JSON incorrectas, fuentes ausentes y listas malformadas; mantiene la diferencia entre datos no disponibles y listas válidas vacías. No modifica la clasificación conservadora DFU/Recovery.
- Añadidos fixtures sintéticos al selftest compartido para respuestas inválidas, inventario vacío y comparación de expedientes. Estos fixtures NO se ejecutaron aquí.
- PASS actual: `python3 tools/check_source.py`: sintaxis Bash de 42 scripts, 60 snippets únicos, plist/versión y referencias de recursos/build. Integridad del ZIP de entrada comprobada.
- El log de compilación aportado documenta una compilación ANTERIOR de 0.9.0 en la Mac del usuario: firma ad hoc y checksum DMG válidos. No valida los cambios de esta revisión.
- NO EJECUTADO en esta revisión: compilación Swift/GUI, `caseengine selftest`, firma, arquitecturas universales, creación/verificación de DMG y pruebas manuales de GUI. El entorno actual es Linux y no dispone de Swift ni herramientas Apple.
- Pendiente en macOS: ejecutar `/bin/bash Build_DMG.command`, revisar las confirmaciones con borradores nuevos/importados/guardados/editados, probar importación/exportación y PDF con datos sintéticos. No ejecutar scripts operativos ni pruebas sobre dispositivos reales durante la verificación.
- Distribución pública pendiente: Developer ID y notarización. No se ha generado un nuevo DMG en esta revisión.
- No se ejecutaron borrados, restauraciones, reparaciones, desmontajes, scans ni cambios sobre dispositivos o datos del usuario.


## 0.10.0 — Gestión profesional de expedientes (2026-10-06)
- Fuente de trabajo: `/workspace/mactech-source/MacTechPortable`. Versión de app 0.10.0, build 16. El ZIP original no incluye Git. Se conserva la revisión anterior y sus correcciones.
- Seguimiento: ticket, técnico responsable, prioridad y fecha objetivo opcional. Las fechas objetivo vencidas se indican en la biblioteca para resultados no resueltos; no existe notificación externa ni garantía SLA.
- Checklist: autorización, revisión de respaldo/no aplica documentado, verificación final y entrega/comunicación. Guardar como Resuelto exige identificación, síntoma, técnico, intervención, verificación posterior y checklist completo. Los expedientes antiguos pueden abrirse; para volver a guardarlos como Resuelto deben completar el cierre.
- Bitácora: entradas manuales con UUID, fecha, técnico y nota; límite de 500 entradas y 10.000 caracteres por nota. Una nota aún no añadida bloquea guardar/imprimir y activa confirmación al descartar. El historial se incluye en JSON, HTML y Print/PDF.
- Biblioteca: carga asíncrona, búsqueda por ID/ticket/equipo/técnico/síntoma/plataforma, filtro por resultado y apertura de una revisión. Conteo distingue revisiones de expedientes. No instala ni ejecuta herramientas de dispositivo.
- Lectura limitada a 500 revisiones, 32 MB de JSON y 5.000 entradas de directorio; listas parciales, archivos rechazados y errores de acceso se indican. Se omiten archivos ocultos y enlaces simbólicos internos. Orden por fecha declarada de actualización, no fecha autenticada. Actualizar manualmente después de guardar.
- Exportación CSV de revisiones filtradas; campos entrecomillados, comillas escapadas y prefijo para celdas con posible fórmula. Archivo con permisos 600 cuando el sistema los permite. Fechas de exportación ISO-8601.
- Guardado por paquete: JSON, HTML y manifiesto SHA-256 en `unified-cases/case-UUID/revision-UUID/`. Una carpeta temporal oculta `.pending-*` se renombra sólo tras completar los archivos/permisos; fallos no publican revisiones parciales y pueden dejar temporales para inspección manual.
- Integridad: importar un JSON verifica su checksum cuando existe un manifiesto adyacente; botón Verificar integridad comprueba JSON y HTML. Expedientes sin manifiesto siguen siendo importables y no se presentan como verificados. Checksum no es firma ni auditoría inmutable; quitar/modificar el manifiesto puede eludir esa protección.
- Compatibilidad: extensión `professional` opcional dentro del esquema 1; los documentos 0.9.0 sin extensión reciben valores predeterminados. Clientes antiguos pueden ignorar la extensión y perderla al volver a guardar: usar 0.10.0 para estos expedientes.
- Validación adicional: límites de campos/dispositivos, prioridades admitidas y UUID únicos en la bitácora. Guardado limita JSON a 2 MB para conservar la importabilidad.
- Añadidos selftests sintéticos: compatibilidad sin extensión, ida/vuelta de seguimiento, cierre incompleto/completo, prioridades inválidas, UUID duplicados, notas excesivas, técnico vacío, vector SHA-256 y escape CSV. NO EJECUTADOS en este entorno.
- Pendiente macOS: `/bin/bash Build_DMG.command` y comprobar GUI, bindings del seguimiento, importación 0.9.0/0.10.0, cierre incompleto/completo, bitácora sin guardar, biblioteca vacía/parcial, CSV con comillas/fórmulas, JSON/HTML modificados y manifiesto ausente, guardado fallido y PDF multipágina. Usar sólo fixtures y carpetas de prueba; sin operaciones sobre dispositivos.
- No se ejecutaron scans, borrados, restauraciones, reparaciones, desmontajes ni modificaciones de dispositivos. El registro BUILD_DMG_LOG aportado sólo valida la compilación anterior 0.9.0, no esta versión.
- PASS de esta revisión: `python3 tools/check_source.py` (42 scripts Bash, 60 snippets, versión 0.10.0 y referencias de recursos/build); análisis de gramática de `ExpertWorkbenchView.swift` y `SupportCore.swift` con tree-sitter 0.25.2 / tree-sitter-swift 0.7.4, sin nodos de error. Este análisis no resuelve tipos, APIs ni bindings y no sustituye `swiftc`.
- NO EJECUTADO: compilación Swift/GUI, selftests, firma, arquitecturas, DMG y verificación funcional de la GUI. Detalle y aceptación pendiente en `docs/VALIDATION_0.10.0.md`.


## Corrección de compilación 0.10.0 — build 17
- La salida aportada por el usuario muestra la sobrecarga de `ViewBuilder.buildBlock` limitada a diez vistas. El panel Seguimiento contenía dieciséis elementos directos en un VStack, incompatible con ese SDK.
- Separado Seguimiento en tres subviews con `@ViewBuilder`: datos del servicio (3 elementos), checklist (7) y bitácora (5). El contenedor principal tiene 4 elementos. Se conservan controles, bindings y separación visual.
- Build incrementado a 17; versión comercial conservada en 0.10.0. La revisión anterior build 16 no se considera compilable en el SDK reportado.
- Validación: comprobaciones estáticas y gramática Swift; recompilación con el SDK del usuario pendiente. La nota aislada no descarta otros errores en BUILD_DMG_LOG.txt.
- No se ejecutaron operaciones sobre dispositivos. Publicado ZIP corregido para volver a ejecutar `/bin/bash Build_DMG.command` en macOS.


## 0.11.0 — Macbook y Snippets TI experto (2026-10-07)
- Carpeta: `/workspace/mactech-source/MacTechPortable`; base 0.10.0 build 17, nueva versión 0.11.0 build 18. macOS mínimo 12.0 sin cambios.
- Botón exacto Macbook junto a iPhone / iPad. Panel independiente con cerrar, selector de ámbito y familia declarada MacBook Air/Pro, navegación por ocho categorías y herramientas existentes.
- Nuevo `MacBookCore.swift`: catálogo de 17 referencias a Tool existentes y política host/target/both. Diagnóstico, seguridad, rendimiento, red, Time Machine y capturas del antiguo expediente bloqueados para objetivo conectado. Escoger familia no verifica modelo ni identidad.
- Firmware: consulta de candidatos desde los buses del anfitrión, entrada DFU guiada y ruta oficial de Apple para Revive/Restore. Sólo Apple silicon/T2 y host compatible; Finder requiere macOS 14+. Intel sin T2 queda en Recovery/servicio. cfgutil Revive/Restore no se ofrecen como funcionalidad validada; el adaptador anterior sigue experimental.
- Mantenimiento y copia reutilizan launchers que identifican objetivos y conservan sus confirmaciones. Sin nuevos borrados, reparaciones automáticas ni bypass de seguridad.
- Reutilizado ExpertWorkbench para expediente Mac; identificación declarada y notas/exportación JSON/HTML/PDF. Sólo en ámbito host puede precargar el resumen local existente, rotulado ESTA Mac; nunca adjunta automáticamente métricas locales a la MacBook conectada.
- Runner: comprueba también el lock de scripts Terminal, monitoriza su presencia y bloquea otras acciones mientras existe. El lock de common.sh sigue siendo la exclusión autoritativa; no se elimina ni fuerza. El arranque de un launcher tiene ventana de espera de 2 s; el lock protege carreras posteriores. Snippets nativos copiados siguen fuera del Runner.
- Catálogo Snippets: 81 total, 71 macOS experto y 10 iPhone/iPad. Nueve categorías macOS; búsqueda y filtros colección/categoría/riesgo/arquitectura; descripción, requisitos, interpretación, parámetros, referencias y comprobación de ejecutables presentes en el anfitrión. Presencia no verifica opciones/versiones/permisos.
- 21 entradas nuevas con comandos nativos o launchers supervisados: arquitectura, registro batería, assertions, RAM, rutas/red, servicios/DNS, interfaz, información de arranque, snapshots APFS/TM, último respaldo, firma/Gatekeeper, errores, agentes, guía firmware, entrada DFU y copia de documentos.
- Nuevo `SnippetCore.swift`: modelo y validación compartidos con caseengine; DNS/IPv4 por etiquetas/octetos, interfaces y servicios; controles rechazados y quoting de rutas. Expansión sólo de marcadores de la plantilla original; marcadores en entradas del técnico no se reexpanden. Rutas sintácticas no prueban existencia; no hay ejecución automática ni salto final.
- Comandos Modifica/Destructivo pasan por wrappers protegidos, quedan ocultos hasta habilitar avanzados y requieren reconocimiento, además de las confirmaciones de los scripts. Cambiar parámetro reinicia reconocimiento.
- Integrados nuevos Swift en ambos builds y empaquetado estándar docs/scripts/launchers. `caseengine selftest` ejecutará reglas simuladas de ámbitos, escape, entradas maliciosas, plantillas, duplicados y wrappers; durante build valida también el catálogo real. No ejecuta snippets.
- PASS en Linux: 42 scripts Bash, plist/versión/recursos; 81 comandos preparados pasan bash -n, categorías/metadata/recursos y roundtrip literal de datos sintéticos con printf únicamente. Gramática de diez archivos Swift y estructura de 79 bloques de contenedor <=10 elementos directos.
- NO EJECUTADO: Swift/selftests/GUI/arrastre/clipboard en macOS, opciones nativas en ejecución, firma/universal/DMG. No hay Swift ni SDK Apple en esta máquina Linux. Las referencias Apple no pudieron descargarse por restricción de red (403); no se afirma consulta de documentación en vivo. Deben contrastarse las opciones contra man/ayuda del macOS de laboratorio.
- No se ejecutaron diagnósticos, scans ni operaciones sobre dispositivos reales. No se entrega DMG. Fuentes y guía `docs/MACBOOK_SUPPORT.md` listas para validación macOS.


## 0.11.1 build 19 — Borrado y formato supervisados (2026-10-07)
- Carpeta de trabajo conservada: `/workspace/mactech-source/MacTechPortable`; base 0.11.0 build 18. macOS mínimo 12.0.
- Macbook: nueva categoría Borrado y formato, con EraseExternal para disco físico externo y FactoryReset exclusivamente para ESTA Mac. 19 acciones reutilizadas, nueve categorías. Selección del objetivo, respaldo/riesgo y frase del panel obligatorios además de los controles del backend.
- EraseExternal.command pide explícitamente APFS o ExFAT, rechaza otros formatos y delega en erase-external.sh, sin alterar sus guardas de disco anfitrión/interno, validación de identidad, autenticación y confirmaciones. No se certifica sanitización ni instalación de macOS.
- iPhone/iPad: acción Borrar/restaurar ahora abre IOSRestore.command y ios-restore-supervised.sh en Terminal. Requiere tipo, identificación manual y frase RESTAURAR <tipo> <identificación> antes de abrir la guía/Finder. La restauración se selecciona, autentica y confirma en Finder; no hay borrado automático ni formato APFS/ExFAT de iOS. Activation Lock/MDM no se eliminan.
- Snippets iOS Restore usa el nuevo wrapper y mac-host-reset abre el mecanismo oficial de ESTA Mac. Catálogo: 82 total, 72 macOS y 10 iOS. La whitelist incluye sólo esos wrappers adicionales protegidos.
- Nuevas pruebas simuladas de ámbito: reset denegado al objetivo conectado y permitido sólo en host; formateo externo permanece sujeto al guard de dispositivo. Ningún comando de borrado se ejecutó durante pruebas.
- PASS: sintaxis Bash de 44 scripts, catálogo/plantillas y parámetros sintéticos; gramática Swift y límites estructurales. NO EJECUTADO: Swift/selftests/macOS GUI, borrados/formateos/restauraciones reales, firma y DMG. Entorno Linux.
