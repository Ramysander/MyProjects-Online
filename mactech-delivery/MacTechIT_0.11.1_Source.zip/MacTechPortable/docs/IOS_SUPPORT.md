# Soporte experto iPhone / iPad — 0.7.0

Panel gráfico desde el botón iPhone / iPad o la sección lateral correspondiente. La aplicación sigue ejecutándose en macOS 12+; no es una app instalada en iOS. Seleccionar carpeta de informes y herramienta. Backend nativo por scripts, Runner compartido y bloqueo operativo existente. Los flujos externos Finder/Configurator siguen a cargo del operador y no están bloqueados por la app.

## Funciones reales
Inventario del bus USB de la Mac, cfgutil list si existe, ayuda de versión local, informes privados y expediente técnico con observaciones antes/después. Abrir Finder/Configurator y guías oficiales. Diez snippets nuevos, total 60. No selección automática del dispositivo ni ejecución masiva.

## Procedimientos supervisados
Conexión y confianza; respaldo cifrado; actualizar; recuperación de arranque iPhone/iPad; restaurar fábrica; batería y almacenamiento según modelo; seguridad/red/perfiles; archivos compartidos por apps; exportar registros; gestión empresarial mediante Configurator. Las acciones se ejecutan y confirman en herramientas oficiales o en el dispositivo. Abrir la guía no demuestra éxito. El expediente iOS es texto, independiente del comparador/PDF de capturas macOS; no reutilizar resultados del host como diagnóstico del móvil.

## Diferencias con macOS
No diskutil/APFS/SMART para iPhone, no acceso al SSD desde DFU, no limpieza universal de cachés ni reparación de permisos. Sensores/ciclos/batería no se consultan automáticamente desde la Mac. No extraer datos bloqueados ni quitar Activation Lock/MDM; requieren credenciales y procesos del propietario/administrador. Restaurar borra datos; actualizar primero en recuperación cuando corresponda. La salud registrada manualmente se marca como observación, no resultado medido.

## Dependencias y construcción
Finder integrado en macOS. Apple Configurator y Automation Tools son opcionales para inventario cfgutil; requieren instalación en la Mac técnica y compatibilidad con su versión. El paquete no incorpora ni instala esas herramientas. Cable de datos, dispositivo desbloqueado y confianza para acceso normal; en recuperación capacidades limitadas. No guardar PIN/contraseñas en informes. Informes USB pueden incluir seriales de otros accesorios.

Descomprimir carpeta nueva, conservar informes previos y ejecutar /bin/bash Build_DMG.command. Resultado esperado dist/MacTech_IT_v0.7.0.dmg. El build incluye IOSSupportView.swift en ambas arquitecturas. No se ha compilado ni probado físicamente en macOS en este entorno Linux.

Fuentes oficiales:
https://support.apple.com/en-us/109054
https://support.apple.com/en-us/108796
https://support.apple.com/en-us/118106
https://support.apple.com/en-us/108925
https://support.apple.com/guide/apple-configurator-mac/welcome/mac


## Borrar / restaurar — 0.11.1
La acción abre Terminal con IOSRestore.command. Introduzca tipo iPhone/iPad, una etiqueta visible sin secretos y la frase exacta indicada. Sólo después abre Finder y la guía oficial. Seleccione y confirme el mismo equipo en Finder; allí se realiza la restauración que borra datos y reinstala iOS/iPadOS. No hay formato APFS/ExFAT, selección automática, eliminación de Activation Lock/MDM ni restauración certificada por abrir la guía. Los informes por defecto van a Documents/MacTech IT Reports para este launcher.
