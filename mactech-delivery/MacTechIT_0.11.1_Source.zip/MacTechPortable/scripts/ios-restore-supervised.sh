#!/bin/bash
# Opens the official Finder workflow only; does not issue an erase to a device.
source "$(dirname "$0")/common.sh"
[ "$#" = 0 ] || fail 'Sin argumentos; identificación interactiva obligatoria.'
[ -t 0 ] || fail 'Requiere una Terminal interactiva.'
export MACTECH_REPORTS="${MACTECH_REPORTS:-$HOME/Documents/MacTech IT Reports}"
[ -d "$MACTECH_REPORTS" ] || /bin/mkdir -m 700 -p "$MACTECH_REPORTS"
read -r -p 'Tipo exacto [iPhone o iPad]: ' family
case "$family" in iPhone|iPad) ;; *) fail 'Seleccione iPhone o iPad.' ;; esac
read -r -p 'Identificador visible del objetivo (modelo/etiqueta, nunca PIN ni claves): ' target
[ -n "$target" ] && [ "${#target}" -le 120 ] || fail 'Identificación requerida, máximo 120 caracteres.'
[[ "$target" != *[[:cntrl:]]* ]] || fail 'Identificación con caracteres de control.'
printf 'Objetivo DECLARADO: %s — %s\n' "$family" "$target"
echo 'Confirme el mismo equipo en Finder. MacTech no selecciona ni valida su identidad por software.'
echo 'Restaurar reinstala iOS/iPadOS y BORRA sus datos. No se aplica un formato APFS/ExFAT al iPhone/iPad.'
echo 'Respalde y compruebe que puede restaurar la copia. Activation Lock y MDM pueden permanecer.'
confirm "RESTAURAR $family $target"
/bin/bash "$ROOT/scripts/ios.sh" restore
echo 'Sólo se abrió el flujo oficial. Seleccione ese objetivo y confirme/autentique en Finder.'
echo 'No se verificó el borrado ni el resultado de la restauración.'
