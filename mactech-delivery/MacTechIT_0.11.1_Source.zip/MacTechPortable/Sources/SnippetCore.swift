import Foundation

struct ITSnippet: Codable, Identifiable {
    let id: String
    let title: String
    let category: String
    let detail: String
    let command: String
    let kind: String
    let risk: String
    var collection: String? = nil
    var requirements: String? = nil
    var compatibility: String? = nil
    var interpretation: String? = nil
    var parameterHint: String? = nil
    var reference: String? = nil
    var executables: [String]? = nil
}
func quoteForShell(_ value: String) -> String {
    "'" + value.replacingOccurrences(of: "'", with: "'\\''") + "'"
}
func snippetError(_ message: String) -> NSError {
    NSError(domain: "Snippet", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
}
func validSnippetParameter(_ input: String, kind: String) -> Bool {
    guard input.count <= 4096, !input.unicodeScalars.contains(where: { CharacterSet.controlCharacters.union(.newlines).contains($0) }) else { return false }
    func matches(_ pattern: String) -> Bool { input.range(of: pattern, options: .regularExpression) != nil }
    switch kind {
    case "none": return input.isEmpty
    case "host":
        guard !input.isEmpty, input.count <= 253 else { return false }
        if input.allSatisfy({ $0.isNumber || $0 == "." }) {
            let parts = input.split(separator: ".", omittingEmptySubsequences: false)
            return parts.count == 4 && parts.allSatisfy { !$0.isEmpty && $0.count <= 3 && $0.allSatisfy({ "0123456789".contains($0) }) && (Int($0) ?? 256) <= 255 }
        }
        return input.split(separator: ".", omittingEmptySubsequences: false).allSatisfy {
            !$0.isEmpty && $0.count <= 63 && String($0).range(of: "^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$", options: .regularExpression) != nil
        }
    case "disk": return matches("^disk[0-9]+(s[0-9]+)*$")
    case "wholeDisk": return matches("^disk[0-9]+$")
    case "volume": return matches("^disk[0-9]+s[0-9]+$")
    case "bundle": return matches("^[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)+$")
    case "file": return input.hasPrefix("/")
    case "app": return input.hasPrefix("/") && input.hasSuffix(".app")
    case "interface": return matches("^[A-Za-z][A-Za-z0-9._-]{0,31}$")
    case "service": return !input.isEmpty && input.count <= 100 && !input.hasPrefix("-")
    default: return false
    }
}
func validateSnippetCatalog(_ items: [ITSnippet]) throws {
    guard !items.isEmpty, Set(items.map { $0.id }).count == items.count else { throw snippetError("Catálogo vacío o IDs duplicados") }
    let kinds = ["none", "host", "disk", "wholeDisk", "volume", "bundle", "file", "app", "interface", "service"]
    let wrappers = ["cache-user.sh", "apfs.sh", "erase-external.sh", "unmount-external.sh", "ios.sh", "ios-restore-supervised.sh", "factory-reset.sh"]
    let regex = try NSRegularExpression(pattern: "\\{\\{([^{}]+)\\}\\}")
    for item in items {
        guard kinds.contains(item.kind), ["Lectura", "Supervisado", "Modifica", "Destructivo"].contains(item.risk),
              !item.command.isEmpty, !item.command.unicodeScalars.contains(where: { CharacterSet.controlCharacters.union(.newlines).contains($0) }) else { throw snippetError("Entrada inválida: " + item.id) }
        let ns = item.command as NSString
        let tokens = regex.matches(in: item.command, range: NSRange(location: 0, length: ns.length)).map { ns.substring(with: $0.range(at: 1)) }
        let remainder = regex.stringByReplacingMatches(in: item.command, range: NSRange(location: 0, length: ns.length), withTemplate: "")
        guard tokens.allSatisfy({ ["target", "toolkit"].contains($0) }),
              !remainder.contains("{{"), !remainder.contains("}}"),
              (item.kind == "none" ? !tokens.contains("target") : tokens.contains("target")) else { throw snippetError("Plantilla/parámetro inválido: " + item.id) }
        if item.risk == "Modifica" || item.risk == "Destructivo" {
            guard wrappers.contains(where: { item.command.hasPrefix("/bin/bash {{toolkit}}/scripts/" + $0 + " ") || item.command == "/bin/bash {{toolkit}}/scripts/" + $0 }) || item.command == "/bin/bash {{toolkit}}/scripts/ios.sh restore" else {
                throw snippetError("Acción sin wrapper supervisado: " + item.id)
            }
        }
    }
}
func prepareSnippet(_ item: ITSnippet, parameter: String, root: String, acknowledged: Bool) throws -> String {
    try validateSnippetCatalog([item])
    guard validSnippetParameter(parameter, kind: item.kind), root.hasPrefix("/"),
          !root.unicodeScalars.contains(where: { CharacterSet.controlCharacters.union(.newlines).contains($0) }) else { throw snippetError("Parámetro o ruta inválidos") }
    if item.risk == "Modifica" || item.risk == "Destructivo" {
        guard acknowledged else { throw snippetError("Identifique el objetivo y reconozca el riesgo") }
    }
    // Expand only tokens in the original template, never tokens inside user input.
    let regex = try NSRegularExpression(pattern: "\\{\\{(target|toolkit)\\}\\}")
    let original = item.command as NSString
    let result = NSMutableString(string: item.command)
    for match in regex.matches(in: item.command, range: NSRange(location: 0, length: original.length)).reversed() {
        let token = original.substring(with: match.range(at: 1))
        result.replaceCharacters(in: match.range, with: quoteForShell(token == "target" ? parameter : root))
    }
    return result as String
}
func snippetCoreSelfTest() throws {
    guard quoteForShell("O'Brien") == "'O'\\''Brien'" else { throw snippetError("Escape de apóstrofe incorrecto") }
    for bad in ["example.com;id", "$(id)", "-x", "example..com", "999.1.1.1", "a\n.com", "a_b.com"] {
        guard !validSnippetParameter(bad, kind: "host") else { throw snippetError("Host inseguro aceptado") }
    }
    guard validSnippetParameter("192.168.1.10", kind: "host"), validSnippetParameter("support.example.com", kind: "host"),
          !validSnippetParameter("disk1;id", kind: "disk"), validSnippetParameter("Wi-Fi", kind: "service"),
          !validSnippetParameter("-listall", kind: "service"), !validSnippetParameter("en0\n", kind: "interface") else { throw snippetError("Reglas de parámetros") }
    let fixture = ITSnippet(id: "fixture", title: "Fixture", category: "Firma", detail: "Synthetic", command: "/usr/bin/codesign --verify {{target}}", kind: "app", risk: "Lectura")
    let input = "/tmp/O'Brien $(id) {{toolkit}}.app"
    let command = try prepareSnippet(fixture, parameter: input, root: "/tmp/Kit test", acknowledged: false)
    guard command == "/usr/bin/codesign --verify " + quoteForShell(input), !command.hasSuffix("\n") else { throw snippetError("Escape o expansión recursiva") }
    func rejected(_ operation: () throws -> Void) throws {
        do { try operation() } catch { return }
        throw snippetError("Caso inválido aceptado")
    }
    try rejected { try validateSnippetCatalog([fixture, fixture]) }
    let destructive = ITSnippet(id: "unsafe", title: "Fixture", category: "Disk", detail: "Synthetic", command: "/usr/sbin/diskutil eraseDisk APFS test {{target}}", kind: "wholeDisk", risk: "Destructivo")
    try rejected { try validateSnippetCatalog([destructive]) }
    let guarded = ITSnippet(id: "guarded", title: "Fixture", category: "Disk", detail: "Synthetic", command: "/bin/bash {{toolkit}}/scripts/erase-external.sh {{target}}", kind: "wholeDisk", risk: "Destructivo")
    try rejected { _ = try prepareSnippet(guarded, parameter: "disk9", root: "/tmp/kit", acknowledged: false) }
    let output = try prepareSnippet(guarded, parameter: "disk9", root: "/tmp/O'Brien", acknowledged: true)
    guard output == "/bin/bash " + quoteForShell("/tmp/O'Brien") + "/scripts/erase-external.sh 'disk9'" else { throw snippetError("Wrapper perdió quoting") }
}
