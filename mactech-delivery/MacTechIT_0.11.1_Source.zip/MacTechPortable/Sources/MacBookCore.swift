import Foundation

struct MacBookAction: Identifiable {
    let id: String // Existing Tool id: reuse execution and scripts.
    let category: String
    let scope: String // host, target or both
    let mode: String
}
let macBookCategories = ["Diagnóstico", "Seguridad", "Rendimiento", "Red", "Respaldo y recuperación", "Firmware", "Mantenimiento", "Borrado y formato", "Expedientes"]
let macBookActions: [MacBookAction] = [
    MacBookAction(id: "diag", category: "Diagnóstico", scope: "host", mode: "Consulta local"),
    MacBookAction(id: "inventory", category: "Diagnóstico", scope: "host", mode: "Consulta local"),
    MacBookAction(id: "security", category: "Seguridad", scope: "host", mode: "Consulta local"),
    MacBookAction(id: "performance", category: "Rendimiento", scope: "host", mode: "Consulta local"),
    MacBookAction(id: "logs", category: "Rendimiento", scope: "host", mode: "Consulta local"),
    MacBookAction(id: "network", category: "Red", scope: "host", mode: "Consulta local; destino autorizado opcional"),
    MacBookAction(id: "backupstatus", category: "Respaldo y recuperación", scope: "host", mode: "Consulta local Time Machine"),
    MacBookAction(id: "backup", category: "Respaldo y recuperación", scope: "both", mode: "Copia supervisada de carpetas accesibles; no respaldo automático"),
    MacBookAction(id: "remotedisk", category: "Respaldo y recuperación", scope: "target", mode: "Guía Compartir disco / disco de destino"),
    MacBookAction(id: "recoveryassistant", category: "Respaldo y recuperación", scope: "both", mode: "Guía de recuperación; no reparación automática"),
    MacBookAction(id: "dfuentry", category: "Firmware", scope: "target", mode: "Guía física DFU; seleccionar Mac, no iPhone/iPad"),
    MacBookAction(id: "externalscan", category: "Firmware", scope: "target", mode: "Consulta de buses del anfitrión; sólo candidatos"),
    MacBookAction(id: "dfuinventory", category: "Firmware", scope: "target", mode: "Inventario Configurator; requiere cfgutil"),
    MacBookAction(id: "cache", category: "Mantenimiento", scope: "host", mode: "Modifica caché de usuario; confirmación en Terminal"),
    MacBookAction(id: "verify", category: "Mantenimiento", scope: "both", mode: "Verificación supervisada del volumen seleccionado"),
    MacBookAction(id: "repair", category: "Mantenimiento", scope: "both", mode: "Reparación supervisada desde Recovery"),
    MacBookAction(id: "erase", category: "Borrado y formato", scope: "both", mode: "BORRA disco físico externo; APFS/ExFAT; validación y confirmación en Terminal"),
    MacBookAction(id: "reset", category: "Borrado y formato", scope: "host", mode: "BORRA ESTA Mac mediante Erase Assistant oficial; no el objetivo conectado"),
    MacBookAction(id: "cases", category: "Expedientes", scope: "host", mode: "Capturas de ESTA Mac; no del objetivo conectado")
]
func macBookActionAllowed(_ action: MacBookAction, scope: String) -> Bool {
    ["host", "target"].contains(scope) && (action.scope == "both" || action.scope == scope)
}
func macBookCoreSelfTest() throws {
    guard let reset = macBookActions.first(where: { $0.id == "reset" }),
          let erase = macBookActions.first(where: { $0.id == "erase" }),
          !macBookActionAllowed(reset, scope: "target"), macBookActionAllowed(reset, scope: "host"),
          macBookActionAllowed(erase, scope: "target") else { throw snippetError("Borrado en ámbito incorrecto") }

    guard Set(macBookActions.map { $0.id }).count == macBookActions.count,
          macBookActions.allSatisfy({ macBookCategories.contains($0.category) && ["host", "target", "both"].contains($0.scope) }),
          macBookActions.filter({ $0.scope == "host" }).allSatisfy({ !macBookActionAllowed($0, scope: "target") }),
          !macBookActionAllowed(macBookActions[0], scope: "unknown") else { throw snippetError("Ámbitos MacBook inválidos") }
}
