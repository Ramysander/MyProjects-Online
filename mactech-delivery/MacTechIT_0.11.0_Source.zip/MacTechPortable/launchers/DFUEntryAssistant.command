#!/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
exec /bin/bash "$ROOT/scripts/dfu-entry-assistant.sh"
