#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
/bin/bash "$ROOT/scripts/factory-reset.sh"
