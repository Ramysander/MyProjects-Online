#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
read -r -p "ECID validado de la Mac objetivo: " ecid
/bin/bash "$ROOT/scripts/dfu.sh" revive "$ecid"
