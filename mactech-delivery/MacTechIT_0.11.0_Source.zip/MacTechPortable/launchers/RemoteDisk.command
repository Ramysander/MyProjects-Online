#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
read -r -p 'Carpeta existente para informe (ruta absoluta): ' destination
MACTECH_REPORTS="$destination" /bin/bash "$ROOT/scripts/remote-disk.sh"
