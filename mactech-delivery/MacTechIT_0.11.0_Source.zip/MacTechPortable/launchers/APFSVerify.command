#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
read -r -p "Volumen (diskNsM): " volume
/bin/bash "$ROOT/scripts/apfs.sh" verify "$volume"
