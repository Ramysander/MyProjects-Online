#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
read -r -p "Volumen (diskNsM), sólo desde Recovery: " volume
/bin/bash "$ROOT/scripts/apfs.sh" repair "$volume"
