#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
read -r -p "Carpeta origen (ruta absoluta): " src
read -r -p "Carpeta destino (ruta absoluta): " dst
/bin/bash "$ROOT/scripts/backup-files.sh" "$src" "$dst"
