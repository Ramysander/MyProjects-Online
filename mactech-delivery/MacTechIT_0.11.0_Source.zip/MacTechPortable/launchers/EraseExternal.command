#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
read -r -p "Disco externo completo (diskN): " disk
/bin/bash "$ROOT/scripts/erase-external.sh" "$disk"
