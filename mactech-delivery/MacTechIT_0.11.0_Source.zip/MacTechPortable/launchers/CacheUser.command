#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
read -r -p "Bundle ID de caché (com.fabricante.app): " bundle
/bin/bash "$ROOT/scripts/cache-user.sh" "$bundle"
