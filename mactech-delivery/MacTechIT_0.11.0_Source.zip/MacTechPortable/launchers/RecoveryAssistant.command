#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
# Permite elegir dónde guardar el expediente cuando corre dentro de una .app.
read -r -p 'Carpeta existente para informe (ruta absoluta): ' destination
MACTECH_REPORTS="$destination" /bin/bash "$ROOT/scripts/recovery-assistant.sh"
