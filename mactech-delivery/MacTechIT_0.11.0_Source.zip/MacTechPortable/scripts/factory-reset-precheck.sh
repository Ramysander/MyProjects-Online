#!/bin/bash
source "$(dirname "$0")/common.sh"

# Read-only eligibility assessment. Never erases, restarts, signs out, or changes settings.
version="$(/usr/bin/sw_vers -productVersion 2>/dev/null || echo unknown)"
major="${version%%.*}"
arch="$(/usr/bin/uname -m)"
model="$(/usr/sbin/sysctl -n hw.model 2>/dev/null || echo unknown)"
assistant='/System/Library/CoreServices/Erase Assistant.app'

silicon=no
[ "$arch" = arm64 ] && silicon=yes

t2=unknown
if [ "$silicon" = yes ]; then
  t2='not-applicable'
elif /usr/sbin/system_profiler SPiBridgeDataType 2>/dev/null | /usr/bin/grep -qiE 'Apple T2|T2'; then
  t2=yes
else
  t2=no
fi

power='unknown'
if /usr/bin/pmset -g batt 2>/dev/null | /usr/bin/grep -qi 'AC Power'; then power='AC connected';
elif /usr/bin/pmset -g batt >/dev/null 2>&1; then power='battery'; fi

network='unknown'
if /usr/bin/nc -G 2 -z apple.com 443 >/dev/null 2>&1; then network='reachable'; else network='not confirmed'; fi

eacs=no
if [[ "$major" =~ ^[0-9]+$ ]] && [ "$major" -ge 12 ] && { [ "$silicon" = yes ] || [ "$t2" = yes ]; }; then eacs=yes; fi
[ -d "$assistant" ] || eacs=no

repair_note='not-required-by-rule'
if [ "$silicon" = yes ] && [[ "$major" =~ ^[0-9]+$ ]] && [ "$major" -ge 26 ]; then
  repair_note='check Repair Assistant if this Mac was repaired or repair status is uncertain'
fi

printf '%s\n' 'FULL FACTORY RESET — READ-ONLY PRE-CHECK'
printf 'Model: %s\nmacOS: %s\nArchitecture: %s\nApple silicon: %s\nT2: %s\nPower: %s\nInternet: %s\nErase Assistant eligible: %s\nRepair Assistant note: %s\n' \
  "$model" "$version" "$arch" "$silicon" "$t2" "$power" "$network" "$eacs" "$repair_note"
printf '%s\n' 'Backup status is NOT inferred as safe. The operator must verify a usable backup before erasing.'

if [ "$eacs" = yes ]; then
  printf '%s\n' 'Recommended method: Apple Erase Assistant (Erase All Content and Settings).'
  exit 0
fi
printf '%s\n' 'Erase All Content and Settings is not confirmed available. Use macOS Recovery + Disk Utility + Reinstall macOS following Apple guidance; this tool will not automate startup-disk erasure.'
exit 2
