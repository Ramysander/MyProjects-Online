#!/bin/bash
# Read-only interpretation of reports. Conservative: collection success is not health success.
summary_status_line() {
  local level="$1" label="$2" detail="$3"
  printf '%-13s %-28s %s\n' "[$level]" "$label" "$detail" | tee -a "$REPORT/summary.txt"
}
summary_init() {
  : > "$REPORT/summary.txt"
  printf 'MacTech IT — Resumen de diagnóstico\nUTC: %s\n\n' "$(date -u)" | tee -a "$REPORT/summary.txt"
}
summary_collection_status() {
  local status_file="$REPORT/status.tsv" name rc file
  [ -f "$status_file" ] || return 0
  printf '\nRecolección de proveedores\n' | tee -a "$REPORT/summary.txt"
  while IFS=$'\t' read -r name rc file; do
    [ "$name" = module ] && continue
    [ -n "$name" ] || continue
    if [ "${rc:-1}" = 0 ]; then
      summary_status_line COLLECTED "$name" "datos obtenidos; no implica salud positiva"
    else
      summary_status_line UNAVAILABLE "$name" "comando terminó con código ${rc:-?}"
    fi
  done < "$status_file"
}
summary_security() {
  printf '\nInterpretación de seguridad\n' | tee -a "$REPORT/summary.txt"
  if [ -f "$REPORT/filevault.txt" ]; then
    if /usr/bin/grep -qi 'FileVault is On' "$REPORT/filevault.txt"; then summary_status_line PASS FileVault 'cifrado activado'
    elif /usr/bin/grep -qi 'FileVault is Off' "$REPORT/filevault.txt"; then summary_status_line WARNING FileVault 'cifrado desactivado'
    else summary_status_line UNKNOWN FileVault 'estado no reconocido'; fi
  fi
  if [ -f "$REPORT/sip.txt" ]; then
    if /usr/bin/grep -qi 'System Integrity Protection status: enabled' "$REPORT/sip.txt"; then summary_status_line PASS SIP 'System Integrity Protection activado'
    elif /usr/bin/grep -qi 'System Integrity Protection status: disabled' "$REPORT/sip.txt"; then summary_status_line WARNING SIP 'System Integrity Protection desactivado'
    else summary_status_line UNKNOWN SIP 'estado no reconocido'; fi
  fi
  if [ -f "$REPORT/gatekeeper.txt" ]; then
    if /usr/bin/grep -qi 'assessments enabled' "$REPORT/gatekeeper.txt"; then summary_status_line PASS Gatekeeper 'evaluaciones activadas'
    elif /usr/bin/grep -qi 'assessments disabled' "$REPORT/gatekeeper.txt"; then summary_status_line WARNING Gatekeeper 'evaluaciones desactivadas'
    else summary_status_line UNKNOWN Gatekeeper 'estado no reconocido'; fi
  fi
  if [ -f "$REPORT/firewall.txt" ]; then
    if /usr/bin/grep -Eqi 'enabled|State = 1' "$REPORT/firewall.txt"; then summary_status_line PASS Firewall 'firewall de aplicaciones activado'
    elif /usr/bin/grep -Eqi 'disabled|State = 0' "$REPORT/firewall.txt"; then summary_status_line WARNING Firewall 'firewall de aplicaciones desactivado'
    else summary_status_line UNKNOWN Firewall 'estado no reconocido'; fi
  fi
}
summary_battery() {
  [ -f "$REPORT/battery.txt" ] || return 0
  printf '\nInterpretación de batería\n' | tee -a "$REPORT/summary.txt"
  if /usr/bin/grep -Eqi 'Condition: *Normal|Estado: *Normal' "$REPORT/battery.txt"; then
    summary_status_line PASS Batería 'system_profiler informa condición Normal'
  elif /usr/bin/grep -Eqi 'Service Recommended|Replace (Soon|Now)|Check Battery|Reparación recomendada' "$REPORT/battery.txt"; then
    summary_status_line WARNING Batería 'macOS informa servicio/revisión recomendada'
  else
    summary_status_line UNKNOWN Batería 'no se encontró una condición interpretable; revisar battery.txt'
  fi
}
summary_storage() {
  [ -f "$REPORT/free_space.txt" ] || return 0
  printf '\nInterpretación de almacenamiento\n' | tee -a "$REPORT/summary.txt"
  local pct
  pct=$(/usr/bin/awk '$NF=="/" {gsub("%","",$(NF-1)); print $(NF-1); exit}' "$REPORT/free_space.txt" 2>/dev/null || true)
  if [[ "$pct" =~ ^[0-9]+$ ]]; then
    if [ "$pct" -ge 95 ]; then summary_status_line FAIL 'Disco de arranque' "${pct}% utilizado; espacio críticamente bajo"
    elif [ "$pct" -ge 85 ]; then summary_status_line WARNING 'Disco de arranque' "${pct}% utilizado; conviene liberar espacio"
    else summary_status_line PASS 'Disco de arranque' "${pct}% utilizado"
    fi
  else summary_status_line UNKNOWN 'Disco de arranque' 'no se pudo interpretar df'; fi
}
summary_finish() {
  printf '\nLeyenda: PASS=estado reconocido favorable; WARNING=requiere atención; FAIL=problema claro; UNKNOWN/UNAVAILABLE=no concluir salud; COLLECTED=sólo recolección correcta.\n' | tee -a "$REPORT/summary.txt"
  printf '\nResumen guardado: %s\n' "$REPORT/summary.txt"
}
