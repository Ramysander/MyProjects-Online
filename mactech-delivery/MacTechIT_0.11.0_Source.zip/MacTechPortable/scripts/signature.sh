#!/bin/bash
source "$(dirname "$0")/common.sh"
[ "$#" = 1 ] || fail 'Uso: signature.sh /ruta/Aplicacion.app'
app="$1"
[[ "$app" = /*.app ]] && [ -d "$app" ] && [ ! -L "$app" ] || fail 'Seleccione una .app absoluta.'
new_report
rc=0
/usr/bin/codesign --verify --deep --strict --verbose=2 "$app" > "$REPORT/codesign.txt" 2>&1 || rc=$?
printf 'codesign\t%s\n' "$rc" > "$REPORT/status.tsv"
rc=0
/usr/sbin/spctl --assess --type execute --verbose=2 "$app" > "$REPORT/gatekeeper.txt" 2>&1 || rc=$?
printf 'gatekeeper\t%s\n' "$rc" >> "$REPORT/status.tsv"
cat "$REPORT/status.tsv"
echo "Informe: $REPORT. Firma válida no significa ausencia de malware."
