#!/bin/bash
# Catálogo cerrado de operaciones de lectura. Sin shell eval ni escaneo de redes.
source "$(dirname "$0")/common.sh"
[ "$EUID" -ne 0 ] || fail 'Ejecutar sin sudo; no elevar el conjunto de herramientas.'
mode="${1:-inventory}"
case "$mode" in inventory|network|security|performance|services|logs|backup-status|printers|updates|all) ;; *) fail 'Módulo inválido.' ;; esac
[ "$#" -le 2 ] || fail 'Demasiados argumentos.'
host="${2:-}"
if [ -n "$host" ]; then
  [ "$mode" = network ] || fail 'Host sólo válido para network.'
  [[ "$host" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$ ]] || fail 'Host IPv4/DNS inválido.'
  [ "${#host}" -le 253 ] || fail 'Host demasiado largo.'
fi
new_report
printf 'module\texit_code\tfile\n' > "$REPORT/status.tsv"
collect() {
  local name="$1"; shift
  local rc=0
  "$@" > "$REPORT/$name.txt" 2>&1 || rc=$?
  printf '%s\t%s\t%s.txt\n' "$name" "$rc" "$name" >> "$REPORT/status.tsv"
  printf '%s: salida %s\n' "$name" "$rc"
}
inventory() {
  collect os /usr/bin/sw_vers
  collect hardware /usr/sbin/system_profiler SPHardwareDataType SPPowerDataType
  collect peripherals /usr/sbin/system_profiler SPUSBDataType SPThunderboltDataType SPDisplaysDataType SPAudioDataType
  collect applications /usr/sbin/system_profiler SPApplicationsDataType
  collect packages /usr/sbin/pkgutil --pkgs
  collect users /usr/bin/dscl . -list /Users UniqueID
}
network() {
  collect ports /usr/sbin/networksetup -listallhardwareports
  collect interfaces /sbin/ifconfig -a
  collect dns /usr/sbin/scutil --dns
  collect proxy /usr/sbin/scutil --proxy
  collect route /sbin/route -n get default
  collect listeners /usr/sbin/lsof -nP -iTCP -sTCP:LISTEN
  if [ -n "$host" ]; then
    # Sólo un destino indicado por el operador, hasta cuatro paquetes.
    collect resolution /usr/bin/dscacheutil -q host -a name "$host"
    collect ping /sbin/ping -c 4 -W 1000 "$host"
  fi
}
security() {
  collect filevault /usr/bin/fdesetup status
  collect sip /usr/bin/csrutil status
  collect gatekeeper /usr/sbin/spctl --status
  collect firewall /usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate
  collect firewall_stealth /usr/libexec/ApplicationFirewall/socketfilterfw --getstealthmode
  collect mdm /usr/bin/profiles status -type enrollment
}
performance() {
  collect memory /usr/bin/vm_stat
  collect swap /usr/sbin/sysctl vm.swapusage
  collect cpu /usr/bin/top -l 1 -n 15 -o cpu
  collect free_space /bin/df -h
  collect thermal /usr/bin/pmset -g therm
}
services() {
  collect agents /bin/launchctl list
  collect system_daemon_files /bin/ls -la /Library/LaunchDaemons
  collect system_agent_files /bin/ls -la /Library/LaunchAgents
  collect user_agent_files /bin/ls -la "$HOME/Library/LaunchAgents"
  # No volcar variables de entorno de launchctl print ni comandos de procesos.
}
logs() {
  collect recent_errors /usr/bin/log show --last 5m --style compact --predicate 'messageType == error OR messageType == fault'
  collect system_crash_files /bin/ls -lt /Library/Logs/DiagnosticReports
  collect user_crash_files /bin/ls -lt "$HOME/Library/Logs/DiagnosticReports"
}
backup_status() {
  collect time_machine /usr/bin/tmutil status
  collect time_machine_destinations /usr/bin/tmutil destinationinfo
  collect apfs /usr/sbin/diskutil apfs list
}
printers() {
  collect queues /usr/bin/lpstat -p -d
  collect jobs /usr/bin/lpstat -o
  collect hardware_printers /usr/sbin/system_profiler SPPrintersDataType
}
updates() { collect available_updates /usr/sbin/softwareupdate --list; }
case "$mode" in
  all) inventory; network; security; performance; services; logs; backup_status; printers ;;
  backup-status) backup_status ;;
  *) "$mode" ;;
esac
source "$(dirname "$0")/diagnostic-summary.sh"
summary_init
summary_collection_status
summary_security
summary_battery
summary_storage
summary_finish
printf 'Informe guardado: %s\n' "$REPORT"
echo 'Código 0 significa ejecución correcta, no equipo sano. Use summary.txt para la interpretación conservadora.'
