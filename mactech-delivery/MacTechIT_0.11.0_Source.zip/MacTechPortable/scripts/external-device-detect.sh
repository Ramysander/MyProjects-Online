#!/bin/bash
# Safe, read-only discovery of USB/Thunderbolt devices and Apple recovery/DFU candidates.
source "$(dirname "$0")/common.sh"
mode="${1:-scan}"
case "$mode" in scan|watch) ;; *) fail 'Uso: external-device-detect.sh scan|watch' ;; esac
need_helper
new_report
out="$REPORT/external-devices.txt"
json="$REPORT/device-state.tsv"
scan_once() {
  local stamp
  stamp="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  {
    echo "=== MacTech IT External Device Scan ==="
    echo "UTC: $stamp"
    echo
    echo '--- USB ---'
    /usr/sbin/system_profiler SPUSBDataType 2>&1 || true
    echo
    echo '--- Thunderbolt / USB4 ---'
    /usr/sbin/system_profiler SPThunderboltDataType 2>&1 || true
    echo
    echo '--- Apple DFU / Recovery candidates ---'
    "$HELPER" dfu 2>&1 || true
    echo
    if [ -x /usr/local/bin/cfgutil ]; then
      echo '--- Apple Configurator (cfgutil list) ---'
      /usr/local/bin/cfgutil list 2>&1 || true
    else
      echo 'cfgutil: NOT INSTALLED (optional; install Automation Tools from Apple Configurator).'
    fi
  } > "$out"

  # Parse records only: report headings must never trigger DFU/Recovery detection.
  local inventory="$REPORT/device-inventory.json"
  [ -x "$ROOT/bin/caseengine" ] || fail 'Compile el motor de expedientes antes de escanear.'
  if /usr/sbin/system_profiler SPUSBDataType SPThunderboltDataType -json > "$inventory" 2> "$REPORT/inventory-errors.txt"; then
    "$ROOT/bin/caseengine" parse-inventory "$inventory" > "$json" || fail 'No se pudo interpretar el inventario.'
  else
    printf 'UNAVAILABLE\tInventario no disponible; no usar estado anterior\n' > "$json"
  fi
  /bin/cat "$json"
  echo "Inventario: $out"
  echo "Estado estructurado: $json"
}

if [ "$mode" = scan ]; then
  scan_once
else
  echo 'Auto-detección activa durante 120 segundos. Sólo lectura; no cambia el estado de dispositivos.'
  previous=''
  started=$SECONDS
  while [ "$((SECONDS-started))" -lt 120 ]; do
    scan_once
    current="$(/usr/bin/shasum -a 256 "$json" | /usr/bin/awk '{print $1}')"
    if [ "$current" != "$previous" ]; then
      echo "Cambio detectado: $(date '+%H:%M:%S')"
      /bin/cat "$json"
      previous="$current"
    fi
    /bin/sleep 2
  done
fi
printf 'Informe: %s\n' "$REPORT"
