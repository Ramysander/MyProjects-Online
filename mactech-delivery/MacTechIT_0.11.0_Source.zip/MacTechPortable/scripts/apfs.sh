#!/bin/bash
source "$(dirname "$0")/common.sh"
[ "$#" = 2 ] || fail 'Uso: apfs.sh verify|repair diskNsM'
mode="$1"; volume="$2"
[[ "$volume" =~ ^disk[0-9]+s[0-9]+$ ]] || fail 'Se requiere identificador de volumen.'
/usr/sbin/diskutil info "$volume"
case "$mode" in
  verify) /usr/sbin/diskutil verifyVolume "$volume" ;;
  repair)
    # La selección y desmontaje del volumen deben hacerse desde Recovery.
    echo 'Realice reparación desde Recovery y con copia de seguridad.'
    confirm "REPARAR $volume DESDE RECOVERY"
    /usr/sbin/diskutil repairVolume "$volume"
    ;;
  *) fail 'Modo inválido.' ;;
esac
