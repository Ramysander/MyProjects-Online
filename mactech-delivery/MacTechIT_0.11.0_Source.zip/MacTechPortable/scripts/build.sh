#!/bin/bash
source "$(dirname "$0")/common.sh"
# No depender de carpetas vacías preservadas por el descompresor.
mkdir -p "$ROOT/bin"
[ -d "$ROOT/bin" ] && [ -w "$ROOT/bin" ] || fail 'La carpeta bin no es escribible.'
# Ejecutar únicamente en la Mac de desarrollo con Xcode/Command Line Tools.
# Para distribución completa producir ambos slices; no instalar compilador al cliente.
for arch in arm64 x86_64; do
  /usr/bin/xcrun swiftc -O -target "$arch-apple-macos12.0" \
    "$ROOT/Sources/macprobe.swift" -framework IOKit -o "$ROOT/bin/macprobe-$arch"
done
/usr/bin/lipo -create "$ROOT/bin/macprobe-arm64" "$ROOT/bin/macprobe-x86_64" -output "$ROOT/bin/macprobe"
echo 'Falta firmar/notarizar la distribución para publicación. Consulte docs/BLUEPRINT.md.'

for arch in arm64 x86_64; do
  /usr/bin/xcrun swiftc -O -parse-as-library -target "$arch-apple-macos12.0" "$ROOT/Sources/CaseEngine.swift" "$ROOT/Sources/SupportCore.swift" "$ROOT/Sources/SnippetCore.swift" "$ROOT/Sources/MacBookCore.swift" -o "$ROOT/bin/caseengine-$arch"
done
/usr/bin/lipo -create "$ROOT/bin/caseengine-arm64" "$ROOT/bin/caseengine-x86_64" -output "$ROOT/bin/caseengine"
"$ROOT/bin/caseengine" selftest "$ROOT/docs/snippets.json"
