#!/bin/bash
# Acceso supervisado a archivos: sin borrado, reparación ni firmware automático.
source "$(dirname "$0")/common.sh"
[ "$EUID" -ne 0 ] || fail 'Ejecutar sin sudo en la Mac técnica.'
[ -t 0 ] || fail 'Abra el asistente en Terminal.'
new_report
printf 'Acceso entre Macs 0.7.0\nUTC: %s\n' "$(date -u)" > "$REPORT/access.txt"
echo 'DFU no expone archivos ni volúmenes: sólo recuperación de firmware.'
echo 'Compartir disco requiere que el objetivo pueda iniciar Recovery.'
echo 'FileVault necesita contraseña o clave legítima. No se solicita ni guarda aquí.'
echo '1 Apple Silicon: Compartir disco; 2 Intel: disco de destino'
echo '3 Unidad externa ya conectada; 4 Objetivo sólo disponible en DFU'
read -r -p 'Método: ' method
case "$method" in
  1)
    echo 'Conecte ambas Mac con cable USB/USB-C/Thunderbolt de datos compatible.'
    echo 'En OBJETIVO: mantener encendido > Opciones > Continuar; autenticar si se solicita.'
    echo 'Utilidades > Compartir disco > seleccionar volumen > Iniciar uso compartido.'
    echo 'En HOST: Finder > Red > Mac objetivo > Conectar como > Invitado > Conectar.'
    echo 'Un recurso compartido no es un disco físico local; puede no aparecer en diskutil.'
    /usr/bin/open 'https://support.apple.com/guide/mac-help/mchl82829c17/mac'
    /usr/bin/open 'network:///'
    ;;
  2)
    echo 'Conecte con cable Thunderbolt compatible.'
    echo 'En OBJETIVO Intel: encender manteniendo T; abrir el disco en Finder del HOST.'
    echo 'Si está cifrado, desbloquear con credenciales autorizadas en Finder.'
    /usr/bin/open 'https://support.apple.com/guide/mac-help/mchlp1443/mac'
    ;;
  3) echo 'Conecte la unidad y abra el volumen en Finder; desbloquee si está cifrado.' ;;
  4)
    if [ -x "$HELPER" ]; then
      "$HELPER" dfu > "$REPORT/dfu-candidates.json" || echo 'Detección USB no disponible.'
    fi
    echo 'Confirme el objetivo en Finder. Revive puede recuperar firmware conservando datos; no extrae archivos.'
    echo 'Restore BORRA datos. Si necesita recuperarlos, no lo ejecute como paso de lectura.'
    /usr/bin/open 'https://support.apple.com/en-us/108900'
    echo 'Resultado: sólo DFU, lectura no disponible.' >> "$REPORT/access.txt"
    printf 'Informe: %s\n' "$REPORT"
    exit 0
    ;;
  *) fail 'Método inválido.' ;;
esac
printf 'Método declarado por operador: %s\n' "$method" >> "$REPORT/access.txt"
read -r -p 'Cuando termine la conexión en Finder, pulse Enter: ' ignored
# La enumeración no establece automáticamente a qué Mac pertenece cada unidad.
/usr/sbin/diskutil list > "$REPORT/disks.txt" || echo 'Inventario diskutil no disponible.'
/sbin/mount > "$REPORT/mounts.txt" || echo 'Inventario de montajes no disponible.'
echo 'Volúmenes visibles (incluyen los del HOST; identifique el objetivo):'
/bin/ls -1 /Volumes
echo '1 Abrir volumen en Finder; 2 Copiar carpeta de documentos; 3 Sólo inventario'
read -r -p 'Acción: ' action
case "$action" in
  3) printf 'Informe: %s\n' "$REPORT"; exit 0 ;;
  1|2) ;;
  *) fail 'Acción inválida.' ;;
esac
read -r -p 'Ruta existente del volumen/carpeta objetivo, sin comillas (/Volumes/...): ' source_path
case "$source_path" in /Volumes/*) ;; *) fail 'Seleccione una ruta bajo /Volumes.' ;; esac
[ -d "$source_path" ] && [ ! -L "$source_path" ] || fail 'Ruta no disponible o enlace simbólico.'
resolved="$(cd "$source_path" && pwd -P)"
case "$resolved" in /Volumes/*) ;; *) fail 'La ruta resuelve fuera de /Volumes.' ;; esac
confirm "LEER OBJETIVO $resolved"
printf 'Ruta seleccionada por operador: %s\n' "$resolved" >> "$REPORT/access.txt"
echo 'No se cambia el modo de montaje. Finder/SMB pueden permitir escritura; no es adquisición forense.'
if [ "$action" = 1 ]; then
  /usr/bin/open -a Finder "$resolved"
  echo 'Finder abierto; esto no demuestra que los archivos sean legibles.' >> "$REPORT/access.txt"
else
  read -r -p 'Carpeta existente de destino para respaldo (ruta absoluta, sin comillas): ' destination
  /bin/bash "$ROOT/scripts/backup-files.sh" "$resolved" "$destination"
  echo 'Copia terminada; integridad y restauración pendientes.' >> "$REPORT/access.txt"
fi
echo 'Al terminar: expulsar volumen en Finder; en Apple Silicon detener Compartir disco.'
echo 'Si hay fallos de lectura o daño físico, detener y priorizar recuperación especializada.'
printf 'Informe: %s\n' "$REPORT"
