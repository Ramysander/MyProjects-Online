#!/bin/bash
source "$(dirname "$0")/common.sh"
[ "${EUID}" -ne 0 ] || fail 'Ejecutar en la sesión gráfica del propietario, no con sudo.'

printf '%s\n' '=== MacTech IT — Full Factory Reset ==='
printf '%s\n' 'Este flujo actúa exclusivamente sobre ESTA Mac.'
printf '%s\n' 'No borra automáticamente el disco de arranque: delega el borrado al mecanismo oficial de Apple.'
printf '%s\n\n' 'ADVERTENCIA: el proceso oficial eliminará cuentas, datos, apps instaladas y configuración local.'

set +e
/bin/bash "$(dirname "$0")/factory-reset-precheck.sh"
precheck=$?
set -e

if [ "$precheck" -ne 0 ]; then
  printf '\n%s\n' 'MacTech IT no confirma elegibilidad para Erase All Content and Settings.'
  printf '%s\n' 'Ruta segura alternativa: iniciar macOS Recovery, borrar con Disk Utility y reinstalar macOS siguiendo Apple Support.'
  printf '%s\n' 'No se ejecutará diskutil eraseDisk ni un borrado automático del disco interno.'
  exit 2
fi

printf '\n%s\n' 'ANTES DE CONTINUAR:'
printf '%s\n' '1. Verifique que el respaldo necesario existe y puede restaurarse.'
printf '%s\n' '2. Conecte el adaptador de corriente en un MacBook.'
printf '%s\n' '3. Confirme acceso a Internet y las credenciales requeridas por Apple.'
printf '%s\n' '4. Si es Apple silicon con macOS 26+ y fue reparada, compruebe Repair Assistant.'
printf '%s\n\n' 'MacTech IT abrirá Erase Assistant; Apple realizará autenticación y la confirmación final.'
confirm 'ERASE THIS MAC'

assistant='/System/Library/CoreServices/Erase Assistant.app'
[ -d "$assistant" ] || fail 'Erase Assistant dejó de estar disponible. Cancelado sin borrar datos.'
/usr/bin/open "$assistant" || fail 'No se pudo abrir Erase Assistant. No se inició ningún borrado.'
printf '%s\n' 'Erase Assistant abierto. Complete o cancele el procedimiento únicamente en la interfaz oficial de Apple.'
