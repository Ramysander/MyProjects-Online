#!/bin/bash
# Asistente supervisado; no afirma diagnosticar a distancia la placa/SSD.
source "$(dirname "$0")/common.sh"
[ "$EUID" -ne 0 ] || fail 'Ejecutar sin sudo en la Mac técnica.'
[ -t 0 ] || fail 'Abra este asistente en Terminal.'
new_report
printf 'MacTech Recovery 0.3\nUTC: %s\n' "$(date -u)" > "$REPORT/recovery.txt"
echo 'MAC OBJETIVO: MacBook averiada. HOST: esta Mac técnica.'
echo '1 Apple Silicon; 2 Intel T2; 3 Intel sin T2; 4 Desconocida'
read -r -p 'Familia del OBJETIVO: ' family
case "$family" in 1|2|3|4) ;; *) fail 'Selección inválida.' ;; esac
echo '1 Sin señales de encendido; 2 Firmware/pantalla negra; 3 Sistema no arranca'
read -r -p 'Síntoma del OBJETIVO: ' symptom
case "$symptom" in 1|2|3) ;; *) fail 'Selección inválida.' ;; esac
printf 'Familia declarada: %s\nSíntoma declarado: %s\n' "$family" "$symptom" >> "$REPORT/recovery.txt"
if [ "$symptom" = 1 ]; then
  echo 'Compruebe cargador compatible, cable y enchufe. Desconecte accesorios.'
  echo 'Mantenga encendido unos 10 segundos; después pulse normalmente.'
  /usr/bin/open 'https://support.apple.com/en-us/102623'
  echo 'Si no responde ni aparece en DFU con conexión correcta, requiere diagnóstico físico.'
  echo '1 Continuar con intento DFU supervisado; 2 Detener para servicio físico'
  read -r -p '> ' next
  case "$next" in
    1) ;;
    2) echo 'Resultado: derivado a diagnóstico físico, sin firmware ejecutado.' >> "$REPORT/recovery.txt"; exit 0 ;;
    *) fail 'Selección inválida.' ;;
  esac
fi
system_recovery() {
  echo 'En la Mac OBJETIVO apagada:'
  case "$family" in
    1) echo 'Mantenga encendido hasta Opciones > Continuar.' ;;
    2|3) echo 'Encienda y mantenga Command-R para Recovery. Internet Recovery depende del modelo.' ;;
    4) echo 'Identifique la familia antes de elegir combinación de arranque.' ;;
  esac
  echo 'En Recovery: respaldo si es posible; Disk Utility > First Aid; reinstalar macOS SIN borrar.'
  echo 'Si el disco falla físicamente o contiene datos irremplazables, detener reparación y priorizar recuperación de datos.'
  echo 'No ejecutar comandos de reparación del HOST pensando que actúan sobre el objetivo.'
  /usr/bin/open 'https://support.apple.com/en-us/102518'
  /usr/bin/open 'https://support.apple.com/en-us/102655'
  echo 'Procedimiento: macOS Recovery guiado; no instalación ejecutada por el host.' >> "$REPORT/recovery.txt"
}
if [ "$symptom" = 3 ]; then
  system_recovery
else
  case "$family" in
    3) echo 'Esta familia no admite el DFU Mac T2/Apple Silicon. Utilice Recovery.'; system_recovery ;;
    4) fail 'Identifique modelo/chip antes de intentar firmware. Informe parcial guardado.' ;;
    1|2)
      major="$(/usr/bin/sw_vers -productVersion | /usr/bin/cut -d. -f1)"
      [ "$major" -ge 14 ] || fail 'El procedimiento Finder necesita host macOS 14+. Actualice/use otro host.'
      echo 'Ambas Mac conectadas a alimentación. Host con Internet y espacio suficiente (Apple indica 32 GB como margen).'
      /bin/df -h / >> "$REPORT/recovery.txt"
      echo 'Cable USB-C de datos y carga, conexión directa al puerto DFU exacto del modelo. No cable Thunderbolt 3.'
      /usr/bin/open 'https://support.apple.com/en-us/108900'
      echo 'Apague OBJETIVO manteniendo encendido hasta 10 s.'
      echo 'Pulse y suelte encendido; inmediatamente mantenga Control izquierdo + Option izquierdo + Shift derecho + encendido.'
      if [ "$family" = 1 ]; then
        echo 'Mantenga cuatro teclas ~10 s; suelte tres y conserve encendido hasta 10 s más, hasta DFU en Finder.'
      else
        echo 'Mantenga cuatro teclas ~3 s, hasta DFU en Finder. Si pide permitir accesorio, siga la guía Apple.'
      fi
      echo 'La pantalla del objetivo debe permanecer vacía. Confirme Mac DFU Mode en Finder.'
      if [ -x "$HELPER" ]; then
        "$HELPER" dfu > "$REPORT/usb-candidates.json" || echo 'No disponible: detección USB' >> "$REPORT/recovery.txt"
      else
        echo 'Helper ausente: comprobar DFU visualmente en Finder.'
      fi
      /usr/bin/open -a Finder
      echo 'En Finder seleccione Mac en Ubicaciones. No se selecciona ni inicia firmware automáticamente.'
      confirm 'MAC OBJETIVO EN DFU VERIFICADA EN FINDER'
      echo '1 Revive en Finder (recomendado); 2 Adaptador cfgutil experimental ya validado en laboratorio'
      read -r -p '> ' backend
      case "$backend" in
        1)
          echo 'Seleccione Revive Mac > Continue en la ventana DFU. Mantenga el host despierto y no desconecte.'
          echo 'Procedimiento: Revive supervisado por Finder; resultado aún no comprobado.' >> "$REPORT/recovery.txt"
          read -r -p 'Cuando haya terminado el procedimiento, pulse Enter para registrar el resultado: ' ignored
          ;;
        2)
          read -r -p 'ECID exacto verificado del objetivo: ' ecid
          rc=0
          /bin/bash "$ROOT/scripts/dfu.sh" revive "$ecid" || rc=$?
          printf 'cfgutil exit: %s (no demuestra arranque correcto)\n' "$rc" >> "$REPORT/recovery.txt"
          ;;
        *) fail 'Selección inválida.' ;;
      esac
      ;;
  esac
fi
echo 'Resultado observado POR EL OPERADOR:'
echo '1 Arranca; 2 Entra a Recovery, sistema pendiente; 3 Sigue fallando; 4 Pausado/no verificado'
read -r -p '> ' outcome
case "$outcome" in 1|2|3|4) ;; *) fail 'Resultado inválido.' ;; esac
printf 'Resultado declarado por operador: %s\nNo certificado ni diagnóstico automático.\n' "$outcome" >> "$REPORT/recovery.txt"
if [ "$outcome" = 2 ]; then system_recovery; fi
if [ "$outcome" = 3 ]; then
  echo 'Revise cable, puerto, alimentación y el error oficial. No se cambia automáticamente a Restore.'
  echo 'Restore borra datos; si se decide usarlo, abra la herramienta Restore separada tras autorización del propietario.'
fi
printf 'Informe: %s\n' "$REPORT"
