#!/bin/bash
# Guided DFU entry assistant. It intentionally does NOT claim to force DFU in software.
source "$(dirname "$0")/common.sh"
job_lock
echo 'MacTech IT — Entrar/Reiniciar en modo DFU'
echo
echo 'IMPORTANTE: DFU es un estado de firmware. En Mac/iPhone/iPad compatibles normalmente requiere una secuencia física exacta de botones/teclas y un host conectado.'
echo 'Esta herramienta NO falsifica un reinicio a DFU ni ejecuta Restore/Erase.'
echo
printf 'Tipo de objetivo: [1] Mac Apple silicon/T2  [2] iPhone/iPad  [3] Cancelar\n> '
IFS= read -r choice
case "$choice" in
  1)
    echo 'Conecte la Mac objetivo a otra Mac host usando el puerto/cable compatible indicado por Apple.'
    echo 'Abra Apple Configurator/Finder y siga la secuencia DFU específica del modelo. La pantalla del objetivo puede permanecer negra.'
    /usr/bin/open 'https://support.apple.com/en-us/108900' || true
    /usr/bin/open -a 'Apple Configurator' || true
    ;;
  2)
    echo 'Conecte el iPhone/iPad por cable. Use la secuencia física correspondiente al modelo para Recovery/DFU.'
    echo 'Finder puede detectar Recovery. DFU profundo no ofrece acceso a archivos y Restore puede borrar datos.'
    /usr/bin/open 'https://support.apple.com/en-us/118106' || true
    /usr/bin/open -a Finder || true
    ;;
  *) echo 'Cancelado.'; exit 0 ;;
esac
echo
echo 'Después de completar la secuencia física, vuelva a MacTech IT y ejecute Auto-detectar USB/Thunderbolt/DFU.'
echo 'No se ha borrado, restaurado, revivido ni reiniciado automáticamente ningún dispositivo.'
