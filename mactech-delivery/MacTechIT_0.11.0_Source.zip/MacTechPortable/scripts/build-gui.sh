#!/bin/bash
source "$(dirname "$0")/common.sh"
/bin/bash "$ROOT/scripts/build.sh"
build_dir="${MACTECH_BUILD_DIR:-$ROOT/dist}"
[[ "$build_dir" = /* ]] || fail 'Build directory must be absolute.'
app="$build_dir/MacTech IT.app"
[ ! -e "$app" ] || fail 'Ya existe dist/MacTech IT.app; muévala antes de reconstruir.'
mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources/toolkit"
for arch in arm64 x86_64; do
  /usr/bin/xcrun swiftc -O -parse-as-library -target "$arch-apple-macos12.0" \
    "$ROOT/GUI/MacTechIT.swift" "$ROOT/GUI/SnippetsView.swift" "$ROOT/GUI/IOSSupportView.swift" "$ROOT/GUI/ExpertWorkbenchView.swift" "$ROOT/GUI/MacBookSupportView.swift" "$ROOT/Sources/SupportCore.swift" "$ROOT/Sources/SnippetCore.swift" "$ROOT/Sources/MacBookCore.swift" -o "$ROOT/bin/gui-$arch"
done
/usr/bin/lipo -create "$ROOT/bin/gui-arm64" "$ROOT/bin/gui-x86_64" -output "$app/Contents/MacOS/MacTechIT"
for folder in scripts launchers docs; do
  /usr/bin/ditto "$ROOT/$folder" "$app/Contents/Resources/toolkit/$folder"
done
mkdir -p "$app/Contents/Resources/toolkit/bin"
/usr/bin/ditto "$ROOT/bin/macprobe" "$app/Contents/Resources/toolkit/bin/macprobe"
/usr/bin/ditto "$ROOT/bin/caseengine" "$app/Contents/Resources/toolkit/bin/caseengine"
/usr/bin/ditto "$ROOT/GUI/Info.plist" "$app/Contents/Info.plist"
/usr/bin/codesign --force --sign - "$app/Contents/Resources/toolkit/bin/macprobe"
/usr/bin/codesign --force --sign - "$app/Contents/Resources/toolkit/bin/caseengine"
/usr/bin/codesign --force --sign - "$app"
echo "Creada: $app"
echo 'Firma ad hoc local: no sustituye Developer ID ni notarización para distribución.'
