#!/bin/bash
source "$(dirname "$0")/common.sh"
need_helper
[ "$#" -ge 1 ] && [ "$#" -le 2 ] || fail 'Uso: erase-external.sh diskN [APFS|ExFAT]'
format="${2:-APFS}"
case "$format" in APFS|ExFAT) ;; *) fail 'Formato no permitido.' ;; esac
disk="$1"
# Plan visible. No root para inspección. Nunca aceptar /dev/disk0 por defecto.
before="$("$HELPER" guard-disk "$disk" "$ROOT")"
printf '%s\n' "$before"
echo 'Destruye TODAS las particiones del disco. No certifica sanitización del SSD.'
echo "Formato: $format; esquema: GPT"
confirm "BORRAR $disk"
/usr/bin/sudo -v
# No repetir el borrado: sólo reintentos acotados del desmontaje normal.
for attempt in 1 2 3; do
  [ "$("$HELPER" guard-disk "$disk" "$ROOT")" = "$before" ] || fail 'Cambió el dispositivo.'
  if /usr/bin/sudo /usr/sbin/diskutil unmountDisk "$disk"; then break; fi
  [ "$attempt" = 3 ] || /bin/sleep 2
done
# Fuerza sólo tras decisión explícita. No actúa sobre el disco anfitrión.
if ! /usr/bin/sudo /usr/sbin/diskutil unmountDisk "$disk"; then
  confirm "FORZAR DESMONTAJE $disk"
  /usr/bin/sudo /usr/sbin/diskutil unmountDisk force "$disk"
fi
[ "$("$HELPER" guard-disk "$disk" "$ROOT")" = "$before" ] || fail 'Cambió el dispositivo.'
/usr/bin/sudo /usr/sbin/diskutil eraseDisk "$format" TechnicalData GPT "$disk"
/usr/sbin/diskutil list "$disk"
# Verificación de mapa. APFS de datos no equivale a instalación de macOS.
/usr/sbin/diskutil verifyDisk "$disk"
