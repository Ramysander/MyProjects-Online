#!/bin/bash
source "$(dirname "$0")/common.sh"
[ -t 0 ] || fail 'Abrir expediente en Terminal.'
new_report
echo 'No introducir PIN, contraseñas, claves de recuperación ni datos personales innecesarios.'
printf 'Expediente iOS/iPadOS 0.7.0\nUTC: %s\nDatos declarados por operador, no sensores automáticos.\n' "$(date -u)" > "$REPORT/ios-case.txt"
for label in 'Identificador interno del caso' 'Modelo y versión' 'Síntoma' 'Observaciones ANTES' 'Acción realizada y error observado' 'Observaciones DESPUÉS' 'Resultado: resuelto/pendiente/derivado'; do
  IFS= read -r -p "$label: " value
  [ "${#value}" -le 4000 ] || fail 'Campo demasiado largo.'
  printf '%s: %s\n' "$label" "$value" >> "$REPORT/ios-case.txt"
done
printf 'Expediente: %s\n' "$REPORT"
