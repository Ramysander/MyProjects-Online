#!/bin/bash
# Compatible con Bash 3.2 del sistema. Sin eval, sin contraseñas en argumentos.
set -euo pipefail
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
umask 077
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
[ "$(uname -s)" = Darwin ] || { echo 'Requiere macOS.' >&2; exit 1; }
HELPER="$ROOT/bin/macprobe"
fail() { echo "$*" >&2; exit 1; }
confirm() {
  [ -t 0 ] || fail 'Se requiere una terminal interactiva.'
  printf 'Escriba exactamente: %s\n> ' "$1"
  IFS= read -r reply
  [ "$reply" = "$1" ] || fail 'Cancelado.'
}
need_helper() { [ -x "$HELPER" ] || fail 'Falta bin/macprobe. Compilar en la Mac de desarrollo.'; }
new_report() {
  local base="${MACTECH_REPORTS:-$ROOT/reports}"
  [[ "$base" = /* ]] || fail 'Destino de informes debe ser absoluto.'
  [ -d "$base" ] && [ ! -L "$base" ] && [ -w "$base" ] || fail 'Destino de informes inválido o no escribible.'
  REPORT="$(mktemp -d "$base/run-$(date -u +%Y%m%dT%H%M%SZ)-XXXXXX")"
}
# Exclusión por usuario para scripts operativos, compartida entre ventanas/Terminal.
# Un trabajo anidado sólo reutiliza el lock si su propietario es ancestro vivo.
job_lock() {
  local lock="/tmp/mactech-job-$EUID" owner="${MACTECH_LOCK_OWNER:-}"
  if [ -n "$owner" ] && [[ "$owner" =~ ^[0-9]+$ ]] && [ "${MACTECH_LOCK_PARENT:-}" = "$PPID" ] && [ -d "$lock" ] && [ ! -L "$lock" ] && [ "$(/bin/cat "$lock/owner" 2>/dev/null)" = "$owner" ]; then
    export MACTECH_LOCK_PARENT="$$"
    return
  fi
  if ! /bin/mkdir -m 700 "$lock" 2>/dev/null; then
    fail "Otro trabajo tiene el bloqueo $lock. No se elimina ni mata automáticamente; comprobar proceso propietario."
  fi
  printf '%s\n' "$$" > "$lock/owner"
  export MACTECH_LOCK_OWNER="$$"
  export MACTECH_LOCK_PARENT="$$"
  MACTECH_OWN_LOCK="$lock"
  release_job_lock() {
    if [ -n "${MACTECH_OWN_LOCK:-}" ] && [ -d "$MACTECH_OWN_LOCK" ] && [ ! -L "$MACTECH_OWN_LOCK" ] && [ "$(/bin/cat "$MACTECH_OWN_LOCK/owner" 2>/dev/null)" = "$$" ]; then
      /bin/rm "$MACTECH_OWN_LOCK/owner"
      /bin/rmdir "$MACTECH_OWN_LOCK"
    fi
  }
  trap release_job_lock EXIT
  trap 'exit 130' INT
  trap 'exit 143' TERM
}
case "$(basename "$0")" in build*.sh|Build*.command) ;; *) job_lock ;; esac
