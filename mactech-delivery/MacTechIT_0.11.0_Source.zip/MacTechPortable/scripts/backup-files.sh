#!/bin/bash
source "$(dirname "$0")/common.sh"
[ "$EUID" -ne 0 ] || fail 'Ejecutar sin sudo.'
[ "$#" = 2 ] || fail 'Uso: backup-files.sh CARPETA_ORIGEN CARPETA_DESTINO'
[[ "$1" = /* ]] && [[ "$2" = /* ]] || fail 'Se requieren rutas absolutas.'
[ -d "$1" ] && [ ! -L "$1" ] && [ -d "$2" ] && [ ! -L "$2" ] || fail 'Carpetas existentes, sin enlaces simbólicos.'
src="$(cd "$1" && pwd -P)"; dest="$(cd "$2" && pwd -P)"
case "$src" in /|/System|/System/*|/Library|/private|/private/*|/Volumes) fail 'Seleccione una carpeta de documentos.' ;; esac
case "$dest/" in "$src/"*) fail 'El destino no puede estar dentro del origen.' ;; esac
confirm 'COPIAR DOCUMENTOS A RESPALDO'
backup="$(mktemp -d "$dest/MacTech-backup-XXXXXX")"
# No sincroniza ni borra el destino. Permisos/TCC y archivos abiertos pueden afectar la copia.
if ! /usr/bin/ditto "$src" "$backup/files"; then
  echo "Copia INCOMPLETA: $backup" >&2; exit 1
fi
printf 'Origen: %s\nFecha UTC: %s\nEstado: copia terminada; integridad y restauración pendientes\n' "$src" "$(date -u)" > "$backup/INFO.txt"
echo "Copia: $backup. Verifique los archivos y pruebe restauración. No es imagen del sistema."
