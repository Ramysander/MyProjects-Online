#!/bin/bash
# Constructor en macOS: app universal + imagen de distribución, sin instalar en el cliente.
source "$(dirname "$0")/common.sh"
[ "$EUID" -ne 0 ] || fail 'Construir como usuario normal.'
/usr/bin/xcrun --sdk macosx --show-sdk-path >/dev/null || fail 'Falta el SDK macOS de Command Line Tools/Xcode.'
/usr/bin/xcrun --find swiftc >/dev/null || fail 'Instale Command Line Tools antes de construir.'
[ -x /usr/bin/hdiutil ] || fail 'Falta hdiutil de macOS.'
mkdir -p "$ROOT/dist"
version="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$ROOT/GUI/Info.plist")"
[[ "$version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || fail 'Versión de aplicación inválida.'
output="$ROOT/dist/MacTech_IT_v$version.dmg"
[ ! -e "$output" ] || fail 'Ya existe el DMG; muévalo antes de construir otro.'
# Directorio único por construcción: conserva resultados anteriores sin borrarlos.
build_dir="$(mktemp -d "$ROOT/dist/build-XXXXXX")"
MACTECH_BUILD_DIR="$build_dir" /bin/bash "$ROOT/scripts/build-gui.sh"
app="$build_dir/MacTech IT.app"
[ -x "$app/Contents/MacOS/MacTechIT" ] || fail 'No se produjo la aplicación.'
[ -x "$app/Contents/Resources/toolkit/bin/macprobe" ] || fail 'Falta helper.'
/usr/bin/codesign --verify --deep --strict --verbose=2 "$app"
/usr/bin/lipo "$app/Contents/MacOS/MacTechIT" -verify_arch arm64 x86_64
/usr/bin/lipo "$app/Contents/Resources/toolkit/bin/macprobe" -verify_arch arm64 x86_64
/usr/bin/lipo "$app/Contents/Resources/toolkit/bin/caseengine" -verify_arch arm64 x86_64
# Se conserva staging para inspección, dentro de este directorio de build.
staging="$build_dir/image"
mkdir "$staging"
/usr/bin/ditto "$app" "$staging/MacTech IT.app"
/bin/ln -s /Applications "$staging/Applications"
/bin/cp "$ROOT/docs/DMG_QUICKSTART.txt" "$staging/LEER_PRIMERO.txt"
/usr/bin/hdiutil create -volname 'MacTech IT' -srcfolder "$staging" -format UDZO "$output"
/usr/bin/hdiutil verify "$output"
/usr/bin/shasum -a 256 "$output" > "$output.sha256"
printf '\nDMG generado: %s\nAPP generada: %s\n' "$output" "$app"
echo 'Firma ad hoc: para distribución pública falta Developer ID y notarización.'
echo 'Pruebe abrir la app y cada módulo en una Mac antes de distribuir.'
