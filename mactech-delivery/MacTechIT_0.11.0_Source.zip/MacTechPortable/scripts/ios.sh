#!/bin/bash
# Backend iOS: inventario real del host y flujos oficiales supervisados.
source "$(dirname "$0")/common.sh"
[ "$#" = 1 ] || fail 'Uso: ios.sh inventory|connect|backup|update|recovery|restore|health|security|files|configurator'
mode="$1"
case "$mode" in inventory|connect|backup|update|recovery|restore|health|security|files|configurator) ;; *) fail 'Acción iOS no permitida.' ;; esac
new_report
cfg=/usr/local/bin/cfgutil
printf 'Soporte iOS/iPadOS 0.7.0\nAcción: %s\nUTC: %s\n' "$mode" "$(date -u)" > "$REPORT/ios.txt"
exec > >(/usr/bin/tee -a "$REPORT/ios.txt") 2>&1
echo 'HOST: esta Mac. OBJETIVO: iPhone/iPad seleccionado por el operador.'
echo 'No se capturan contraseñas. No se ejecuta borrado ni actualización automática.'
case "$mode" in
  inventory)
    /usr/bin/sw_vers
    if /usr/sbin/system_profiler SPUSBDataType -json > "$REPORT/usb-host.json"; then
      echo 'Inventario USB del HOST guardado (puede incluir seriales de otros accesorios).'
    else echo 'Inventario USB no disponible.'; fi
    if [ -x "$cfg" ]; then
      if "$cfg" list > "$REPORT/configurator-devices.txt" 2>&1; then
        /bin/cat "$REPORT/configurator-devices.txt"
      else echo 'cfgutil list falló: revise cable, confianza, modo y versión local.'; fi
    else echo 'cfgutil no instalado: usar Finder o instalar Automation Tools desde Configurator.'; fi
    echo 'Una lista vacía no demuestra ausencia de dispositivo ni identifica su estado de salud.'
    ;;
  connect)
    echo 'Conectar por cable de datos; desbloquear iPhone/iPad; seleccionar dispositivo en Finder.'
    echo 'Aceptar Confiar en ambos equipos con autorización del propietario.'
    /usr/bin/open -a Finder
    /usr/bin/open 'https://support.apple.com/en-us/109054'
    ;;
  backup)
    echo 'Finder > dispositivo > General > respaldar todos los datos en esta Mac > Cifrar respaldo local.'
    echo 'Guardar contraseña fuera del informe; Respaldar ahora; comprobar fecha y Administrar respaldos.'
    echo 'Restaurar una copia se realiza en Finder; confirmar objetivo y compatibilidad antes de proceder.'
    /usr/bin/open -a Finder
    /usr/bin/open 'https://support.apple.com/en-us/108796'
    ;;
  update)
    echo 'Respaldar primero. Finder > objetivo > General > Buscar actualización > seguir indicaciones.'
    /usr/bin/open -a Finder
    /usr/bin/open 'https://support.apple.com/en-us/109046'
    ;;
  recovery)
    echo 'Identificar modelo y seguir la combinación exacta de botones de Apple.'
    echo 'En Finder intentar Actualizar primero; Restaurar borra datos. No se fuerza DFU por comandos.'
    echo 'DFU/Recovery no ofrecen acceso al SSD ni extracción de archivos.'
    /usr/bin/open -a Finder
    /usr/bin/open 'https://support.apple.com/en-us/118106'
    /usr/bin/open 'https://support.apple.com/en-us/108925'
    ;;
  restore)
    echo 'RESTAURAR BORRA DATOS. Respaldar si es posible y verificar propietario/objetivo.'
    echo 'Finder > dispositivo > General > Restaurar. Confirmar en Finder; no se pulsa automáticamente.'
    echo 'Activation Lock y la reinscripción MDM pueden permanecer tras restaurar.'
    /usr/bin/open -a Finder
    /usr/bin/open 'https://support.apple.com/en-us/118107'
    ;;
  health)
    echo 'En el OBJETIVO: Ajustes > General > Información; registrar modelo y versión.'
    echo 'Ajustes > Batería: uso y salud/ciclos sólo si el modelo ofrece esos campos.'
    echo 'Ajustes > General > Almacenamiento del iPhone/iPad: registrar capacidad y espacio.'
    echo 'Comprobar carga, cable, temperatura anormal, reinicios, pantalla y conectividad.'
    echo 'Liberar espacio desde Ajustes; sin limpieza global de cachés desde la Mac.'
    echo 'No hay SMART, temperatura universal o lectura de ciclos garantizada mediante este módulo.'
    ;;
  security)
    echo 'En el OBJETIVO: revisar actualización del sistema y permisos en Privacidad y seguridad.'
    echo 'General > VPN y gestión de dispositivos: documentar perfiles; no retirar gestión sin autorización.'
    echo 'Comprobar Wi-Fi, DNS/VPN configurados y conectividad en el propio dispositivo.'
    echo 'Pruebas de red en la Mac miden el HOST, no el iPhone. No se diagnostica malware automáticamente.'
    ;;
  files)
    echo 'Finder > objetivo > Archivos: sólo documentos de aplicaciones que admiten compartir archivos.'
    echo 'No montar el iPhone con diskutil. Datos cifrados requieren desbloqueo y confianza.'
    echo 'Para evidencias: propietario exporta registros desde Privacidad y seguridad > Análisis y mejoras > Datos del análisis.'
    echo 'Los registros pueden contener información privada; copiar sólo los necesarios al expediente.'
    /usr/bin/open -a Finder
    /usr/bin/open 'https://support.apple.com/en-us/119585'
    ;;
  configurator)
    if [ -x "$cfg" ]; then
      "$cfg" help > "$REPORT/cfgutil-help.txt" 2>&1 || echo 'Ayuda cfgutil no disponible.'
      echo 'Ayuda local guardada: validar capacidades y requisitos de la versión instalada.'
    else echo 'Instalar Apple Configurator y sus Automation Tools para usar cfgutil.'; fi
    /usr/bin/open -a 'Apple Configurator' || echo 'Apple Configurator no se pudo abrir.'
    /usr/bin/open 'https://support.apple.com/guide/apple-configurator-mac/welcome/mac'
    echo 'Seleccionar explícitamente el iPhone/iPad. Supervisión, perfiles y despliegue se realizan allí.'
    ;;
esac
echo 'Estado: inventario/guía generado; operación sobre el dispositivo pendiente de verificación.'
printf 'Informe: %s\n' "$REPORT"
