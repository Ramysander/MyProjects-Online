#!/bin/bash
source "$(dirname "$0")/common.sh"
need_helper
# Ruta explícita y confiable, nunca descubrir ejecutables en carpetas arbitrarias.
cfg=/usr/local/bin/cfgutil
mode="${1:-watch}"
case "$mode" in
  watch)
    # Detecta candidatos USB. No confundir un candidato con una Mac verificada.
    for tick in $(/usr/bin/jot 60); do
      "$HELPER" dfu
      /bin/sleep 2
    done
    ;;
  inventory)
    [ -x "$cfg" ] || fail 'Instale Automation Tools desde Apple Configurator.'
    "$cfg" help
    "$cfg" list
    ;;
  revive|restore)
    [ "$#" = 2 ] || fail 'Uso: dfu.sh revive|restore ECID'
    ecid="$2"
    [[ "$ecid" =~ ^(0[xX])?[0-9a-fA-F]+$ ]] || fail 'ECID inválido.'
    [ -x "$cfg" ] || fail 'Falta cfgutil. Alternativa oficial: Finder.'
    # Adaptador condicionado: validar soporte de Mac y --ecid en la versión local.
    "$cfg" help
    "$cfg" help "$mode"
    "$cfg" list
    echo 'Verifique en Finder/Configurator: Mac en DFU, ECID exacto y un único objetivo.'
    echo 'La existencia de un comando no demuestra compatibilidad con este modelo.'
    [ "$mode" != restore ] || echo 'RESTORE BORRA EL EQUIPO OBJETIVO.'
    confirm "MAC DFU VALIDADA $mode $ecid"
    # Un solo intento; no cambiar automáticamente Revive por Restore.
    /usr/bin/caffeinate -i "$cfg" --ecid "$ecid" "$mode"
    ;;
  *) fail 'Uso: dfu.sh watch|inventory|revive ECID|restore ECID' ;;
esac
