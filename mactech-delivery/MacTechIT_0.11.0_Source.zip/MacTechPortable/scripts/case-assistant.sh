#!/bin/bash
source "$(dirname "$0")/common.sh"
[ -t 0 ] || fail 'Abrir en Terminal.'
engine="$ROOT/bin/caseengine"
[ -x "$engine" ] || fail 'Falta caseengine; reconstruya con build-gui.sh.'
echo '1 Nuevo expediente; 2 Abrir expediente existente'
read -r -p '> ' action
case "$action" in
  1)
    read -r -p 'Carpeta BASE existente y escribible (ruta absoluta): ' base
    [[ "$base" = /* ]] && [ -d "$base" ] && [ ! -L "$base" ] || fail 'Base inválida.'
    read -r -p 'Nombre/modelo del equipo (sin contraseñas): ' asset
    [ -n "$asset" ] || fail 'Equipo requerido.'
    echo 'Síntoma: slow (lenta), network (red), startup (no arranca)'
    read -r -p '> ' symptom
    folder="$("$engine" new "$base" "$asset" "$symptom")"
    ;;
  2) read -r -p 'Carpeta del expediente (ruta absoluta): ' folder ;;
  *) fail 'Selección inválida.' ;;
esac
[[ "$folder" = /* ]] && [ -d "$folder" ] && [ ! -L "$folder" ] || fail 'Expediente inválido.'
echo 'Las capturas miden ESTA Mac, no el objetivo DFU. No capturar el host como si fuera otro equipo.'
while true; do
  echo '1 Antes; 2 Después; 3 Anotar intervención; 4 Informe/comparación; 5 Imprimir/guardar PDF; 6 Salir'
  read -r -p '> ' choice
  case "$choice" in
    1) "$engine" capture "$folder" before ;;
    2) "$engine" capture "$folder" after ;;
    3) read -r -p 'Intervención/resultado observado: ' note; "$engine" note "$folder" "$note" ;;
    4) "$engine" report "$folder"; /usr/bin/open "$folder/report.html" ;;
    5) "$engine" print "$folder" ;;
    6) echo "Expediente: $folder"; break ;;
    *) echo 'Opción inválida.' ;;
  esac
done
