#!/bin/bash
source "$(dirname "$0")/common.sh"
# No rm -rf en /System, /Library ni ~/Library. Limpieza del SO: flujo nativo.
[ "${EUID}" -ne 0 ] || fail 'Ejecutar como usuario normal.'
echo 'Para problemas de cachés del sistema: iniciar en modo seguro y reiniciar normalmente.'
echo 'No existe reparación global de permisos del sistema moderno con repairPermissions.'
/usr/bin/open -a 'Disk Utility'
