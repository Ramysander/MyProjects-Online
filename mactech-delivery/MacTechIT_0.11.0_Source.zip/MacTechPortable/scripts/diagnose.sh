#!/bin/bash
source "$(dirname "$0")/common.sh"
new_report
printf 'module\texit_code\tfile\n' > "$REPORT/status.tsv"
# Cada proveedor conserva su estado de salida; ausencia de datos no significa sano.
collect() {
  local name="$1"; shift
  local rc=0
  "$@" > "$REPORT/$name.txt" 2>&1 || rc=$?
  printf '%s\t%s\t%s.txt\n' "$name" "$rc" "$name" >> "$REPORT/status.tsv"
}
collect os /usr/bin/sw_vers
collect cpu /usr/sbin/sysctl -n machdep.cpu.brand_string
collect hardware /usr/sbin/system_profiler SPHardwareDataType
collect battery /usr/sbin/system_profiler SPPowerDataType
collect battery_registry /usr/sbin/ioreg -r -c AppleSmartBattery -l
collect storage /usr/sbin/system_profiler SPNVMeDataType SPSerialATADataType SPStorageDataType
collect t2 /usr/sbin/system_profiler SPiBridgeDataType
collect disks /usr/sbin/diskutil list -plist
collect apfs /usr/sbin/diskutil apfs list -plist
collect filevault /usr/bin/fdesetup status
collect sip /usr/bin/csrutil status
collect thermal /usr/bin/pmset -g therm
collect boot_info /usr/sbin/bless --info /
if [ -x "$HELPER" ]; then collect public_power "$HELPER" power; fi
source "$(dirname "$0")/diagnostic-summary.sh"
summary_init
summary_collection_status
summary_security
summary_battery
summary_finish
printf 'Informe: %s\n' "$REPORT"
echo 'Datos sensibles: seriales, UUID y nombres de volúmenes. Revise antes de compartir.'
