#!/bin/bash
# Desmontaje supervisado de disco físico externo, con las mismas protecciones del borrado.
source "$(dirname "$0")/common.sh"
need_helper
[ "$#" -ge 1 ] && [ "$#" -le 2 ] || fail 'Uso: unmount-external.sh diskN [normal|force]'
disk="$1"
mode="${2:-normal}"
case "$mode" in normal|force) ;; *) fail 'Modo no permitido.' ;; esac
before="$("$HELPER" guard-disk "$disk" "$ROOT")"
printf '%s\n' "$before"
echo 'Cierre aplicaciones que usen esta unidad. El desmontaje forzado puede perder escrituras pendientes.'
confirm "DESMONTAR $disk $mode"
/usr/bin/sudo -v
[ "$("$HELPER" guard-disk "$disk" "$ROOT")" = "$before" ] || fail 'Cambió el dispositivo.'
if [ "$mode" = force ]; then
  /usr/bin/sudo /usr/sbin/diskutil unmountDisk force "$disk"
else
  /usr/bin/sudo /usr/sbin/diskutil unmountDisk "$disk"
fi
