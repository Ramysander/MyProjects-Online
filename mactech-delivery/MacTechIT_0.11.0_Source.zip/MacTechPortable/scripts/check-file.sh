#!/bin/bash
source "$(dirname "$0")/common.sh"
[ "$#" -ge 1 ] && [ "$#" -le 2 ] || fail 'Uso: check-file.sh /ruta/archivo [SHA256 esperado]'
file="$1"
[[ "$file" = /* ]] && [ -f "$file" ] && [ ! -L "$file" ] || fail 'Archivo regular absoluto requerido.'
new_report
/usr/bin/shasum -a 256 "$file" > "$REPORT/sha256.txt"
actual="$(/usr/bin/cut -c1-64 "$REPORT/sha256.txt")"
printf 'SHA-256: %s\n' "$actual"
if [ "$#" = 2 ]; then
  [[ "$2" =~ ^[0-9a-fA-F]{64}$ ]] || fail 'SHA256 esperado inválido.'
  expected="$(printf '%s' "$2" | /usr/bin/tr 'A-F' 'a-f')"
  [ "$actual" = "$expected" ] || fail 'NO COINCIDE.'
  echo 'COINCIDE con el hash proporcionado.'
fi
# Comparar hash no demuestra confianza si se desconoce el origen del hash.
printf 'Informe: %s\n' "$REPORT"
