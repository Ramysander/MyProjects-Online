#!/bin/bash
source "$(dirname "$0")/common.sh"
[ "$EUID" -ne 0 ] || fail 'Ejecutar como usuario normal, sin sudo.'
[ "$#" = 1 ] || fail 'Uso: cache-user.sh com.fabricante.aplicacion'
bundle="$1"
[[ "$bundle" =~ ^[A-Za-z0-9_-]+(\.[A-Za-z0-9_-]+)+$ ]] || fail 'Bundle ID inválido.'
base="$HOME/Library/Caches"
source_cache="$base/$bundle"
[ -d "$base" ] && [ ! -L "$HOME/Library" ] && [ ! -L "$base" ] || fail 'Ruta de cachés inválida.'
[ -d "$source_cache" ] && [ ! -L "$source_cache" ] || fail 'Caché inexistente o enlace simbólico.'
echo 'Cierre la aplicación antes de continuar. Se moverá a cuarentena; no libera espacio todavía.'
/usr/bin/du -sh "$source_cache"
confirm "CUARENTENA $bundle"
quarantine="$(mktemp -d "$base/MacTech-quarantine-XXXXXX")"
/bin/mv "$source_cache" "$quarantine/"
printf 'Cuarentena: %s\n' "$quarantine"
echo 'Restaurar con la aplicación cerrada y sin otra carpeta del mismo nombre; revisar antes de eliminar.'
