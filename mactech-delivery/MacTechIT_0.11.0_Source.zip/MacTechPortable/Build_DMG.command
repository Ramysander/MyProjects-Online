#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
log="$ROOT/BUILD_DMG_LOG.txt"
rc=0
/bin/bash "$ROOT/scripts/build-dmg.sh" > "$log" 2>&1 || rc=$?
/bin/cat "$log"
if [ "$rc" -eq 0 ]; then
  if [ -t 0 ]; then
    /usr/bin/open "$ROOT/dist" || echo 'DMG generado; no se pudo abrir Finder.'
  fi
else
  echo 'Construcción fallida. Consulte BUILD_DMG_LOG.txt; no se garantiza un DMG válido.'
fi
# No bloquear Codex/CI ni convertir éxito en fallo por EOF de stdin.
if [ -t 0 ]; then
  read -r -p 'Pulse Enter para cerrar: ' ignored || true
fi
exit "$rc"
