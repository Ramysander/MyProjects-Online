#!/usr/bin/env python3
"""Static checks only. Never imports or runs operational backend scripts."""
import json
import plistlib
import re
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
scripts = sorted((root / 'scripts').glob('*.sh'))
scripts += sorted((root / 'launchers').glob('*.command'))
scripts += sorted(root.glob('*.command'))
for script in scripts:
    subprocess.run(['/bin/bash', '-n', str(script)], check=True)
print(f'PASS Bash syntax: {len(scripts)} scripts')
with (root / 'GUI/Info.plist').open('rb') as stream:
    info = plistlib.load(stream)
version = info['CFBundleShortVersionString']
assert re.fullmatch(r'\d+\.\d+\.\d+', version)
assert info['CFBundleExecutable'] == 'MacTechIT'
assert info['LSMinimumSystemVersion'] == '12.0'
for filename in ['AGENTS.md', 'docs/PROJECT_STATUS.md', 'GUI/MacTechIT.swift']:
    assert version in (root / filename).read_text(), f'Stale version: {filename}'
items = json.loads((root / 'docs/snippets.json').read_text())
assert len(items) == len({item['id'] for item in items})
for item in items:
    assert item['kind'] in {'none', 'host', 'disk', 'wholeDisk', 'volume', 'bundle', 'file', 'app', 'interface', 'service'}
    assert item['risk'] in {'Lectura', 'Supervisado', 'Modifica', 'Destructivo'}
    assert not any(ord(c) < 32 for c in item['command'])
    assert set(re.findall(r'\{\{(.*?)\}\}', item['command'])) <= {'target', 'toolkit'}
    for relative in re.findall(r'\{\{toolkit\}\}/([A-Za-z0-9_./-]+)', item['command']):
        assert (root / relative).is_file(), relative
builder = (root / 'scripts/build-gui.sh').read_text()
for path in (root / 'GUI').glob('*.swift'):
    assert path.name in builder, f'GUI file omitted from build: {path.name}'
    for name in re.findall(r'script: "([^"\n]+)"', path.read_text()):
        folder = 'launchers' if name.endswith('.command') else 'scripts'
        assert (root / folder / name).is_file(), name
for name in ['build.sh', 'build-gui.sh']:
    assert 'SupportCore.swift' in (root / 'scripts' / name).read_text()
assert 'SnippetCore.swift' in builder and 'MacBookCore.swift' in builder
assert 'SnippetCore.swift' in (root / 'scripts/build.sh').read_text()
assert 'try supportCoreSelfTest()' in (root / 'Sources/CaseEngine.swift').read_text()
assert 'parse-inventory' in (root / 'scripts/external-device-detect.sh').read_text()
dmg_builder = (root / 'scripts/build-dmg.sh').read_text()
assert 'CFBundleShortVersionString' in dmg_builder
assert 'MacTech_IT_v$version.dmg' in dmg_builder
assert 'mkdir -p "$ROOT/bin"' in (root / 'scripts/build.sh').read_text()
print(f'PASS plist/version {version}, {len(items)} snippets, GUI resources and build references')
print('NOT RUN: Swift build, caseengine selftest, codesign, lipo, hdiutil and device workflows')
