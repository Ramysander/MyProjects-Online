#!/usr/bin/env python3
"""Optional Swift grammar/structure inspection; not a compiler or type checker.
Dependencies: tree-sitter==0.25.2, tree-sitter-swift==0.7.4.
Never executes Swift or device commands.
"""
from pathlib import Path
from tree_sitter import Language, Parser
import tree_sitter_swift

root = Path(__file__).resolve().parents[1]
parser = Parser(Language(tree_sitter_swift.language()))
containers = ('VStack', 'HStack', 'Group', 'HSplitView', 'ZStack', 'ScrollView', 'TabView')
count = 0
for path in [*(root / 'GUI').glob('*.swift'), *(root / 'Sources').glob('*.swift')]:
    data = path.read_bytes()
    tree = parser.parse(data)
    assert not tree.root_node.has_error, path.name
    def walk(node):
        global count
        if node.type == 'call_expression' and data[node.start_byte:node.end_byte].decode().startswith(containers):
            for child in node.named_children:
                if child.type != 'call_suffix':
                    continue
                for part in child.named_children:
                    if part.type != 'lambda_literal':
                        continue
                    for body in part.named_children:
                        if body.type == 'statements':
                            count += 1
                            assert len(body.named_children) <= 10, (path.name, node.start_point, len(body.named_children))
        for child in node.children:
            walk(child)
    walk(tree.root_node)
    print('PASS Swift grammar:', path.name)
print(f'PASS {count} inspected container blocks <=10 statements')
print('NOT RUN: swiftc, type checking, platform availability or SwiftUI runtime')
