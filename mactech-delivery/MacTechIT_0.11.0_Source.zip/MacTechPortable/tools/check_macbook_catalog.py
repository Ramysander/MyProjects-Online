#!/usr/bin/env python3
"""Inspect catalogs and test literal shell arguments only; never run a snippet."""
import json
import re
import shlex
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
items = json.loads((root / 'docs/snippets.json').read_text())
expert = [item for item in items if item['collection'] == 'macOS experto']
expected = {'Inventario y batería', 'Discos y APFS', 'Seguridad', 'Red y DNS',
            'Rendimiento y procesos', 'Registros y servicios', 'Respaldos',
            'Firma de aplicaciones', 'Recuperación y firmware'}
assert {item['category'] for item in expert} == expected
assert len({item['id'] for item in items}) == len(items)
samples = {'none': '', 'host': 'support.example.com', 'disk': 'disk9s2',
           'wholeDisk': 'disk9', 'volume': 'disk9s2', 'bundle': 'com.example.app',
           'file': "/tmp/O'Brien $(not_executed) {{toolkit}} file", 'app': "/tmp/O'Brien $(not_executed) {{toolkit}}.app",
           'interface': 'en0', 'service': 'Wi-Fi laboratory'}
kit = "/tmp/MacTech O'Brien $(not_executed)"
wrappers = {'cache-user.sh', 'apfs.sh', 'erase-external.sh', 'unmount-external.sh', 'ios.sh'}
for item in items:
    for field in ['requirements', 'compatibility', 'interpretation', 'parameterHint', 'reference', 'executables']:
        assert item[field], (item['id'], field)
    assert item['reference'].startswith('https://')
    assert all(path.startswith('/') for path in item['executables'])
    if item['risk'] in {'Modifica', 'Destructivo'}:
        match = re.match(r'^/bin/bash \{\{toolkit\}\}/scripts/([\w-]+\.sh)(?: |$)', item['command'])
        assert match and match[1] in wrappers, item['id']
    substitutions = {'target': samples[item['kind']], 'toolkit': kit}
    command = re.sub(r'\{\{(target|toolkit)\}\}', lambda match: shlex.quote(substitutions[match[1]]), item['command'])
    assert '\n' not in command and '\r' not in command
    subprocess.run(['/bin/bash', '-n'], input=command, text=True, check=True, capture_output=True)
    words = shlex.split(command)
    if '{{target}}' in item['command']:
        assert samples[item['kind']] in words, (item['id'], words)
    for relative in re.findall(r'\{\{toolkit\}\}/([A-Za-z0-9_./-]+)', item['command']):
        assert (root / relative).is_file(), relative
# Check shell quoting by roundtripping synthetic strings through printf alone.
for value in ["O'Brien", '$(never_run); id', '{{toolkit}}', 'Wi-Fi laboratory', 'a&b']:
    result = subprocess.run(['/bin/bash', '-c', 'printf %s ' + shlex.quote(value)], check=True, capture_output=True, text=True)
    assert result.stdout == value
core = (root / 'Sources/MacBookCore.swift').read_text()
ids = re.findall(r'MacBookAction\(id: "([^"]+)"', core)
known = set(re.findall(r'Tool\(id: "([^"]+)"', (root / 'GUI/MacTechIT.swift').read_text()))
assert len(ids) == len(set(ids)) and set(ids) <= known
assert '"revive"' not in ids and '"restore"' not in ids
assert 'Button("Macbook")' in (root / 'GUI/MacTechIT.swift').read_text()
for filename in ['build.sh', 'build-gui.sh']:
    source = (root / 'scripts' / filename).read_text()
    assert 'SnippetCore.swift' in source and 'MacBookCore.swift' in source
assert 'MacBookSupportView.swift' in (root / 'scripts/build-gui.sh').read_text()
print(f'PASS {len(expert)} macOS snippets / {len(items)} total; 9 categories; all rendered commands pass bash -n')
print(f'PASS literal parameters (apostrophes, substitutions, braces, spaces); {len(ids)} reused MacBook actions and build integration')
print('NOT RUN: native macOS commands, Swift selftests, GUI, drag/drop or device operations')
