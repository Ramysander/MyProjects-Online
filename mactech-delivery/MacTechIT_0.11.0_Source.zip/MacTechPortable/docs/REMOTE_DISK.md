# Leer disco de otra Mac — 0.7.0

Abrir Recuperación > Leer disco de otra Mac. Elegir carpeta existente de informes y método. Apple Silicon: Recovery > Utilidades > Compartir disco; en host Finder > Red > objetivo > Conectar como > Invitado. Intel: cable Thunderbolt y encendido manteniendo T. Unidad externa: conectar y montar con Finder. FileVault requiere credenciales legítimas.

Tras conectar, el asistente guarda diskutil list y mount (pueden contener nombres privados). Enumera /Volumes y permite elegir una ruta existente para abrir en Finder o copiar documentos usando el módulo de respaldo. El operador identifica el objetivo: no se atribuyen automáticamente discos al equipo remoto. Recursos SMB no aparecen necesariamente como discos en diskutil.

DFU no expone datos. La rama DFU guarda candidatos USB cuando el helper está disponible y abre la guía Apple. No inicia Revive ni Restore. Recovery debe arrancar para Compartir disco. El módulo no recupera datos de chips dañados ni elude cifrado. No es adquisición forense: no impone sólo lectura al montaje y Finder/SMB pueden escribir metadatos. No ejecuta programas de la unidad; revisar archivos copiados antes de abrirlos si se sospecha malware.

Copias: elegir carpeta de documentos bajo /Volumes y destino existente fuera del origen. Sin borrado del destino, no imagen del sistema; verificar restauración. Al finalizar expulsar en Finder y detener Compartir disco en el objetivo.

Fuentes oficiales:
https://support.apple.com/guide/mac-help/mchl82829c17/mac
https://support.apple.com/guide/mac-help/mchlp1443/mac
https://support.apple.com/en-us/108900

Construcción: /bin/bash Build_DMG.command; resultado esperado dist/MacTech_IT_v0.7.0.dmg. Compilación y conexión reales pendientes de validación en macOS.
