# AGENTS.md — MacTech IT

## Build and validation rules
- Read `docs/PROJECT_STATUS.md` before changing code.
- Build/package only on macOS with Apple Command Line Tools available.
- Do not run operational scripts against real Macs, iPhones, iPads, external disks, APFS volumes, DFU targets, or user data during build verification.
- Safe verification is limited to source inspection, shell syntax checks, Swift compilation, `caseengine selftest`, app packaging, code-sign verification, architecture verification, DMG creation/verification, and SHA-256 generation.
- Never bypass confirmations or device/target validation to make a test pass.
- Do not use `sudo` for the build.
- Treat DFU/restore/erase/repair/factory-reset/unmount and device-management flows as manual/lab-only tests.
- Stop on the first build/test failure and fix the cause rather than disabling a check.

## Expected build
Run from the project root on macOS:

```bash
/bin/bash Build_DMG.command
```

Expected artifacts:
- `dist/MacTech_IT_v0.8.0.dmg`
- `dist/MacTech_IT_v0.8.0.dmg.sha256`
- a build-specific `MacTech IT.app` under `dist/build-XXXXXX/`
