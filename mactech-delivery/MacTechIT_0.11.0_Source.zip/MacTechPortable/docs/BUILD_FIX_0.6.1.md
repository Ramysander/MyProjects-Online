# Corrección de compilación 0.7.0

El registro recibido confirma que los helpers se compilaron y caseengine selftest pasó. La interfaz falló con `extra arguments at positions #11, #12, #13 in call`: el ViewBuilder disponible sólo aceptaba diez vistas directas y el VStack principal contenía trece.

Se agruparon seis elementos de cabecera/detalle en Group. El VStack principal queda con ocho elementos directos; el Group contiene seis. No se eliminaron controles ni se cambió el flujo de herramientas. Se actualizó versión y nombre del DMG para evitar confusión con paquetes anteriores.

Uso: descomprimir en una carpeta NUEVA, conservar la carpeta anterior con sus informes, y ejecutar `/bin/bash Build_DMG.command` desde la nueva MacTechPortable. No mezclar fuentes de versiones diferentes. El resultado esperado es dist/MacTech_IT_v0.7.0.dmg.

Validación local: sintaxis Bash, plist, integridad y extracción del ZIP. No hay SDK macOS en este entorno: la nueva GUI necesita recompilación en la Mac del usuario. Si aparece otro error, enviar el nuevo BUILD_DMG_LOG.txt.
