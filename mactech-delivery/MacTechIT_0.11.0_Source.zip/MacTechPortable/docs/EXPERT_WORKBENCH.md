# Centro TI experto — 0.10.0

## Usar el panel
1. Compile en una Mac con Command Line Tools: `/bin/bash Build_DMG.command`.
2. Abra MacTech IT.app y pulse **Centro TI**, o **Centro TI / expedientes** en el módulo iPhone/iPad.
3. En **Dependencias**, compruebe qué ejecutables están disponibles. Configurator CLI es opcional; su presencia no verifica soporte Restore/Revive para un modelo.
4. En **Dispositivos**, pulse **Escanear conexiones**. La consulta lee system_profiler de la Mac técnica. No cambia modos ni desbloquea dispositivos. Algunos equipos/periféricos pueden no publicar datos en estas fuentes.
5. Confirme candidatos DFU/Recovery en Finder/Configurator antes de usar los asistentes existentes. DFU no expone archivos de usuario.
6. En **Expediente**, seleccione Mac/iPhone/iPad e identifique manualmente el equipo. Escriba síntoma, antes, intervención y después. Declare el resultado; las notas no equivalen a mediciones automáticas.
7. Si interesa, adjunte el inventario desde Dispositivos. Incluye fecha y todos los registros observados; no vincula automáticamente un periférico al equipo del expediente.
8. **Guardar revisión** crea JSON y HTML bajo `unified-cases/case-UUID` en el destino de informes de la ventana principal. Cada guardado conserva las revisiones anteriores. **Mostrar archivos** abre la carpeta.
9. **Abrir JSON** importa un expediente de este módulo, con límite de 2 MB. Los expedientes del asistente antiguo tienen otro esquema.
10. **Imprimir / PDF** abre el diálogo nativo: PDF > Guardar como PDF. Revise el documento y el destino. No se guarda PDF automáticamente.

Guarde antes de cerrar o cambiar de expediente. El borrador vive en memoria; no hay autoguardado. Los expedientes pueden contener datos personales; no registre secretos. JSON/HTML no están cifrados. Las carpetas creadas usan permisos 700 y los archivos 600; unidades sin permisos POSIX pueden no aplicar estas restricciones.

## Verificación de desarrollo
`python3 tools/check_source.py` sólo revisa fuentes. En macOS, `Build_DMG.command` compila ambas arquitecturas y ejecuta `caseengine selftest`, incluyendo fixtures del parser compartido. No ejecutar scans, reparaciones ni restauraciones durante estas verificaciones.

Pruebas manuales pendientes: GUI Intel/Apple silicon, inventario real en distintas versiones de macOS, importación/exportación y PDF de varias páginas. No se certifica compilación ni funcionamiento de dispositivos desde Linux.


### Ajustes de esta revisión
El panel solicita confirmación al cerrar, abrir o crear un expediente sólo si el borrador difiere del estado inicial, importado o guardado. Los cambios de plataforma, resultado e inventario también cuentan. No hay autoguardado.

Una respuesta JSON sin fuentes de inventario o con listas malformadas se presenta como inventario no disponible; una lista válida vacía conserva el aviso de que no descarta un equipo conectado. Los fixtures correspondientes requieren ejecutar el selftest en macOS.


## Seguimiento y cierre profesional
En **Seguimiento**, indique ticket, técnico, prioridad y, opcionalmente, fecha objetivo. Registre cada intervención en la bitácora y pulse **Añadir entrada** antes de guardar. La nota aún no añadida no forma parte del informe y bloquea guardar/imprimir hasta incorporarla o vaciarla.

El checklist registra declaraciones del técnico sobre autorización, respaldo, verificación y entrega. Si el respaldo no aplica, documente el motivo. Para guardar **Resuelto**, complete también equipo, síntoma, intervención y después; el panel muestra los pendientes. Puede guardar estados Pendiente/Parcial/Escalado sin completar el cierre. Un expediente antiguo Resuelto puede abrirse, pero debe completar estos campos antes de guardar una nueva revisión.

## Biblioteca y CSV
Seleccione la carpeta de informes en la ventana principal; abra **Biblioteca** y pulse **Actualizar**. Busque por ticket, técnico, equipo, síntoma, plataforma o ID; filtre por resultado. Cada fila es una revisión, no necesariamente un expediente distinto. Se muestran revisiones de la carpeta actual únicamente; actualizar no combina otras carpetas. Abrir pide confirmación si hay cambios sin guardar.

La fecha objetivo vencida es un aviso local para estados no resueltos. La lista se ordena por fecha de actualización declarada. Para limitar uso de memoria, la carga se detiene al alcanzar 500 revisiones, 32 MB de JSON o 5.000 entradas; indica si el listado es parcial y cuenta rechazos/errores. La selección limitada no garantiza incluir los expedientes más recientes de toda la carpeta. Divida archivos históricos en otra carpeta si necesita gestionar más volumen.

**Exportar CSV filtrado** exporta las filas visibles, con identificador, ticket, equipo, plataforma, técnico, prioridad, resultado, fechas y nombre de revisión. No exporta las notas detalladas. Campos con comillas/comas/saltos se escapan; posibles fórmulas reciben un prefijo de texto. Proteja el CSV como cualquier informe con datos personales.

## Paquetes e integridad
Cada nuevo guardado crea `unified-cases/case-UUID/revision-UUID/`, con JSON, HTML y `.sha256`. Conserve el paquete completo si necesita verificar ambos archivos. La publicación se hace renombrando una carpeta oculta sólo después de completar todos los archivos. Un error puede dejar una carpeta `.pending-*` para inspección; la biblioteca la omite.

**Verificar integridad** compara JSON y HTML con el manifiesto SHA-256. Abrir/importar comprueba el JSON si existe su manifiesto adyacente. Documentos antiguos o JSON copiados solos se pueden abrir sin checksum; no tienen integridad comprobada. El manifiesto no está firmado: cambiarlo o quitarlo puede eludir la comprobación. La bitácora es editable por quien tenga acceso al archivo; no acredita autoría ni constituye evidencia forense inmutable.

Los JSON mantienen esquema 1 con extensión opcional `professional`. 0.10.0 importa archivos 0.9.0; versiones anteriores pueden ignorar y perder la extensión si vuelven a guardarlos. Guarde siempre el original. No hay cifrado, sincronización multiusuario ni control de roles.
