# Construir y verificar 0.8.2 en tu Mac

Esta entrega es código fuente, no un DMG compilado. El entorno de revisión es Linux y no puede acceder a tu Mac.

Descomprimir en una carpeta nueva, conservar informes y builds anteriores. Abrir Terminal en MacTechPortable y ejecutar:

```bash
/bin/bash Build_DMG.command
```

El script comprueba SDK/compilador, construye universal, ejecuta caseengine selftest, verifica firmas/arquitecturas, crea/verifica DMG y genera SHA-256. Se detiene ante fallo. No usar sudo.

Resultado esperado: dist/MacTech_IT_v0.8.2.dmg y .dmg.sha256. El registro está en BUILD_DMG_LOG.txt. Desde Codex o CI sin Terminal interactiva, el constructor no abre Finder ni espera Enter; conserva el código de salida real.

Verificación estática opcional durante desarrollo: python3 tools/check_source.py (Python 3 requerido sólo para esta comprobación).

Para probar la interfaz, abrir la app y revisar navegación/snippets sin ejecutar tareas sobre dispositivos. Guardar el registro de construcción real. No considerar una comprobación estática como prueba de compilación o compatibilidad de hardware.
