# Snippets de discos y USB — 0.7.0

Siete comandos en la categoría Discos y USB: identificar, inspeccionar, desmontar, forzar desmontaje, borrar APFS/GPT, borrar ExFAT/GPT y verificar mapa. Listar el resultado sigue disponible en Listar discos.

Los comandos modificadores aparecen al activar Mostrar comandos que modifican el equipo. Seleccionar un snippet, escribir diskN, aceptar la casilla, copiar o arrastrar a Terminal y pulsar Enter. Los wrappers vuelven a validar el disco y requieren confirmación escrita. No elegir un disco por número sin inspeccionarlo; puede cambiar al reconectar.

Los wrappers rechazan discos internos, virtuales y discos que alojan el anfitrión o la herramienta. No hacen reintentos de borrado ilimitados, no eluden Activation Lock/FileVault, no reparan fallos físicos ni certifican sanitización SSD o eliminación de amenazas del firmware.

Recompilar: /bin/bash Build_DMG.command desde la carpeta nueva. Resultado esperado dist/MacTech_IT_v0.7.0.dmg. Conservar informes anteriores. Compilación macOS pendiente.
