# MacTech IT 0.7.1 — corrección funcional de diagnósticos

Esta revisión corrige la experiencia en la que los módulos terminaban con código 0 pero no mostraban una conclusión útil.

## Cambios
- `scripts/diagnostic-summary.sh`: interpretación conservadora PASS/WARNING/FAIL/UNKNOWN/UNAVAILABLE/COLLECTED.
- `diagnose.sh` e `it.sh`: generan y muestran `summary.txt` al terminar.
- La GUI crea por defecto `~/Documents/MacTech IT Reports`.
- Botón `Abrir último resultado` para abrir directamente el directorio de la última ejecución.
- Se mantiene la salida cruda y `status.tsv` para auditoría.
- No se automatizan operaciones destructivas ni acciones sobre iPhone/iPad.

## Compilar en macOS
Desde la raíz:

    /bin/bash Build_DMG.command

Resultado esperado: `dist/MacTech_IT_v0.7.1.dmg` y su SHA-256.

## Prueba segura recomendada
Ejecutar Diagnóstico hardware, Postura de seguridad y Rendimiento. Verificar que la ventana muestre el resumen y que `summary.txt` exista. No usar Repair, Erase, Restore, Factory Reset ni DFU como parte de esta validación.
