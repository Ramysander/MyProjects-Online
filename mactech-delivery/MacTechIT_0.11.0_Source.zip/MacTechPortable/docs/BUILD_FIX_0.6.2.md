# Corrección de empaquetado 0.7.0

El registro del usuario confirma compilación de GUI y helpers, selftest y verificación codesign correctos. El fallo posterior era el orden de argumentos de lipo: el archivo debe ir antes de -verify_arch, porque esa opción consume la lista de arquitecturas.

Se corrigen ambas invocaciones y se añade verificación universal de caseengine. La advertencia launchApplication obsoleto no provoca este fallo.

Descomprimir en carpeta nueva y ejecutar /bin/bash Build_DMG.command. Resultado esperado: dist/MacTech_IT_v0.7.0.dmg. Conservar informes anteriores.

Esta corrección se valida con sintaxis Bash y simulación del flujo de empaquetado, incluyendo rutas con espacios. No se ha ejecutado hdiutil ni compilado en este entorno Linux; el DMG real debe generarse y comprobarse en macOS.
