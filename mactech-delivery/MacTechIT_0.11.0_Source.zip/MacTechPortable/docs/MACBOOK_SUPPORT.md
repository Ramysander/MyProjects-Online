# Macbook — soporte MacBook Air / MacBook Pro (0.11.0)

## Abrir y elegir el equipo
Pulse **Macbook**, junto a **iPhone / iPad** en la parte superior derecha. El panel usa el mismo Runner y los mismos informes que la ventana principal. **Cerrar** cierra el panel, no cancela un trabajo iniciado ni cierra Terminal.

Elija **ESTA Mac anfitriona** o **MacBook objetivo conectada**. La familia Air/Pro y la identificación son declaraciones del técnico, no detección automática. Si ESTA Mac es un escritorio, las consultas seguirán siendo del escritorio: no las atribuya a la MacBook elegida. Verifique el modelo en el inventario antes de registrar el expediente.

Para un objetivo conectado introduzca una identificación manual sin contraseñas. No hay diagnóstico remoto de batería, ciclos, CPU, memoria, FileVault o sensores mediante USB/DFU. Las consultas locales se deshabilitan en ese ámbito. Una enumeración USB puede mostrar candidatos Apple DFU/Recovery, nunca prueba identidad, desbloqueo, confianza, salud ni acceso a datos.

## Categorías

| Categoría | Herramientas reutilizadas y alcance |
| --- | --- |
| Diagnóstico | diagnose.sh e inventario: modelo/chip, macOS, batería/ciclos, almacenamiento, registro de batería y estado térmico publicados por ESTA Mac |
| Seguridad | it.sh security: FileVault, SIP, Gatekeeper, firewall y estado MDM de ESTA Mac; consulta, no modificación |
| Rendimiento | it.sh performance/logs: CPU, memoria, swap, espacio, estado térmico y fallos recientes del anfitrión |
| Red | interfaces, DNS, proxy, rutas y un destino DNS/IPv4 autorizado opcional; cuatro paquetes ping, sin escaneo de subredes |
| Respaldo y recuperación | estado/destinos Time Machine locales; copia supervisada de carpetas accesibles; guía Compartir disco/disco de destino y asistente Recovery |
| Firmware | guía de entrada DFU, consulta de candidatos e inventario Configurator; ruta oficial Revive/Restore según modelo/host |
| Mantenimiento | caché de una aplicación del usuario anfitrión; selección y verificación/reparación APFS supervisadas del volumen accesible |
| Expedientes | asistente con capturas locales del anfitrión y Centro TI con identificación/notas/revisiones/exportación |

Diagnóstico térmico no significa temperatura universal: `pmset` ofrece estados; los sensores y campos del registro varían por modelo/macOS. Datos ausentes o proveedor fallido son desconocidos/no disponibles, no salud positiva. Los informes preservan estados por proveedor.

## Firmware, Recovery y operaciones supervisadas
Revive/Restore oficiales son para Apple silicon o Intel con T2. Intel sin T2 necesita Recovery o servicio. Finder para estos flujos exige macOS 14+ en el anfitrión; compruebe la versión y requisitos vigentes de Apple, cable/puerto, Internet y secuencia física del modelo. Primero Revive; Restore borra el objetivo y requiere respaldo, identificación y confirmación en la herramienta oficial. Abrir la guía **no ejecuta** ninguna de las dos operaciones.

Referencia oficial: https://support.apple.com/108900

El adaptador cfgutil previo sigue experimental y no se ofrece en este panel como función validada. Inventario Configurator requiere sus Automation Tools; su presencia no demuestra soporte de un modelo. El asistente genérico de entrada DFU reutilizado también tiene opciones iPhone/iPad: seleccione sólo **Mac** desde este panel.

Copia, caché, APFS y recuperación reutilizan flujos existentes. Confirme primero el equipo/volumen y luego las frases/diálogos exigidos por cada flujo. Copia de documentos sólo trabaja con carpetas accesibles y no garantiza restaurabilidad. No lee el disco por DFU. Reparación APFS se realiza desde Recovery; la GUI puede no estar disponible allí. No hay borrado directo del disco de arranque ni bypass de autenticación.

## Expedientes y resultados
**Expediente MacBook** reutiliza Centro TI, precarga la identificación declarada y permite notas antes/intervención/después, seguimiento y exportación JSON/HTML/Print-PDF. En ámbito anfitrión puede precargar `summary.txt` del último informe local (hasta 100 KB), marcado **ESTA Mac anfitriona**. En ámbito objetivo nunca incorpora automáticamente el informe del anfitrión; las notas deben identificar su fuente y no ser presentadas como mediciones remotas.

El asistente antiguo de Expedientes captura ESTA Mac y se deshabilita para objetivo conectado. El botón de Centro TI sirve en ambos ámbitos. Verifique fechas, identidad y origen antes de incluir resultados, y redacte datos sensibles. El CSV de Biblioteca exporta metadatos, no las notas completas.

## Exclusión de tareas
Los procesos GUI usan `Runner.busy`. Runner también observa el lock compartido de Terminal y bloquea acciones mientras exista; los scripts mantienen la exclusión autoritativa de `common.sh`. No se elimina un lock ni se mata un proceso automáticamente. Si queda un lock, inspeccione el propietario y resuelva manualmente la causa. Una apertura de Terminal no significa que el flujo terminó. Comandos nativos copiados fuera de la app no participan en ese bloqueo: nunca los solape con mantenimiento/firmware.

## Validación
En Linux sólo se han comprobado fuentes, catálogo, shell quoting, sintaxis Bash y estructura/gramática Swift. No se han ejecutado diagnósticos ni operaciones reales. macOS 12 mínimo de diseño, pendiente de compilación y pruebas GUI en Intel/Apple silicon.

En macOS, desde la raíz: `/bin/bash Build_DMG.command`. Verifique el panel y Snippets con expedientes y rutas sintéticas sin pulsar consultas/operaciones sobre dispositivos. Los nuevos selftests ejecutados por el build usan fixtures puros y validan el catálogo sin ejecutar sus comandos.
