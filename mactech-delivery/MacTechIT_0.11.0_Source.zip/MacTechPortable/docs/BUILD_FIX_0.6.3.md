# Corrección 0.7.0

El ZIP 0.6.2 omitía los directorios vacíos. build.sh asumía que bin ya existía, provocando errno=2 al escribir macprobe-arm64. Ahora crea bin antes de compilar y comprueba su escritura. El ZIP conserva explícitamente los directorios, incluidos bin, reports y dist.

Descomprimir en una carpeta nueva y ejecutar /bin/bash Build_DMG.command. Resultado esperado: dist/MacTech_IT_v0.7.0.dmg.

Validación local: sintaxis Bash, extracción ZIP y prueba del inicio de build.sh con bin ausente y ruta con espacios. El compilador y hdiutil reales requieren macOS.
