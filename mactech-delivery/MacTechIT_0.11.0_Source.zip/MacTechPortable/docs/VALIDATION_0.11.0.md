# Validación 0.11.0 build 18 — 2026-10-07

## Ejecutado sin operaciones sobre dispositivos
- `python3 tools/check_source.py`: PASS 42 scripts con Bash -n; versión 0.11.0, recursos y referencias del build.
- `python3 tools/check_macbook_catalog.py`: PASS 81 entradas (71 macOS, 10 iOS), nueve categorías macOS, campos requeridos, recursos y 17 referencias a Tool existentes. Los 81 comandos renderizados con parámetros sintéticos pasan Bash -n. Roundtrip de entradas con apóstrofes, espacios, sustituciones y marcadores mediante printf únicamente; nunca se ejecuta un snippet.
- `tools/check_swift_structure.py` con tree-sitter 0.25.2/tree-sitter-swift 0.7.4: PASS gramática de diez archivos Swift, 79 bloques de contenedor inspeccionados <=10 elementos directos. No verifica tipos, APIs ni bindings y no sustituye swiftc.
- No se ejecutaron los proveedores nativos, scans, modificaciones de dispositivo, cachés, verificación/reparación APFS, DFU, respaldo de datos reales, restauraciones ni desmontajes.

## Pendiente macOS
- Compilar con `/bin/bash Build_DMG.command`. Ejecuta selftests sintéticos y valida el catálogo real; debe generar app universal, verificar firma y DMG, producir SHA-256.
- Abrir Macbook, comprobar el botón exacto, cierre y las ocho categorías con ambos ámbitos. Diagnósticos y capturas locales no deben habilitarse para objetivo. Elegir Air/Pro no debe presentarse como detección de identidad.
- Confirmar que expediente del objetivo no recibe el resumen del anfitrión; validar notas, JSON/HTML y PDF con datos sintéticos. En host, comprobar etiqueta y origen de resumen precargado.
- Comprobar Snippets: filtros combinados, selección oculta sin comando copiable, revisión de plantilla/comando completo, parámetros inválidos, cambio de parámetro reiniciando confirmación, copia y arrastre a un editor de texto (no ejecutar en Terminal durante la verificación).
- Contrastar opciones nativas en man/ayuda del sistema. La comprobación de ejecutables en GUI sólo indica presencia; permisos, opciones/macOS y compatibilidad no están certificados. Referencias Apple en vivo inaccesibles aquí por proxy 403.
- Verificar que GUI/Terminal comparten el bloqueo sin eliminar locks ni forzar procesos; usar fixtures controlados, no acciones de dispositivos.
- No se entregó un DMG: esta máquina es Linux, sin Swift/SDK Apple. Swift selftests y GUI están NO EJECUTADOS, no aprobados. Developer ID/notarización continúan pendientes para distribución pública.
