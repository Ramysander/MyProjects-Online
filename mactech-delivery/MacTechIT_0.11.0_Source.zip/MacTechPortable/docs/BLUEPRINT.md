# MacTechPortable — arquitectura y código base

Versión de diseño: 0.1, 2 de octubre de 2026. Idioma: español.
Estado: prototipo de código fuente, NO producto certificado ni binario macOS compilado.

## 1. Alcance y límites técnicos

Herramienta de asistencia para equipos propios o autorizados. Ejecutar desde USB/Thunderbolt significa abrir archivos en el macOS anfitrión; NO significa arrancar un sistema operativo desde USB. Diagnosticar otra Mac por DFU no proporciona acceso a su batería, sensores o volumen FileVault. Para esos datos, ejecutar el diagnóstico en esa Mac o usar herramientas de servicio apropiadas.

El requisito «formatear sin importar el estado previo» no es implementable: un SSD averiado, protección de escritura, errores de E/S, firmware dañado o políticas de seguridad pueden impedirlo. Se incluyen reintentos acotados de desmontaje y un desmontaje forzado explícito. No hay fuerza bruta de contraseñas, desbloqueo de FileVault, eliminación de Activation Lock ni desactivación de SIP/Secure Boot. Estos mecanismos no se saltan con `--yes` o `-force`. Esas opciones tampoco son banderas universales de las herramientas de Apple.

El formateo APFS destruye la estructura lógica; no certifica sanitización de NAND. En SSD, las opciones de borrado seguro de Disk Utility no están disponibles. Para una Mac compatible, preferir Erase All Content and Settings. No confundir un volumen APFS de datos con un sistema macOS reinstalado y arrancable.

## 2. Carpetas y responsabilidades

| Ruta | Función |
|---|---|
| `Launch.command` | Iniciar diagnóstico desde Terminal/Finder |
| `scripts/common.sh` | Rutas absolutas, permisos de informes, confirmación y comprobación de macOS |
| `scripts/diagnose.sh` | Recolectar información nativa y guardar códigos de salida |
| `scripts/maintenance.sh` | Derivar mantenimiento del sistema a herramientas oficiales |
| `scripts/cache-user.sh` | Poner en cuarentena una caché concreta del usuario |
| `scripts/apfs.sh` | Verificar un volumen; reparación asistida desde Recovery |
| `scripts/erase-external.sh` | Plan, identificación, desmontaje y formato GPT/APFS de disco externo |
| `scripts/factory-reset.sh` | Abrir el asistente oficial; conservar autenticación del propietario |
| `scripts/dfu.sh` | Detectar candidatos USB e integrar cfgutil bajo validación local |
| `scripts/build.sh` | Compilar helper universal en la Mac de desarrollo |
| `Sources/macprobe.swift` | IOKit, energía pública y lectura de plists de diskutil |
| `bin/` | Binarios compilados; inicialmente vacío |
| `reports/` | Informes locales privados; inicialmente vacío |
| `docs/` | Diseño, pruebas y referencias |

Arquitectura de ejecución: launcher sin privilegios → proveedor de diagnóstico o plan de operación → inspección del objetivo → autorización de la operación → comando nativo → verificación del resultado.

No instalar LaunchDaemon, agente persistente, kext, helper privilegiado ni paquetes en el cliente. Elevar exclusivamente `diskutil` con sudo en el módulo de formato externo; nunca ejecutar toda la herramienta como root. No guardar contraseñas, tokens de iCloud ni recovery keys. El propietario introduce las credenciales en la interfaz oficial.

Una futura interfaz SwiftUI debe mostrar primero el plan: modelo, tamaño, identificador, datos que se pierden y fuente de verificación. Ejecutar trabajos con Process, argumentos separados, lectura asíncrona de stdout/stderr, cancelación para diagnóstico y estados de error explícitos. No cancelar firmware a mitad de operación ni terminar procesos por timeout arbitrario. Añadir un bloqueo de ejecución para impedir operaciones simultáneas sobre el mismo objetivo.

## 3. Portabilidad y dependencias

Diagnóstico Bash: utiliza `/bin/bash` y comandos que ya pertenecen a macOS. No requiere Homebrew, Python, jq ni Swift instalado en el cliente. Swift es sólo una dependencia de compilación: distribuir `bin/macprobe` previamente construido para arm64 y x86_64.

Baseline de diseño: macOS 12 o posterior. Probar explícitamente cada versión/modelo antes de declarar compatibilidad. Finder DFU requiere una segunda Mac con macOS 14 o posterior; Apple advierte que puede ser necesario actualizar el host para el firmware del objetivo. El adaptador cfgutil depende de Apple Configurator y sus Automation Tools en el host técnico. Copiar únicamente cfgutil al USB no garantiza sus frameworks, soporte ni licencia.

Dependencias por operación:

| Operación | Dependencia adicional |
|---|---|
| Lectura nativa | macOS en ejecución; algunas fuentes pueden denegar acceso |
| Helper Swift compilado | IOKit y Foundation del sistema |
| Compilar | Xcode/Command Line Tools en la Mac de desarrollo |
| Formato externo | helper compilado y permisos administrativos |
| Reparación de inicio | macOS Recovery; volumen adecuado y copia de seguridad |
| Reset | Apple Silicon o T2, macOS 12+, sesión y credenciales autorizadas |
| DFU | Segunda Mac, cable/puerto DFU adecuados, alimentación, Internet y espacio |
| cfgutil | Configurator y Automation Tools; soporte comprobado de la versión local |

Preferir APFS para el soporte portable: conserva permisos de ejecutables. Un soporte de sólo lectura puede contener código, pero el módulo de informes actual requiere `reports/` escribible. Una distribución posterior debe permitir un destino externo configurable y separado. Un USB perdido puede revelar seriales y datos de inventario: proteger los informes y controlar su retención.

Gatekeeper puede bloquear una distribución descargada. Preparar firma Developer ID y notarización; no resolverlo desactivando Gatekeeper ni eliminando atributos de cuarentena automáticamente. La construcción universal requiere un SDK con los targets indicados. Firmar el helper y empaquetar la distribución firmada/notarizada según el formato elegido. Este paquete no incluye certificado, firma, notarización ni una aplicación GUI terminada.

## 4. Diagnóstico: significado de las mediciones

`system_profiler SPPowerDataType` proporciona ciclos, condición y capacidad cuando el modelo lo expone. `ioreg AppleSmartBattery` conserva campos crudos para investigación; son detalles dependientes del hardware. No calcular porcentajes comparando unidades de capacidad que pueden no coincidir. La API pública IOPowerSources proporciona estado de energía; no garantiza todos los campos de salud/ciclos.

`pmset -g therm` y `ProcessInfo.thermalState` describen estado térmico, no temperatura exacta de CPU. No hay en esta base una API pública universal para todos los sensores SMC de Intel y Apple Silicon. Añadir un proveedor especializado sólo después de validar hardware/API/licencia, sin inventar temperaturas ni desactivar protecciones. Apple Diagnostics complementa el informe, pero no se presenta como invocable automáticamente por estos scripts.

`system_profiler SPNVMeDataType SPSerialATADataType` registra la información que macOS expone. Para un disco específico usar `diskutil info diskN`, y comprobar si existe SMART Status. Un puente USB puede no pasar SMART. «No soportado» y «desconocido» NO equivalen a «Verified». SMART tampoco predice todos los fallos.

`SPHardwareDataType` permite identificar el chip Apple Silicon, incluyendo familia M1/M2/M3/M4 cuando se reporta. `SPiBridgeDataType` complementa la identificación T2. Presencia del chip no es un test de salud de Secure Enclave. SIP, FileVault y datos de arranque se registran por separado. Activation Lock debe comprobarse con el flujo oficial; no inferir que esté desactivado sólo porque el disco se borró.

`bless --info /` es lectura complementaria y puede fallar según plataforma/volumen. No usar `bless --setBoot`, modificaciones de NVRAM o políticas de arranque como «reparación» universal. En Apple Silicon, un volumen APFS vacío más bless no crea un macOS arrancable.

Los informes tienen un `status.tsv`: código 0 sólo indica éxito del proveedor, no aprobación del hardware. Los informes están limitados por el estado de la sesión; una Mac que no arranca necesita Recovery/DFU, no el diagnóstico del host técnico.

## 5. Mantenimiento y APFS

No existe el antiguo `diskutil repairPermissions` como reparación general del sistema moderno. No aplicar chmod/chown recursivos a /System, /Applications ni /Library. Para permisos de una aplicación concreta, identificar antes el propietario y ACL esperados; el sistema firmado no se repara modificando permisos a ciegas.

Limpieza de cachés del sistema: usar arranque en modo seguro y reinicio normal como flujo de mantenimiento. El módulo no borra globalmente /Library/Caches, /System/Library/Caches ni /private/var/folders. La utilidad de caché del usuario mueve una carpeta elegida a cuarentena, exige cerrar la aplicación y permite restaurarla manualmente. Moverla no libera espacio hasta revisar y eliminar la cuarentena.

Verificar APFS con `diskutil verifyVolume diskNsM`. Reparar desde Recovery con `diskutil repairVolume diskNsM` cuando corresponda. El script de reparación pide confirmación del entorno, pero no demuestra por sí mismo que esté en Recovery. La base no automatiza todo el árbol APFS: para diagnóstico completo seguir First Aid en cada volumen, contenedor y dispositivo. `verifyDisk` verifica el mapa de particiones; no sustituye `verifyVolume`.

Nunca ejecutar fsck_apfs con opciones de escritura sobre un volumen montado. Si la unidad falla físicamente, priorizar respaldo/recuperación y sustitución, no ciclos repetidos de reparación.

## 6. Formato y reintentos

Ejemplo para un disco externo DE PRUEBA:

```bash
/bin/bash scripts/erase-external.sh disk4
```

`disk4` es un ejemplo, nunca un valor predeterminado. El helper exige disco completo, externo y físico; bloquea el disco que contiene `/`, Data y la herramienta. Incluye volúmenes APFS sintetizados asociados a PhysicalStores y rechaza contenedores de múltiples discos. Si un plist cambia de esquema o falta una identidad, aborta.

El plan muestra tamaño, nombre y DeviceTreePath. El operador confirma el disco. Antes de cada intento se vuelve a inspeccionar su identidad. Hay hasta tres intentos de desmontaje normal y un desmontaje forzado sólo si se confirma específicamente. El borrado ocurre una única vez:

```bash
diskutil eraseDisk APFS TechnicalData GPT diskN
```

Esto crea mapa GUID, contenedor APFS y volumen de datos. El script rechaza discos internos aun desde Recovery: un reset interno se deriva al asistente oficial o a la guía Apple de Recovery. Evita destruir particiones de recuperación/firmware de Apple Silicon mediante una receta universal.

Limitación importante: la inspección y el comando diskutil no son una transacción atómica. No desconectar/reconectar unidades ni ejecutar operaciones de disco concurrentes durante el proceso. La identidad usada no es una identidad criptográfica ni autentica un dispositivo USB malicioso. El diseño final necesita bloqueo de trabajos, seguimiento de conexión IOKit y pruebas de desconexión antes de uso en producción.

`unmountDisk force` puede causar pérdida de escrituras pendientes; no desbloquea FileVault ni desvincula una cuenta Apple. No matar procesos arbitrarios ni reiniciar automáticamente para intentar vencer un error. Al fallar, detener, inspeccionar código/error y decidir entre Recovery, soporte o sustitución.

## 7. Full Factory Reset

```bash
/bin/bash scripts/factory-reset.sh
```

Abre Erase Assistant de ESTA Mac. Mantiene diálogos y credenciales. La ruta de la app es un detalle de implementación que debe verificarse por versión; si no está disponible, usar Ajustes del Sistema → General → Transferir o restablecer → Borrar contenidos y ajustes.

No se incluye un comando privado `--yes` de borrado sin credenciales. Para una flota administrada, la arquitectura puede incorporar el comando MDM oficial EraseDevice y el estado de elegibilidad de EACS, mediante un MDM autorizado. Eso necesita inscripción y administración previas, por lo que no satisface un entorno universal sin dependencias. No confundir `cfgutil erase` orientado a dispositivos gestionados con EACS local de cualquier Mac.

En macOS 26+ y Apple Silicon reparado, Apple recomienda comprobar reparaciones pendientes con Repair Assistant antes del borrado. El reset requiere conectividad para activación y puede solicitar cuenta Apple. No garantiza resolver piezas vinculadas a otra cuenta.

## 8. DFU: host y objetivo son máquinas diferentes

La guía actual de Apple utiliza Finder. Requiere una Mac objetivo Apple Silicon/T2, otra Mac con macOS 14+, alimentación y cable USB-C que soporte carga y datos. Apple indica no usar cable Thunderbolt 3 para este procedimiento. Utilizar el puerto DFU específico del modelo y conexión directa. La entrada DFU utiliza una secuencia física dependiente del modelo; este script no fuerza remotamente una Mac cualquiera a entrar en DFU.

`macprobe dfu` enumera dispositivos USB de Apple cuyo nombre contiene DFU. Es detección automática de CANDIDATOS, no identificación definitiva: un iPhone/iPad también puede usar DFU y algunos modelos pueden exponer nombres distintos. No puede determinar una MacBook/ECID autorizado a partir de ese nombre. La siguiente fase debe correlacionar inventario de Configurator, ECID, modelo, conexión y estado DFU. Hasta implementar/verificar ese adaptador, no lanzar restores por un evento de conexión.

```bash
/bin/bash scripts/dfu.sh watch
/bin/bash scripts/dfu.sh inventory
/bin/bash scripts/dfu.sh revive 0xECID_VALIDO
# Restore sólo cuando la operación y el objetivo están verificados:
/bin/bash scripts/dfu.sh restore 0xECID_VALIDO
```

Sustituir `0xECID_VALIDO` por un ECID real; el marcador se rechaza. `watch` toma muestras por 120 segundos; detener con Ctrl-C. El host puede requerir permitir la conexión del accesorio. Verificar también Finder/Configurator.

El adaptador contiene las llamadas candidatas `cfgutil --ecid ECID revive` / `restore`, después de mostrar `cfgutil help`, `cfgutil help OPERACION` e inventario. Su compatibilidad real con Mac y la sintaxis de selección deben comprobarse con la versión instalada. No se ha validado aquí una combinación Configurator/macOS/modelo; que cfgutil anuncie revive/restore no demuestra soporte del objetivo. Si la ayuda o el soporte no coinciden, cancelar y usar Finder. No inventar flags --yes/-force ni redistribuir herramientas privadas.

Revive intenta recuperar firmware sin borrar datos. Restore es destructivo. No escalar automáticamente entre ellos ni realizar reintentos masivos. Tras Restore puede seguir siendo necesaria la cuenta previamente vinculada. Para T2 puede ser necesario reinstalar macOS desde Internet Recovery; no prometer idéntico flujo en todas las familias.

Producción: proveedor versionado de Configurator con parser probado sobre fixtures reales, rechazo de múltiples objetivos y ECID ambiguo, estado DFU confirmado, operación serializada y verificación de salida/reaparición. Alternativa oficial Finder con operador cuando no exista contrato CLI comprobado.

## 9. Seguridad de distribución y validación

No ejecutar scripts de un USB ajeno como administrador. La distribución final debe ser inmutable/firmada y los informes vivir separados. No registrar contraseñas o tokens. Al publicar, añadir hashes del artefacto, control de versiones, notarización y política de retención.

Estado real de estas pruebas: verificación sintáctica Bash en Linux y revisión del código; no se dispone de macOS, Swift SDK, hardware ni cfgutil en este entorno. No se ejecutó ningún borrado, reparación o firmware. `bin/` no contiene un ejecutable compilado. No declarar probado este prototipo en una Mac cliente.

Matriz mínima antes de producción:

1. Compilar Swift arm64/x86_64 y probar APIs/puentes CF con SDK real.
2. Diagnosticar Intel sin T2, Intel T2 y M1/M2/M3/M4, incluyendo escritorio sin batería.
3. Verificar macOS 12/13/14/15/26 donde corresponda; no prometer combinaciones no soportadas por Apple.
4. Registrar SMART desconocido en USB y fallos de permiso como desconocidos.
5. Probar guards con disco de arranque externo, soporte portable APFS, objetivo APFS, múltiples PhysicalStores y cambios de esquema.
6. En discos desechables: confirmar cancelación, desmontaje ocupado, error de E/S y desconexión; comprobar que no se selecciona otro diskN.
7. No probar borrado en la única copia de datos. Validar GPT, APFS y estructura creada.
8. Correlacionar DFU e inventario real cfgutil; rechazar iPhone/iPad, dos objetivos y ECID equivocado.
9. Revive/Restore sobre equipo de laboratorio con recuperación y propietario disponible; confirmar activación posterior.
10. Validar firma/notarización y ejecución desde un USB en host limpio sin Xcode.

## 10. Referencias oficiales consultadas

- Apple, firmware y DFU, publicada 16/06/2026: https://support.apple.com/en-us/108900
- Apple, EACS, publicada 14/09/2026: https://support.apple.com/en-us/102664
- Apple, Activation Lock: https://support.apple.com/en-us/102541
- Apple, First Aid: https://support.apple.com/guide/disk-utility/repair-a-storage-device-dskutl1040/mac
- Apple, formato y límites SSD: https://support.apple.com/en-nz/guide/disk-utility/dskutl14079/mac
- Apple Developer, energía: https://developer.apple.com/documentation/iokit/1523856-iopscopypowersourceslist
- Contratos CLI de la máquina de laboratorio: `man diskutil`, `man bless`, `man system_profiler`, `cfgutil help`, `cfgutil help revive`, `cfgutil help restore`. Guardar versión y ayuda con los resultados de prueba. No se verificó públicamente un contrato completo de cfgutil para todas las Mac solicitadas.
