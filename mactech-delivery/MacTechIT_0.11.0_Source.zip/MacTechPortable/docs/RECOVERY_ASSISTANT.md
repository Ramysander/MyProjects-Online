# Asistente Revivir MacBook — 0.3

Nueva herramienta GUI: **Recuperación → Revivir MacBook — asistente**. Abre un flujo supervisado en Terminal; no es un motor que garantice recuperar cualquier equipo. Las instrucciones se basan en las guías oficiales Apple consultadas el 4 de octubre de 2026 (UTC).

## Tres rutas

| Síntoma declarado | Ruta |
|---|---|
| Sin señales de encendido | Comprobar cargador/cable/enchufe, accesorios y encendido; continuar DFU sólo si procede o derivar a servicio |
| Firmware/pantalla negra | Confirmar familia Apple Silicon/T2; conectar segunda Mac; preparar DFU y Revive en Finder |
| Sistema no arranca | Recovery en el objetivo, First Aid y reinstalar macOS sin borrar; respaldar si es posible |

El síntoma es declarado por el operador: pantalla negra no demuestra fallo de firmware. Intel sin T2 utiliza Recovery y no el procedimiento DFU T2/Apple Silicon. Un objetivo de familia desconocida debe identificarse antes de firmware.

## Ejecutar

En Terminal dentro del paquete:

```bash
/bin/bash scripts/recovery-assistant.sh
```

Para una carpeta externa ya existente:

```bash
MACTECH_REPORTS="/Volumes/SoporteTI/Informes" /bin/bash scripts/recovery-assistant.sh
```

Desde GUI, el launcher pide una carpeta existente y escribible. El asistente conserva un expediente en `recovery.txt`: familia/síntoma declarados, ruta, código de cfgutil si se usa y resultado observado por operador. Si se cancela o falla, puede existir un informe parcial. No confundir un código de salida 0 con recuperación confirmada. USB candidatos no es identificación de Mac ni autorización para Restore.

## Firmware: requisitos y ejecución real

Una Mac objetivo Apple Silicon o T2; otra Mac con macOS 14 o posterior; ambas con alimentación; Internet y espacio suficiente en host. Apple indica 32 GB como margen de descarga. El asistente muestra espacio disponible, pero no demuestra conectividad ni capacidad de descargar firmware. Finder puede solicitar actualizar el host.

Usar cable USB-C con datos/carga directo, no Thunderbolt 3, y el puerto DFU exacto del modelo. Consultar la guía oficial abierta por el asistente. La entrada DFU es física, con teclado integrado. El programa no simula teclas ni incluye macvdmtool.

El asistente abre Finder y requiere confirmación de **Mac DFU Mode** del objetivo. El técnico selecciona **Revive Mac → Continue** en Finder; Finder realiza la recuperación real. El programa no pulsa ese botón ni automatiza la selección del objetivo. Mantener host despierto y conexión hasta terminar. Revive no borra datos; Restore sí.

Se conserva un adaptador opcional cfgutil experimental sólo para combinación ya verificada de versión/modelo y ECID. Falta validar su soporte Mac real en laboratorio. No usarlo como alternativa automática si Finder falla. El proceso no escala Revive a Restore y no realiza reintentos masivos.

Tras Revive, confirmar arranque en el objetivo; si solicita usuario/volumen/Recovery, seguir Apple. El expediente registra la declaración del técnico, no una comprobación remota certificada.

## Sistema: Recovery

Apple Silicon: desde apagado mantener encendido hasta opciones de arranque, elegir Options/Continue. Intel: Command-R al encender; otras variantes de Recovery dependen del modelo.

En el propio objetivo utilizar Disk Utility/First Aid y reinstalación sin borrar. Apple indica que reinstalar macOS no elimina apps/datos personales; respaldo previo si es posible. El asistente muestra instrucciones y abre documentación, pero no ejecuta instalación del objetivo desde el host.

Si hay errores físicos de SSD o datos irremplazables, detener escritura y priorizar recuperación de datos. No hay reparación por software de placa dañada, batería/cargador averiado o SSD físicamente fallando. No elude Activation Lock, firmware password ni FileVault.

## Compilación/validación

Compilar en macOS con `/bin/bash scripts/build-gui.sh`. La GUI sigue siendo código fuente sin binario distribuido. La nueva categoría contiene el asistente; hay 24 herramientas en total. Conserva los módulos anteriores.

Verificado aquí: sintaxis Bash, plist, ZIP e impedimento de ejecutar el asistente en Linux. No se compiló Swift ni se realizó DFU/Revive/reinstalación. Pruebas pendientes: Mac de laboratorio Apple Silicon/T2, Intel sin T2, host macOS <14, helper ausente, cancelación, ECID inválido, dos dispositivos USB, permisos del destino y estados reales después de Revive. No probar Restore con la única copia de datos.

## Referencias oficiales

- Firmware/DFU: https://support.apple.com/en-us/108900
- No enciende: https://support.apple.com/en-us/102623
- No termina de arrancar: https://support.apple.com/en-us/102675
- Recovery: https://support.apple.com/en-us/102518
- Reinstalar macOS: https://support.apple.com/en-us/102655
