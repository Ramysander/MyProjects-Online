# MacTech IT Portable 0.2 — edición TI

## Qué se implementó

Se amplía el código base 0.1 con nueve grupos de recolección TI, comprobación de SHA-256, evaluación de firma de apps, copia asistida de documentos y una interfaz SwiftUI nativa con 23 herramientas. No se entrega un binario precompilado: este entorno no tiene macOS ni SDK de Apple. El código GUI requiere compilación y pruebas en una Mac de desarrollo antes de distribución.

| Área | Servicios implementados | Límites |
|---|---|---|
| Inventario | Hardware, energía, USB/Thunderbolt, pantallas, audio, apps, paquetes, usuarios | Metadatos; no contraseñas ni inventario remoto |
| Red | Interfaces, DNS, proxy, ruta, listeners TCP locales; DNS/ping de un host opcional | Sin barrido de redes, sniffing ni pruebas de intrusión; GUI acepta DNS/IPv4 |
| Seguridad | FileVault, SIP, Gatekeeper, firewall, stealth, inscripción MDM | No modifica protecciones; no equivale a análisis antimalware ni auditoría de cumplimiento |
| Rendimiento | CPU, memoria, swap, espacio, estado térmico | Muestras puntuales; no temperaturas universales ni benchmark de estrés |
| Servicios | Agentes de la sesión y archivos de LaunchAgents/LaunchDaemons | No detiene procesos ni vuelca variables de entorno |
| Registros | Errores/faults de cinco minutos y nombres de crash reports | Puede requerir permisos; se conserva error, no se eleva automáticamente |
| Impresoras | Colas, trabajos y hardware/configuración | No cancela trabajos ni cambia drivers |
| Respaldos | Estado de Time Machine y copia a carpeta nueva con ditto | No copia coherente de bases abiertas, imagen arrancable ni snapshot; restauración requiere prueba |
| Actualizaciones | Lista de softwareupdate | No instala; consulta de red/metadatos; duración depende de Apple |
| Integridad | SHA-256 y comparación, codesign y spctl para .app | Origen del hash y confianza en certificado deben verificarse |
| Mantenimiento | Caché por aplicación, APFS asistido y Disk Utility | Se mantienen restricciones de 0.1 |
| DFU/restablecimiento | Detección candidata, cfgutil asistido, Erase Assistant | DFU sigue experimental y dependiente del modelo/versión; no incorpora macvdmtool compilado |

## Uso sin GUI

Desde Terminal dentro de la carpeta MacTechPortable:

```bash
/bin/bash scripts/it.sh inventory
/bin/bash scripts/it.sh network
/bin/bash scripts/it.sh network example.com
/bin/bash scripts/it.sh security
/bin/bash scripts/it.sh performance
/bin/bash scripts/it.sh services
/bin/bash scripts/it.sh logs
/bin/bash scripts/it.sh printers
/bin/bash scripts/it.sh backup-status
/bin/bash scripts/it.sh updates
/bin/bash scripts/it.sh all
```

`all` excluye la consulta de actualizaciones para evitar esa dependencia de Internet, y no ejecuta pruebas activas de ping sin un host indicado. El informe no produce un puntaje ficticio de salud. Cada salida corresponde a un proveedor y su código. Un 0 sólo indica que el comando terminó correctamente; las verificaciones se interpretan leyendo el archivo. Aplicaciones, agentes y registros pueden revelar datos privados.

Destino distinto al soporte portable (carpeta ya existente, ruta absoluta):

```bash
MACTECH_REPORTS="/Volumes/SoporteTI/Informes" /bin/bash scripts/it.sh all
```

No ejecutar toda la herramienta con sudo. El acceso a algunas carpetas puede depender de permisos de privacidad/TCC; permitirlo por el sistema cuando proceda, sin desactivar SIP. No compartir informes sin revisar seriales, nombres de usuario, DNS/proxy, rutas y mensajes de aplicaciones. La herramienta no envía informes a servicios externos; ping, DNS y softwareupdate sí pueden generar tráfico según la operación elegida.

## Compilar la interfaz gráfica en macOS

En la Mac de desarrollo, instalar Command Line Tools si faltan y luego ejecutar:

```bash
xcode-select --install
/bin/bash scripts/build-gui.sh
```

También se incluye `Build_GUI.command`. Se genera `dist/MacTech IT.app`, con ejecutable universal arm64/x86_64 y scripts/helper incorporados. Requiere un SDK compatible con las APIs y targets; el baseline de diseño es macOS 12. No tratar el build como verificado hasta compilar con un SDK real.

La firma ad hoc generada sirve para uso local; no equivale a Developer ID ni notarización. Para distribución pública se necesitan firma y notarización apropiadas. No desactivar Gatekeeper para resolver la distribución.

Después de compilar y probar, copiar la .app al USB y abrirla. Seleccionar un destino escribible para los informes. No se escribe dentro de la app para informes GUI. No instalar Swift/Xcode en cada cliente una vez que el binario ya se distribuye correctamente. Configurator y Automation Tools siguen siendo una dependencia del host para cfgutil.

## Interacción GUI

- Sidebar con 23 herramientas, explicación, host de red, selección de archivo/app y hash opcional.
- Ejecución de los diagnósticos fuera del hilo de la interfaz; salida limitada para evitar crecimiento indefinido de la vista.
- Informes privados por ejecución y botón para abrir el destino en Finder.
- Una tarea de lectura por ventana. La base aún permite abrir más ventanas y Terminal puede tener tareas independientes: el bloqueo global de trabajos queda pendiente. No ejecutar operaciones concurrentes de disco/firmware.
- Las acciones que requieren preguntas o sudo se abren como launchers fijos en Terminal. No introducir contraseñas por argumentos ni construir AppleScript con texto del usuario.
- Los launchers no heredan el destino de informes elegido en la GUI y sus resultados se supervisan en Terminal. La GUI no muestra progreso de esos procesos. No presenta un falso porcentaje de progreso.
- No se implementó cancelación de procesos hijos ni timeout global. Los proveedores lentos pueden mantener el trabajo en curso; la GUI permanece disponible para visualizar salida. No interrumpir firmware a mitad del proceso.
- APFS repair desde Recovery se realiza preferiblemente con scripts/Disk Utility; no asumir que SwiftUI funcione allí.

## Qué se corrigió respecto de 0.1

El destino de informes puede configurarse fuera del código para usar una app portable y preservar su firma. El catálogo de ejecución acepta sólo comandos previstos; las rutas de archivo se pasan como argumentos, sin eval. Las nuevas consultas conservan códigos de salida y fallos de permisos. La copia de documentos rechaza un destino dentro del origen y nunca sincroniza con borrado. Las operaciones destructivas conservan las confirmaciones e identificación de objetivo.

## Validación y requisitos para versión de producción

Realizado: inspección del paquete original vigente, sintaxis Bash, lectura del plist y verificación de que el ZIP contiene las fuentes, launchers y documentación. Probado en Linux que la entrada TI rechaza ese sistema antes de generar informes. No se realizó ejecución de macOS, compilación Swift ni pruebas de hardware/DFU.

Antes de uso técnico real: compilar helper y GUI; probar cada botón y destino de informes con espacios; verificar cambios de selección durante trabajos; probar macOS 12/13/14/15/26 en combinaciones soportadas; probar permisos TCC; confirmar códigos de salida de cada proveedor; prueba de restauración de documentos; y completar la matriz destructiva del blueprint 0.1 en equipos/datos desechables.

## Próximos servicios que requieren integración adicional

Gestión remota multi-equipo, tickets y clientes, integración MDM, inventario central, alertas persistentes, software de seguridad/antimalware, administración de parches y backup programado requieren servidores, APIs, credenciales o agentes. No se presentan como funciones terminadas de este paquete portable. Para un taller u oficina, una siguiente versión puede añadir ficha de servicio (equipo, cliente, problema, evidencias y resultado) después de validar esta base.

## Referencias

- Foundation Process: https://developer.apple.com/documentation/foundation/process
- Diagnóstico inalámbrico oficial, sin modificar configuración: https://support.apple.com/guide/mac-help/use-wireless-diagnostics-mchlf4de377f/mac
- Contratos CLI deben verificarse en la Mac de laboratorio: man system_profiler, man networksetup, man scutil, man tmutil, man ditto, man codesign y ayuda de cada herramienta según versión.
- Los límites y referencias Apple de DFU/reset/SSD permanecen en BLUEPRINT.md.
