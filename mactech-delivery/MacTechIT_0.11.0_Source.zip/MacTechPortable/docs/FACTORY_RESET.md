# Full Factory Reset — MacTech IT 0.8.0

MacTech IT uses Apple's supported reset path rather than directly erasing the startup disk.

## Supported primary path
For macOS 12+ on Apple silicon or Intel Macs with the Apple T2 Security Chip, run the read-only pre-check and then open Apple's Erase Assistant. The user must authenticate and confirm in Apple's UI.

## Fallback
If Erase All Content and Settings is unavailable, MacTech IT stops. The operator must use macOS Recovery, Disk Utility, and Reinstall macOS according to Apple guidance. The application deliberately does not issue `diskutil eraseDisk` against the internal startup disk.

## Safety
- Verify a restorable backup before erasing.
- Connect MacBooks to power and Internet.
- On Apple silicon with macOS 26+, if the Mac was repaired or repair status is uncertain, check Repair Assistant before erasing.
- Never bypass Activation Lock, Apple Account authentication, MDM restrictions, or ownership controls.
- Automated tests may run only source/syntax/build validation; they must never start a real reset.
