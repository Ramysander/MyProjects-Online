# Motor de diagnóstico y expedientes — 0.5

La GUI añade **Expedientes → Diagnóstico y expedientes**. El botón abre un asistente en Terminal; el formulario gráfico completo de expedientes no se implementó en esta versión. Hay 25 entradas en el catálogo. El motor Swift se compila como `caseengine` y se incorpora en la app junto a `macprobe`.

## Flujo

1. Crear expediente en una carpeta local o USB existente, o abrir uno anterior.
2. Indicar equipo y síntoma: `slow`, `network` o `startup`.
3. Capturar Antes en la Mac que realmente se mide.
4. Registrar intervención realizada (manual, no ejecutada automáticamente).
5. Capturar Después en la misma Mac bajo condiciones similares.
6. Generar informe y comparación. Imprimir/guardar PDF con el diálogo nativo (PDF → Guardar como PDF).

El programa no captura por DFU los sensores/volúmenes de otra Mac. El nombre de equipo es declarado; la identidad usada para comparación es IOPlatformUUID del host medido. No crear un expediente de una Mac averiada y registrar datos de la Mac técnica como si fueran sus datos.

## Evaluación inicial

- Espacio de `/`: ocupación <90% Correcto, 90–<97% Atención, >=97% Fallo de recurso disponible. No diagnóstico de avería física. Umbrales fijos de esta versión, documentados y pendientes de configuración GUI.
- FileVault y SIP: estados textuales reconocidos; activo Correcto, desactivo Atención, resultados no reconocidos No disponible. Depende del idioma/formato de comandos; nunca inferir éxito de una cadena desconocida.
- Rendimiento/red: conserva las muestras para revisión; estado Atención significa interpretación pendiente, no fallo demostrado.
- Arranque: No disponible como diagnóstico del objetivo remoto y guía hacia el asistente Recovery/DFU.

Archivos del expediente: `case.json`, `before.json`, `after.json`, carpetas de evidencia, `report.txt` y `report.html`. Los proveedores incluyen códigos de salida y los hallazgos incluyen estado, evidencia y próxima acción. Se permite una captura por fase para no sobrescribir evidencia; para repetir abrir otro expediente. Un fallo de captura puede dejar evidencia parcial.

No hay puntaje ficticio de salud ni causalidad automática. La comparación exige misma identidad conocida, síntoma, versión de esquema y fecha posterior; muestra cambios de ocupación/espacio libre con unidades coherentes. Métricas de CPU y memoria todavía no se comparan numéricamente. La identidad UUID es identificador práctico, no una identidad criptográfica resistente a falsificación.

## Informes y privacidad

Notas llevan fecha y son declaraciones del operador. El PDF se guarda mediante diálogo nativo de impresión, con revisión del usuario; no se genera silenciosamente. HTML escapa datos introducidos para evitar convertir notas en scripts. Permisos de expediente 0700 y archivos de informe/JSON 0600 donde el volumen los soporte; no se cifran. Proteger el USB y revisar datos antes de compartir.

## Control de operaciones

Los scripts operativos que cargan common.sh adquieren un lock mediante mkdir atómico, por UID, en `/tmp/mactech-job-UID`. Se comparte entre GUI y Terminal y permite trabajos anidados sólo si el dueño es ancestro vivo. Las ventanas GUI comparten el mismo Runner para tareas de lectura. No mata procesos ni elimina locks ajenos automáticamente.

Si hay cierre forzado puede quedar lock huérfano. Inspeccionar archivo owner y comprobar proceso antes de cualquier limpieza manual. No usarlo como defensa frente a un usuario malicioso local. Diferentes usuarios, Finder/Configurator independientes, comandos ejecutados manualmente y el binario caseengine invocado directamente quedan fuera del bloqueo. Es exclusión de trabajos de esta herramienta por usuario, no un bloqueo universal de todos los discos del sistema.

No cerrar Terminal ni cancelar procesos mientras haya firmware activo. El bloqueo heredado protege la ruta cfgutil ejecutada dentro del asistente; Finder ejecuta el firmware fuera de la herramienta y no está controlado por este mecanismo.

## Construcción y pruebas

`Build_DMG.command` produce la versión 0.5 en una Mac con SDK/Command Line Tools. Durante build se ejecuta `caseengine selftest`: datos ausentes, límites, identidad desconocida y escape HTML. Estos selftests Swift NO se ejecutaron aquí porque no existe SDK macOS.

Validación realizada en Linux: sintaxis Bash, plist, ZIP y pruebas del mecanismo de lock en una copia de common.sh con guard macOS retirado y ruta temporal de prueba. Eso verifica exclusión, anidación y liberación, no ejecución real macOS. No se compiló Swift ni se abrió la interfaz ni se generó DMG/PDF.

Antes de distribuir: compilar ambos slices; ejecutar selftests y ampliar fixtures de df/csrutil/fdesetup; pruebas con identidad distinta/desconocida; copiar expediente entre Mac; verificar impresión PDF multipágina; probar permisos y volúmenes USB; simulación de lock huérfano; validar cada botón y el DMG. Las cinco mejoras están implementadas como base de código, con estas limitaciones declaradas.
