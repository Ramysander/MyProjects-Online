# External Device Detection and DFU — 0.8.1

MacTech IT performs read-only discovery through system_profiler, macprobe and optional cfgutil. It can report USB, Thunderbolt/USB4 and conservative Apple DFU/Recovery candidates. A candidate is not proof of device identity, ownership, health or trust.

## DFU entry

DFU is a firmware state. MacTech IT does not claim to force a universal software reboot into DFU. The **Entrar / reiniciar en modo DFU** action opens a guided workflow and official Apple tools/documentation. The operator performs the model-specific physical sequence.

Automated tests must never invoke revive, restore, erase, factory reset or other device-changing actions.
