# Validación 0.10.0 — 2026-10-06

## Ejecutado en Linux

| Verificación | Resultado |
| --- | --- |
| `python3 tools/check_source.py` | PASS: sintaxis Bash de 42 scripts, 60 snippets, plist/versión 0.10.0, recursos y referencias de build |
| Gramática Swift de `GUI/ExpertWorkbenchView.swift` y `Sources/SupportCore.swift` | PASS: tree-sitter 0.25.2 / tree-sitter-swift 0.7.4, sin errores de análisis |
| Compilación Swift y comprobación de tipos | NO EJECUTADA: requiere macOS/SDK Apple |
| `caseengine selftest` | NO EJECUTADO |
| GUI, importación/exportación, bitácora, biblioteca, CSV y checksums | Revisados en fuente; NO verificados funcionalmente |
| Firma, universal arm64/x86_64, creación/verificación DMG | NO EJECUTADOS |
| Operaciones sobre dispositivos | NO EJECUTADAS |

El análisis de gramática no comprueba disponibilidad de APIs, conformidades de protocolos, tipado de SwiftUI ni ejecución de CryptoKit. No sustituye el compilador.

## Compilación permitida en macOS

Desde la raíz del proyecto, con Apple Command Line Tools:

```bash
/bin/bash Build_DMG.command
```

El constructor ejecuta selftests sintéticos, genera app universal y verifica firma/arquitecturas/DMG y SHA-256. Salidas esperadas: `dist/MacTech_IT_v0.10.0.dmg`, `.dmg.sha256` y app en el directorio build único. Detenerse ante el primer fallo, conservar el log y corregir la causa.

Los nuevos selftests cubren importación sin extensión, serialización del seguimiento, checklist de cierre, prioridades inválidas, IDs duplicados, notas excesivas, técnico vacío, vector SHA-256 conocido y comillas/prefijos de fórmula en CSV. No ejecutan comandos de dispositivos.

## Aceptación manual pendiente: sólo datos sintéticos

Use una carpeta de informes vacía de laboratorio. No abra módulos operativos ni pulse Escanear conexiones durante estas pruebas.

1. Cree un expediente ficticio. En Seguimiento defina ticket, técnico, prioridad y fecha objetivo pasada. Añada una nota; compruebe que conservar notas pendientes exige Añadir entrada antes de guardar/imprimir y que cerrar pide confirmación.
2. Guarde como Pendiente, actualice Biblioteca y encuentre la revisión mediante ticket/técnico/equipo. Compruebe el aviso de fecha objetivo vencida.
3. Seleccione Resuelto sin completar el cierre: debe rechazar el guardado y explicar los campos pendientes. Complete equipo, síntoma, intervención, después y checklist; guardar debe crear una nueva revisión conservando la anterior.
4. Exporte/importa un JSON 0.9.0 sin extensión y un JSON 0.10.0 con seguimiento; compruebe valores por defecto y conservación de la bitácora. No vuelva a guardar documentos profesionales desde versiones anteriores.
5. Compruebe JSON, HTML y PDF con notas largas, `<`, `>`, `&`, comillas y texto Unicode. Un resultado Resuelto importado con cierre incompleto debe mostrar esa advertencia en el informe.
6. Exporte CSV filtrado con datos ficticios que incluyan comas, comillas, saltos y `=1+1`; examine el archivo como texto, compruebe comillas y prefijo de texto. Debe exportar revisiones visibles, no fusionarlas por expediente.
7. En una copia del paquete sintético, Verificar integridad debe confirmar JSON/HTML. Modificar sólo HTML debe provocar fallo en Verificar; modificar JSON sin actualizar el manifiesto debe impedir Abrir. Un JSON copiado sin manifiesto debe abrir, pero no indicar integridad verificada.
8. Cambie campos después de guardar/importar: Cerrar/Nuevo/Abrir debe pedir confirmación. Sin cambios ni nota pendiente no debe pedirla.
9. Compruebe carpeta inexistente/no accesible, JSON excesivo o malformado y rechazo de seguimiento inválido. En una carpeta de prueba de sólo lectura, guardar debe fallar sin marcar el borrador como guardado. En fallos a mitad del paquete, las carpetas `.pending-*` no deben aparecer en Biblioteca.
10. Para bibliotecas grandes sintéticas, confirme límite y aviso de lista parcial. La selección limitada no garantiza incluir todas las revisiones más recientes; los conteos describen únicamente los archivos cargados.

Los expedientes son archivos locales sin cifrado. Los checksums detectan diferencias respecto del manifiesto recibido, pero no autentican autoría ni impiden alterar/eliminar ese manifiesto. La bitácora no es un registro de auditoría inmutable. No se ha validado distribución pública; requiere Developer ID, notarización y pruebas en macOS limpio.
