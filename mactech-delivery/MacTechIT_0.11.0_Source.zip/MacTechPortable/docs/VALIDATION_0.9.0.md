# Validación 0.9.0 — 2026-10-06

Ejecutado en Linux, sin operaciones sobre dispositivos reales.

PASS: Bash -n en 42 scripts y launchers; Info.plist/version 0.9.0; 60 snippets únicos y plantillas; referencias de recursos GUI; inclusión del núcleo compartido en ambos builds; conexión de selftests al motor; integridad y rutas del ZIP.

Pendiente en macOS: compilación Swift universal, ejecución de caseengine selftest, firma/arquitecturas, creación y verificación del DMG. Pendiente manual: comportamiento de GUI, inventario, revisiones/importación de expedientes y PDF multipágina.

Ejecute desde el directorio del proyecto: `/bin/bash Build_DMG.command`. No use sudo. El build ejecuta selftests de datos simulados; no necesita dispositivos conectados. Un resultado estático PASS no acredita que Swift compile ni que exista un DMG válido.
