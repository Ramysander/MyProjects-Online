import Foundation
import CryptoKit

// Shared pure models. No device commands are executed by this file.
struct ConnectedDevice: Codable, Identifiable, Equatable {
    var id: String
    var name: String
    var transport: String
    var serial: String
    var location: String
    var state: String
}
func parseConnectedDevices(_ data: Data) throws -> [ConnectedDevice] {
    guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
          root["SPUSBDataType"] != nil || root["SPThunderboltDataType"] != nil else {
        throw NSError(domain: "Inventario", code: 1, userInfo: [NSLocalizedDescriptionKey: "La respuesta no contiene un inventario USB/Thunderbolt válido"])
    }
    for key in ["SPUSBDataType", "SPThunderboltDataType"] {
        if let records = root[key], !(records is [Any]) {
            throw NSError(domain: "Inventario", code: 2, userInfo: [NSLocalizedDescriptionKey: "Formato inesperado de los registros de inventario"])
        }
    }
    var result: [ConnectedDevice] = []
    func walk(_ value: Any, transport: String) {
        if let list = value as? [Any] { for entry in list { walk(entry, transport: transport) }; return }
        guard let item = value as? [String: Any] else { return }
        func string(_ key: String) -> String { (item[key] as? String) ?? "" }
        let name = string("_name")
        let usbDevice = transport == "USB" && (!string("vendor_id").isEmpty || !string("product_id").isEmpty)
        let thunderDevice = transport == "Thunderbolt / USB4" && !string("device_name").isEmpty
        if usbDevice || thunderDevice {
            let vendor = string("vendor_id").lowercased()
            let apple = vendor.contains("0x05ac")
            let lower = name.lowercased()
            let state: String
            if apple && lower.contains("dfu") { state = "Candidato DFU — confirmar en Finder/Configurator" }
            else if apple && lower.contains("recovery") { state = "Candidato Recovery — confirmar en Finder" }
            else { state = "Conectado; modo y confianza no verificados" }
            let serial = string("serial_num").isEmpty ? string("serial_number") : string("serial_num")
            let location = string("location_id")
            result.append(ConnectedDevice(id: "\(transport)-\(result.count)", name: name.isEmpty ? string("device_name") : name,
                transport: transport, serial: serial.isEmpty ? "No disponible" : serial,
                location: location.isEmpty ? "No disponible" : location, state: state))
        }
        if let children = item["_items"] { walk(children, transport: transport) }
    }
    if let usb = root["SPUSBDataType"] { walk(usb, transport: "USB") }
    if let thunder = root["SPThunderboltDataType"] { walk(thunder, transport: "Thunderbolt / USB4") }
    return result
}
struct ServiceEvent: Codable, Equatable, Identifiable {
    var id = UUID().uuidString
    var date = Date()
    var technician: String
    var note: String
}
struct CaseWorkflow: Codable, Equatable {
    var ticket = ""
    var technician = ""
    var priority = "Normal"
    var due: Date?
    var authorizationConfirmed = false
    var backupReviewed = false
    var finalVerification = false
    var handoffConfirmed = false
    var events: [ServiceEvent] = []
}
struct UnifiedServiceCase: Codable, Equatable {
    var schema = 1
    var id = UUID().uuidString
    var created = Date()
    var updated = Date()
    var platform = "Mac"
    var asset = ""
    var symptom = ""
    var before = ""
    var action = ""
    var after = ""
    var outcome = "Pendiente"
    var inventoryDate: Date?
    var devices: [ConnectedDevice] = []
    // Optional extension keeps original schema-1 documents readable.
    var professional: CaseWorkflow?
    var workflow: CaseWorkflow {
        get { professional ?? CaseWorkflow() }
        set { professional = newValue }
    }
    var closureIssues: [String] {
        var issues: [String] = []
        func missing(_ value: String) -> Bool { value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        if missing(asset) { issues.append("Identificar el equipo") }
        if missing(symptom) { issues.append("Documentar el motivo de servicio") }
        if missing(workflow.technician) { issues.append("Asignar técnico responsable") }
        if missing(action) || missing(after) { issues.append("Documentar intervención y verificación posterior") }
        if !workflow.authorizationConfirmed { issues.append("Confirmar autorización del servicio") }
        if !workflow.backupReviewed { issues.append("Revisar respaldo o documentar que no aplica") }
        if !workflow.finalVerification { issues.append("Registrar verificación final") }
        if !workflow.handoffConfirmed { issues.append("Confirmar entrega o comunicación del resultado") }
        return issues
    }
    func validate() throws {
        guard schema == 1, UUID(uuidString: id) != nil,
              ["Mac", "iPhone", "iPad"].contains(platform),
              ["Pendiente", "Resuelto", "Parcial", "Escalado"].contains(outcome),
              [asset, symptom, before, action, after].allSatisfy({ $0.count <= 20000 }), devices.count <= 500,
              devices.allSatisfy({ [$0.id, $0.name, $0.transport, $0.serial, $0.location, $0.state].allSatisfy { $0.count <= 2000 } }),
              [created, updated, inventoryDate, workflow.due].compactMap({ $0 }).allSatisfy({ $0.timeIntervalSince1970.isFinite }) else {
            throw NSError(domain: "MacTechCase", code: 1, userInfo: [NSLocalizedDescriptionKey: "Formato de expediente inválido o demasiado grande"])
        }
        let fields = [workflow.ticket, workflow.technician]
        guard fields.allSatisfy({ $0.count <= 500 }),
              ["Baja", "Normal", "Alta", "Crítica"].contains(workflow.priority),
              workflow.events.count <= 500,
              Set(workflow.events.map { $0.id }).count == workflow.events.count,
              workflow.events.allSatisfy({ UUID(uuidString: $0.id) != nil && $0.date.timeIntervalSince1970.isFinite && !$0.note.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && $0.note.count <= 10000 && !$0.technician.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && $0.technician.count <= 500 }) else {
            throw NSError(domain: "MacTechCase", code: 2, userInfo: [NSLocalizedDescriptionKey: "Seguimiento profesional inválido o demasiado grande"])
        }
    }
    var reportText: String {
        let formatter = ISO8601DateFormatter()
        var text = "MacTech IT — expediente \(id)\nCreado: \(formatter.string(from: created))\nActualizado: \(formatter.string(from: updated))\nPlataforma: \(platform)\nEquipo (declarado por técnico): \(asset)\nSíntoma: \(symptom)\n\nANTES (nota del técnico)\n\(before)\n\nINTERVENCIÓN (nota del técnico)\n\(action)\n\nDESPUÉS (nota del técnico)\n\(after)\n\nResultado declarado: \(outcome)\n"
        if let details = professional {
            text += "\nSEGUIMIENTO DEL SERVICIO\nTicket: \(details.ticket)\nTécnico: \(details.technician)\nPrioridad: \(details.priority)\n"
            if let due = details.due { text += "Fecha objetivo: \(formatter.string(from: due))\n" }
            text += "Checklist declarado por el técnico (no verificación automática):\n"
            for (label, checked) in [("Autorización", details.authorizationConfirmed), ("Respaldo revisado / no aplica documentado", details.backupReviewed), ("Verificación final", details.finalVerification), ("Entrega / comunicación", details.handoffConfirmed)] {
                text += "\(checked ? "CONFIRMADO" : "PENDIENTE") — \(label)\n"
            }
            text += "\nBITÁCORA MANUAL (no es un registro de auditoría inmutable)\n"
            for event in details.events { text += "\(formatter.string(from: event.date)) | \(event.technician) | \(event.note)\n" }
        }
        if let date = inventoryDate {
            text += "\nInventario observado desde la Mac técnica: \(formatter.string(from: date))\nNo acredita identidad del equipo intervenido, confianza, salud ni acceso a datos.\n"
            for device in devices { text += "\(device.name) | \(device.transport) | \(device.state) | serie: \(device.serial) | ubicación: \(device.location)\n" }
        }
        if outcome == "Resuelto", !closureIssues.isEmpty {
            text += "\nCIERRE INCOMPLETO: " + closureIssues.joined(separator: "; ") + "\n"
        }
        return text
    }
}
func supportHTMLEscape(_ value: String) -> String {
    value.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;").replacingOccurrences(of: ">", with: "&gt;").replacingOccurrences(of: "\"", with: "&quot;")
}
func supportSHA256(_ data: Data) -> String {
    SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
}
func supportCSVField(_ value: String) -> String {
    let first = value.trimmingCharacters(in: .whitespacesAndNewlines).first
    let safe = first.map { "=+-@".contains($0) } == true ? "'" + value : value
    return "\"" + safe.replacingOccurrences(of: "\"", with: "\"\"") + "\""
}
func supportCoreSelfTest() throws {
    guard supportSHA256(Data("abc".utf8)) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad" else {
        throw NSError(domain: "SHA256 known vector", code: 1)
    }
    guard supportCSVField("a,\"b\"") == "\"a,\"\"b\"\"\"",
          supportCSVField(" =1+1").hasPrefix("\"'"), supportCSVField("Técnico") == "\"Técnico\"" else {
        throw NSError(domain: "CSV escaping", code: 1)
    }
    let empty = Data(#"{"SPUSBDataType":[{"_name":"DFU Recovery USB Bus"}],"SPThunderboltDataType":[{"_name":"Thunderbolt"}]}"#.utf8)
    guard try parseConnectedDevices(empty).isEmpty else { throw NSError(domain: "False positive bus", code: 1) }
    let fixture = Data(#"{"SPUSBDataType":[{"_name":"USB Bus","_items":[{"_name":"Apple Mobile Device (DFU Mode)","vendor_id":"0x05ac","product_id":"0x1227"},{"_name":"DFU reader","vendor_id":"0x9999","product_id":"0x0001"}]}]}"#.utf8)
    let rows = try parseConnectedDevices(fixture)
    guard rows.count == 2, rows[0].state.hasPrefix("Candidato DFU"), !rows[1].state.hasPrefix("Candidato"), supportHTMLEscape("<&>") == "&lt;&amp;&gt;" else { throw NSError(domain: "Inventory rules", code: 1) }
    for malformed in ["[]", "{}", #"{"SPUSBDataType":null}"#, #"{"SPUSBDataType":{}}"#] {
        do {
            _ = try parseConnectedDevices(Data(malformed.utf8))
        } catch { continue }
        throw NSError(domain: "Invalid inventory accepted", code: 1)
    }
    guard try parseConnectedDevices(Data(#"{"SPUSBDataType":[]}"#.utf8)).isEmpty else {
        throw NSError(domain: "Empty inventory", code: 1)
    }
    let original = UnifiedServiceCase()
    let decoded = try JSONDecoder().decode(UnifiedServiceCase.self, from: JSONEncoder().encode(original))
    try decoded.validate()
    guard decoded == original else { throw NSError(domain: "Case round trip", code: 1) }
    var edited = original
    edited.platform = "iPad"
    guard edited != original else { throw NSError(domain: "Platform edit not detected", code: 1) }
    edited = original; edited.outcome = "Escalado"
    guard edited != original else { throw NSError(domain: "Outcome edit not detected", code: 1) }
    edited = original; edited.devices = rows
    guard edited != original else { throw NSError(domain: "Inventory edit not detected", code: 1) }
    // Legacy documents without the extension must still decode.
    let legacy = try JSONEncoder().encode(original)
    let migrated = try JSONDecoder().decode(UnifiedServiceCase.self, from: legacy)
    guard migrated.professional == nil, migrated.workflow.priority == "Normal" else {
        throw NSError(domain: "Legacy migration", code: 1)
    }
    var managed = original
    managed.workflow.ticket = "LAB-001"
    managed.workflow.technician = "Técnico de prueba"
    managed.workflow.priority = "Alta"
    managed.workflow.events.append(ServiceEvent(technician: "Técnico de prueba", note: "Verificación sintética <sin dispositivos>"))
    try managed.validate()
    let managedCopy = try JSONDecoder().decode(UnifiedServiceCase.self, from: JSONEncoder().encode(managed))
    guard managedCopy == managed, !managed.closureIssues.isEmpty,
          managed.reportText.contains("LAB-001"), managed.reportText.contains("BITÁCORA MANUAL") else {
        throw NSError(domain: "Professional round trip", code: 1)
    }
    managed.asset = "Equipo simulado"; managed.symptom = "Fixture"
    managed.action = "Inspección sintética"; managed.after = "Resultado sintético"
    managed.workflow.authorizationConfirmed = true; managed.workflow.backupReviewed = true
    managed.workflow.finalVerification = true; managed.workflow.handoffConfirmed = true
    guard managed.closureIssues.isEmpty else { throw NSError(domain: "Closure checklist", code: 1) }
    func expectRejection(_ draft: UnifiedServiceCase) throws {
        do { try draft.validate() }
        catch { return }
        throw NSError(domain: "Invalid professional case accepted", code: 1)
    }
    var invalid = managed; invalid.workflow.priority = "No válida"
    try expectRejection(invalid)
    invalid = managed; invalid.workflow.events.append(invalid.workflow.events[0])
    try expectRejection(invalid)
    invalid = managed; invalid.workflow.events[0].note = String(repeating: "a", count: 10001)
    try expectRejection(invalid)
    invalid = managed; invalid.workflow.events[0].technician = " "
    try expectRejection(invalid)
}
