import Foundation
import IOKit
import IOKit.ps

// Las llamadas usan argumentos separados: no se interpreta un shell.
func diskutil(_ args: [String]) throws -> [String: Any] {
    let task = Process(); let pipe = Pipe()
    task.executableURL = URL(fileURLWithPath: "/usr/sbin/diskutil")
    task.arguments = args; task.standardOutput = pipe
    task.standardError = FileHandle.standardError
    try task.run()
    let bytes = pipe.fileHandleForReading.readDataToEndOfFile()
    task.waitUntilExit()
    guard task.terminationStatus == 0,
          let obj = try PropertyListSerialization.propertyList(from: bytes, format: nil) as? [String: Any]
    else { throw NSError(domain: "diskutil", code: 1) }
    return obj
}
func emit(_ value: Any) throws {
    let data = try JSONSerialization.data(withJSONObject: value, options: [.prettyPrinted, .sortedKeys])
    FileHandle.standardOutput.write(data); print("")
}
func refuse(_ text: String) throws -> Never {
    throw NSError(domain: text, code: 1)
}
// Guard conservador: sólo disco físico EXTERNO; protege sistema y soporte portable.
func guardDisk(_ disk: String, _ root: String) throws {
    guard disk.range(of: "^disk[0-9]+$", options: .regularExpression) != nil else { try refuse("Identificador inválido") }
    let info = try diskutil(["info", "-plist", disk])
    guard info["Whole"] as? Bool == true,
          info["Internal"] as? Bool == false,
          info["VirtualOrPhysical"] as? String == "Physical",
          let size = info["TotalSize"] as? NSNumber,
          let tree = info["DeviceTreePath"] as? String, !tree.isEmpty
    else { try refuse("Sólo discos físicos externos con identidad verificable") }
    let layout = try diskutil(["list", "-plist", disk])
    var members = Set<String>([disk])
    func walk(_ value: Any) {
        if let d = value as? [String: Any] {
            if let id = d["DeviceIdentifier"] as? String { members.insert(id) }
            for v in d.values { walk(v) }
        } else if let a = value as? [Any] { for v in a { walk(v) } }
    }
    walk(layout)
    // Incluye volúmenes sintetizados de contenedores respaldados por este disco.
    let apfs = try diskutil(["apfs", "list", "-plist"])
    guard let containers = apfs["Containers"] as? [[String: Any]] else { try refuse("Esquema APFS desconocido") }
    for c in containers {
        guard let stores = c["PhysicalStores"] as? [[String: Any]] else { try refuse("PhysicalStores desconocido") }
        if stores.contains(where: { members.contains($0["DeviceIdentifier"] as? String ?? "") }) {
            guard stores.count == 1 else { try refuse("Contenedor con múltiples discos físicos") }
            walk(c)
        }
    }
    // diskutil info de rutas resuelve también el volumen APFS que las contiene.
    for protected in ["/", "/System/Volumes/Data", root] {
        let v = try diskutil(["info", "-plist", protected])
        guard let id = v["DeviceIdentifier"] as? String else { try refuse("No se pudo resolver ruta protegida") }
        if members.contains(id) { try refuse("Disco del sistema o de la herramienta") }
    }
    try emit(["device": disk, "size": size, "tree": tree,
              "media": info["MediaName"] as? String ?? "unknown"])
}
func power() throws {
    guard let blob = IOPSCopyPowerSourcesInfo()?.takeRetainedValue(),
          let sources = IOPSCopyPowerSourcesList(blob)?.takeRetainedValue() as? [CFTypeRef]
    else { try refuse("Información de energía no disponible") }
    var rows = [[String: String]]()
    for source in sources {
        if let d = IOPSGetPowerSourceDescription(blob, source)?.takeUnretainedValue() as? [String: Any] {
            rows.append(d.mapValues { String(describing: $0) })
        }
    }
    try emit(["sources": rows, "thermalState": ProcessInfo.processInfo.thermalState.rawValue])
}
func dfuCandidates() throws {
    var iterator: io_iterator_t = 0
    guard IOServiceGetMatchingServices(kIOMainPortDefault, IOServiceMatching("IOUSBHostDevice"), &iterator) == KERN_SUCCESS
    else { try refuse("No se puede leer USB") }
    defer { IOObjectRelease(iterator) }
    var rows = [[String: String]]()
    while true {
        let device = IOIteratorNext(iterator); if device == 0 { break }
        defer { IOObjectRelease(device) }
        func property(_ key: String) -> Any? {
            IORegistryEntryCreateCFProperty(device, key as CFString, kCFAllocatorDefault, 0)?.takeRetainedValue()
        }
        let name = property("USB Product Name") as? String ?? ""
        if (property("idVendor") as? NSNumber)?.intValue == 0x05ac && name.uppercased().contains("DFU") {
            rows.append(["product": name, "location": String(describing: property("locationID") ?? "unknown")])
        }
    }
    // Es una heurística: puede ser iPhone/iPad; no autoriza Restore.
    try emit(["candidateOnly": true, "devices": rows])
}
do {
    let a = CommandLine.arguments
    switch a.dropFirst().first {
    case "power": try power()
    case "dfu": try dfuCandidates()
    case "guard-disk" where a.count == 4: try guardDisk(a[2], a[3])
    default: try refuse("Uso: macprobe power | dfu | guard-disk diskN ROOT")
    }
} catch {
    FileHandle.standardError.write(Data("ERROR: \(error)\n".utf8)); exit(1)
}
