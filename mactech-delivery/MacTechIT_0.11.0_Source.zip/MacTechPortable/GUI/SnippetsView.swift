import SwiftUI
import AppKit
import Foundation

struct SnippetsView: View {
    let root: URL
    let snippets: [ITSnippet]
    let loadError: String?
    @Environment(\.presentationMode) private var presentationMode
    @State private var search = ""
    @State private var selected: String? = "os"
    @State private var parameter = ""
    @State private var collectionFilter: String
    @State private var categoryFilter = "Todas"
    @State private var riskFilter = "Todos"
    @State private var architectureFilter = "Todas"
    @State private var showAdvanced = false
    @State private var acknowledged = false
    @State private var message = ""
    init(root: URL, initialCollection: String = "macOS experto") {
        self.root = root
        _collectionFilter = State(initialValue: initialCollection)
        do {
            let loaded = try JSONDecoder().decode([ITSnippet].self, from: Data(contentsOf: root.appendingPathComponent("docs/snippets.json")))
            try validateSnippetCatalog(loaded)
            snippets = loaded; loadError = nil
        } catch { snippets = []; loadError = "No se pudo validar el catálogo: \(error.localizedDescription)" }
    }
    private var filtered: [ITSnippet] {
        snippets.filter { item in
            let text = [item.title, item.category, item.detail, item.command, item.interpretation ?? ""].joined(separator: " ")
            return (collectionFilter == "Todas" || item.collection == collectionFilter) &&
                (categoryFilter == "Todas" || item.category == categoryFilter) &&
                (riskFilter == "Todos" || item.risk == riskFilter) &&
                (architectureFilter == "Todas" || (item.compatibility ?? "").contains(architectureFilter)) &&
                (showAdvanced || item.risk != "Modifica" && item.risk != "Destructivo") &&
                (search.isEmpty || text.localizedCaseInsensitiveContains(search))
        }
    }
    private var current: ITSnippet? { filtered.first { $0.id == selected } }
    private var prepared: String? {
        guard let item = current else { return nil }
        return try? prepareSnippet(item, parameter: item.kind == "none" ? "" : parameter, root: root.path, acknowledged: showAdvanced && acknowledged)
    }
    private var categories: [String] { Array(Set(snippets.filter { collectionFilter == "Todas" || $0.collection == collectionFilter }.map { $0.category })).sorted() }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            filters
            if let error = loadError { Text(error).foregroundColor(.red) }
            HSplitView { snippetList; snippetDetail }
            Text("Texto para la sesión Terminal receptora, no necesariamente ESTA Mac. No incluya secretos. Los wrappers conservan su bloqueo y confirmaciones; las consultas nativas copiadas no participan en el Runner.").font(.caption)
        }.padding(20).frame(minWidth: 1080, minHeight: 740)
        .onChange(of: selected) { _ in parameter = ""; acknowledged = false; message = "" }
        .onChange(of: parameter) { _ in acknowledged = false }
        .onChange(of: collectionFilter) { _ in categoryFilter = "Todas"; selected = nil; acknowledged = false }
        .onChange(of: showAdvanced) { _ in acknowledged = false }
    }
    private var header: some View {
        HStack { Text("Snippets TI experto para Mac").font(.title2).bold(); Spacer(); Button("Cerrar") { presentationMode.wrappedValue.dismiss() } }
    }
    private var filters: some View {
        VStack(alignment: .leading, spacing: 8) {
            TextField("Buscar herramienta, comando, necesidad o interpretación", text: $search)
            HStack {
                Picker("Colección", selection: $collectionFilter) { ForEach(["Todas", "macOS experto", "iPhone / iPad"], id: \.self) { Text($0).tag($0) } }
                Picker("Categoría", selection: $categoryFilter) { ForEach(["Todas"] + categories, id: \.self) { Text($0).tag($0) } }
                Picker("Riesgo", selection: $riskFilter) { ForEach(["Todos", "Lectura", "Supervisado", "Modifica", "Destructivo"], id: \.self) { Text($0).tag($0) } }
                Picker("Arquitectura", selection: $architectureFilter) { ForEach(["Todas", "Intel", "Apple silicon"], id: \.self) { Text($0).tag($0) } }
            }
            Toggle("Mostrar flujos que modifican o destruyen datos", isOn: $showAdvanced)
        }
    }
    private var snippetList: some View {
        List(selection: $selected) {
            ForEach(filtered) { item in
                VStack(alignment: .leading) {
                    Text(item.title)
                    Text(item.category + " · " + item.risk).font(.caption).foregroundColor(.secondary)
                }.tag(item.id)
            }
        }.frame(minWidth: 270)
    }
    private var snippetDetail: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if let item = current {
                    metadata(item)
                    parameters(item)
                    commandPreview(item)
                    Text(message).font(.caption)
                    Text("Arrastre al prompt vacío, revise el comando y pulse Enter. El texto no termina en salto de línea ni ejecuta automáticamente. Si Terminal añade escapes, copie/pegue y revise de nuevo.").font(.caption)
                } else { Text("Seleccione un snippet de los resultados filtrados.") }
            }.padding()
        }.frame(minWidth: 600)
    }
    private func metadata(_ item: ITSnippet) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(item.title).font(.title2).bold()
            Text(item.detail)
            Text("Riesgo: " + item.risk + " · " + (item.compatibility ?? "Compatibilidad no declarada")).font(.caption)
            Text("Requisitos: " + (item.requirements ?? "Consulte la ayuda local")).font(.caption)
            Text("Interpretación: " + (item.interpretation ?? "Revise el estado de salida; datos ausentes no acreditan salud."))
            Text(availability(item)).font(.caption)
            if let reference = item.reference, let url = URL(string: reference) { Link("Referencia / documentación", destination: url) }
        }
    }
    private func availability(_ item: ITSnippet) -> String {
        let missing = (item.executables ?? []).filter { !FileManager.default.isExecutableFile(atPath: $0) }
        return missing.isEmpty ? "Ejecutables declarados presentes en ESTA Mac; compruebe opciones con man/ayuda local. No prueba permisos, versión ni soporte del modelo." : "No disponibles en ESTA Mac: " + missing.joined(separator: ", ") + ". El comando puede no funcionar aquí."
    }
    @ViewBuilder private func parameters(_ item: ITSnippet) -> some View {
        if item.kind != "none" {
            TextField(item.parameterHint ?? ("Parámetro: " + item.kind), text: $parameter)
            if item.kind == "file" || item.kind == "app" {
                Button("Seleccionar archivo / aplicación") {
                    let panel = NSOpenPanel(); panel.canChooseFiles = item.kind == "file"; panel.canChooseDirectories = item.kind == "app"
                    panel.treatsFilePackagesAsDirectories = false
                    if panel.runModal() == .OK, let url = panel.url { parameter = url.path }
                }
            }
        }
        if item.risk == "Modifica" || item.risk == "Destructivo" {
            Toggle("Identifiqué el objetivo y revisaré sus confirmaciones supervisadas", isOn: $acknowledged)
        }
    }
    @ViewBuilder private func commandPreview(_ item: ITSnippet) -> some View {
        Text("Plantilla completa (los marcadores no se ejecutan):").font(.caption)
        Text(item.command).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
        if let command = prepared {
            Text("Comando preparado:").font(.caption).bold()
            Text(command).font(.system(.body, design: .monospaced)).textSelection(.enabled).padding(10).background(Color(NSColor.textBackgroundColor))
            HStack {
                Label("Arrastrar como texto", systemImage: "hand.draw").padding(8).background(Color.accentColor.opacity(0.15))
                    .onDrag { NSItemProvider(object: command as NSString) }
                Button("Copiar") {
                    NSPasteboard.general.clearContents(); NSPasteboard.general.setString(command, forType: .string)
                    message = "Copiado sin salto de línea; no se ha ejecutado."
                }
            }
        } else { Text("Parámetro inválido o confirmación pendiente. No se permite copiar/arrastrar hasta preparar el comando.").foregroundColor(.secondary) }
        Button("Abrir Terminal (sin comando)") { NSWorkspace.shared.open(URL(fileURLWithPath: "/System/Applications/Utilities/Terminal.app")) }
    }
}
