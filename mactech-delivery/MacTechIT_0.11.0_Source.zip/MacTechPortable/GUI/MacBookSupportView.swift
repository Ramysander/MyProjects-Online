import SwiftUI
import AppKit

struct MacBookSupportView: View {
    @ObservedObject var runner: Runner
    @Environment(\.presentationMode) private var presentationMode
    @State private var category = "Diagnóstico"
    @State private var selected: String? = "diag"
    @State private var scope = "host"
    @State private var family = "MacBook Air"
    @State private var identity = ""
    @State private var host = ""
    @State private var confirmed = false
    @State private var snippets = false
    @State private var expert = false
    private var action: MacBookAction? { macBookActions.first { $0.id == selected && $0.category == category } }
    private var tool: Tool? { catalog.first { $0.id == selected } }
    private var targetIdentified: Bool { scope == "host" || !identity.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    private var canRun: Bool {
        guard let action = action, let tool = tool else { return false }
        return macBookActionAllowed(action, scope: scope) && targetIdentified && !runner.jobInProgress && (!tool.terminal || confirmed) &&
            (action.id != "network" || host.isEmpty || validSnippetParameter(host, kind: "host"))
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            context
            HSplitView {
                navigation
                detail
            }
            Text("MacBook Air / MacBook Pro únicamente. No hay acceso remoto automático a batería, FileVault, sensores o CPU de una MacBook conectada. DFU no expone archivos.").font(.caption)
        }.padding(20).frame(minWidth: 1050, minHeight: 720)
        .onChange(of: selected) { _ in confirmed = false }
        .onChange(of: scope) { _ in confirmed = false }
        .onChange(of: identity) { _ in confirmed = false }
        .onChange(of: family) { _ in confirmed = false }
        .sheet(isPresented: $snippets) { SnippetsView(root: runner.root, initialCollection: "macOS experto") }
        .sheet(isPresented: $expert) {
            ExpertWorkbenchView(runner: runner, initialAsset: family + " · " + (scope == "host" ? "ESTA Mac anfitriona (identidad por confirmar)" : "Objetivo declarado: " + identity), initialReport: scope == "host" ? runner.latestReport : nil)
        }
    }
    private var header: some View {
        HStack {
            Text("Macbook · soporte MacBook Air / Pro").font(.title2).bold()
            Spacer()
            Button("Expediente MacBook") { expert = true }.disabled(!targetIdentified)
            Button("Snippets macOS experto") { snippets = true }
            Button("Cerrar") { presentationMode.wrappedValue.dismiss() }
        }
    }
    private var context: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Picker("Equipo", selection: $scope) {
                    Text("ESTA Mac anfitriona").tag("host")
                    Text("MacBook objetivo conectada").tag("target")
                }.pickerStyle(.segmented)
                Picker("Familia declarada", selection: $family) {
                    Text("MacBook Air").tag("MacBook Air")
                    Text("MacBook Pro").tag("MacBook Pro")
                }
            }
            if scope == "target" {
                TextField("Identificación manual del objetivo (modelo / etiqueta; nunca contraseñas)", text: $identity)
            }
            Text(scope == "host" ? "Todas las métricas locales corresponden a ESTA Mac. Confirme que es la MacBook declarada; escoger una familia no verifica el modelo." : "Diagnóstico remoto no disponible. El inventario observa buses del anfitrión; identidad y modo del objetivo deben confirmarse en Finder/Configurator.").font(.caption)
        }
    }
    private var navigation: some View {
        VStack(alignment: .leading) {
            Picker("Categoría", selection: $category) {
                ForEach(macBookCategories, id: \.self) { Text($0).tag($0) }
            }
            List(selection: $selected) {
                ForEach(macBookActions.filter { $0.category == category }) { item in
                    VStack(alignment: .leading) {
                        Text(catalog.first { $0.id == item.id }?.title ?? item.id)
                        Text(item.scope == "host" ? "ESTA Mac" : item.scope == "target" ? "Objetivo / guía" : "Selección supervisada").font(.caption)
                    }.tag(item.id)
                }
            }
        }.frame(minWidth: 260)
        .onChange(of: category) { value in selected = macBookActions.first { $0.category == value }?.id }
    }
    private var detail: some View {
        VStack(alignment: .leading, spacing: 10) {
            actionDescription
            controls
            reportOutput
        }.padding().frame(minWidth: 600)
    }
    @ViewBuilder private var actionDescription: some View {
        if let action = action, let tool = tool {
            Text(tool.title).font(.title2).bold()
            Text(action.mode).font(.headline)
            Text(tool.detail)
            if !macBookActionAllowed(action, scope: scope) {
                Text("No disponible para el ámbito elegido. Las consultas locales no miden una MacBook objetivo conectada.").foregroundColor(.orange)
            }
            if category == "Diagnóstico" {
                Text("system_profiler identifica modelo/chip; macOS y ciclos según datos disponibles. pmset ofrece estado térmico, no temperaturas universales. Un sensor ausente no acredita salud.").font(.caption)
            }
            if category == "Firmware" {
                firmwareGuidance
            }
            if category == "Mantenimiento" {
                Text("Cachés: sólo usuario del anfitrión. APFS: verificar la identidad del volumen accesible; reparación desde Recovery. No seleccionar el disco de arranque de otra Mac por suposición.").font(.caption)
            }
        } else { Text("Seleccione una herramienta; para notas y exportación utilice Expediente MacBook.") }
    }
    private var firmwareGuidance: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Revive/Restore oficiales: sólo Apple silicon o Mac con T2, cable/puerto/secuencia DFU correctos y otro Mac compatible. Finder requiere macOS 14+ en el anfitrión. Intel sin T2: Recovery/servicio; no este flujo DFU.").font(.caption)
            Button("Guía oficial de Apple: Revive / Restore") {
                if let url = URL(string: "https://support.apple.com/108900") { NSWorkspace.shared.open(url) }
            }
            Text("La guía no ejecuta Revive/Restore. Revive se intenta primero; Restore borra datos y exige selección y confirmación en la herramienta oficial. El adaptador cfgutil existente sigue experimental y no se ofrece como función validada.").font(.caption)
        }
    }
    @ViewBuilder private var controls: some View {
        if let tool = tool {
            VStack(alignment: .leading, spacing: 8) {
                if tool.id == "network" {
                    TextField("Destino DNS o IPv4 autorizado (opcional; cuatro paquetes)", text: $host)
                }
                if tool.terminal {
                    Toggle("Identifiqué el equipo/volumen y revisaré las confirmaciones del flujo", isOn: $confirmed)
                }
                HStack {
                    Button("Destino de informes") { runner.chooseReports() }.disabled(runner.jobInProgress)
                    Button(tool.terminal ? "Abrir flujo supervisado" : "Consultar ESTA Mac") {
                        guard canRun else { return }
                        runner.run(tool, host: host, expectedHash: "")
                    }.disabled(!canRun)
                }
                Text("Una guía abierta no confirma que una copia, recuperación o reparación haya terminado.").font(.caption)
            }
        }
    }
    private var reportOutput: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(runner.reportFolder?.path ?? "Seleccione una carpeta de informes.").font(.caption)
            Text(runner.notice).font(.caption)
            Text("Salida compartida del Runner: diagnósticos locales = ESTA Mac; identificación del objetivo en sus herramientas oficiales.").font(.caption).bold()
            ScrollView { Text(runner.output).font(.system(.caption, design: .monospaced)).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading) }
            Button("Abrir último informe") { if let url = runner.latestReport { NSWorkspace.shared.open(url) } }.disabled(runner.latestReport == nil)
        }
    }
}
