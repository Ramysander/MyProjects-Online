import SwiftUI
import AppKit

let iosCatalog: [Tool] = [
    Tool(id: "ios-inventory", title: "Inventario y dependencias", category: "Diagnóstico", detail: "Captura USB de la Mac y lista de cfgutil si está instalado. Los candidatos USB no prueban identidad ni confianza. No lee sensores del iPhone.", script: "ios.sh", arguments: ["inventory"], terminal: false),
    Tool(id: "ios-connect", title: "Conexión y confianza", category: "Conexión", detail: "Cable de datos, desbloqueo y autorización en el dispositivo. Abre Finder y la guía de Apple.", script: "ios.sh", arguments: ["connect"], terminal: false),
    Tool(id: "ios-backup", title: "Respaldo cifrado y restauración de copia", category: "Respaldo", detail: "Guía con Finder. El respaldo y su cifrado se configuran allí; la herramienta no captura contraseñas ni verifica que la copia finalizó.", script: "ios.sh", arguments: ["backup"], terminal: false),
    Tool(id: "ios-update", title: "Actualizar iOS / iPadOS", category: "Mantenimiento", detail: "Abre Finder para actualizar el equipo elegido por el operador. Respaldo previo. No actualiza dispositivos automáticamente.", script: "ios.sh", arguments: ["update"], terminal: false),
    Tool(id: "ios-recovery", title: "Recuperación de arranque", category: "Recuperación", detail: "Guías separadas para iPhone e iPad. Intentar Actualizar antes de Restaurar. No fuerza DFU ni extrae datos desde DFU.", script: "ios.sh", arguments: ["recovery"], terminal: false),
    Tool(id: "ios-dfu-detect", title: "Auto-detectar USB / Recovery / DFU", category: "Recuperación", detail: "Monitor de sólo lectura para detectar cambios y candidatos Recovery/DFU. No desbloquea ni modifica el iPhone/iPad.", script: "external-device-detect.sh", arguments: ["watch"], terminal: false),
    Tool(id: "ios-dfu-entry", title: "Entrar / reiniciar en DFU", category: "Recuperación", detail: "Abre un asistente guiado. La entrada real en DFU requiere la secuencia física del modelo; no existe un botón universal seguro que fuerce DFU por software.", script: "DFUEntryAssistant.command", arguments: [], terminal: true),
    Tool(id: "ios-reset", title: "Restaurar a fábrica — BORRA datos", category: "Avanzado", detail: "Flujo oficial en Finder. Seleccionar el objetivo y confirmar allí. No elimina Activation Lock ni administración corporativa.", script: "ios.sh", arguments: ["restore"], terminal: false),
    Tool(id: "ios-health", title: "Batería, almacenamiento y rendimiento", category: "Diagnóstico", detail: "Checklist en el dispositivo: datos disponibles según modelo y versión. No ofrece SMART ni ciclos universales ni temperaturas remotas.", script: "ios.sh", arguments: ["health"], terminal: false),
    Tool(id: "ios-security", title: "Seguridad, red y perfiles", category: "Seguridad", detail: "Revisión guiada de actualizaciones, permisos, VPN/MDM y conectividad. Sin jailbreak ni eliminación de perfiles.", script: "ios.sh", arguments: ["security"], terminal: false),
    Tool(id: "ios-files", title: "Archivos y evidencias", category: "Soporte", detail: "Archivos compartidos por apps compatibles en Finder y registros exportados por el propietario. No acceso al disco completo ni al sistema de archivos protegido.", script: "ios.sh", arguments: ["files"], terminal: false),
    Tool(id: "ios-configurator", title: "Apple Configurator y ayuda cfgutil", category: "Administración", detail: "Abre Configurator y registra ayuda local de cfgutil. Supervisión y despliegue se realizan en la herramienta oficial con autorización.", script: "ios.sh", arguments: ["configurator"], terminal: false),
    Tool(id: "ios-case", title: "Expediente técnico iPhone / iPad", category: "Expedientes", detail: "Registra modelo, síntoma, observaciones antes/después y resultado declarado en un informe privado. No guardar PIN ni contraseñas.", script: "IOSCase.command", arguments: [], terminal: true)
]

struct IOSSupportView: View {
    @ObservedObject var runner: Runner
    @Environment(\.presentationMode) var presentationMode
    @State private var selected: String? = "ios-inventory"
    @State private var acknowledged = false
    @State private var snippets = false
    @State private var expert = false
    private var tool: Tool { iosCatalog.first { $0.id == selected } ?? iosCatalog[0] }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "iphone")
                Text("Soporte TI · iPhone y iPad").font(.title.bold())
                Spacer()
                Button("Centro TI / expedientes") { expert = true }
                Button("Snippets") { snippets = true }
                Button("Cerrar") { presentationMode.wrappedValue.dismiss() }
            }
            Text("Se ejecuta desde esta Mac. El dispositivo objetivo se selecciona en Finder o Configurator.").font(.caption)
            HSplitView {
                List(selection: $selected) {
                    ForEach(iosCatalog) { item in
                        VStack(alignment: .leading) {
                            Text(item.title)
                            Text(item.category).font(.caption).foregroundColor(.secondary)
                        }.tag(item.id)
                    }
                }.frame(minWidth: 270)
                VStack(alignment: .leading, spacing: 12) {
                    Text(tool.title).font(.title2.bold())
                    Text(tool.detail)
                    if tool.id == "ios-reset" {
                        Toggle("Comprendo que Restaurar borra los datos del objetivo", isOn: $acknowledged)
                    }
                    HStack {
                        Button("Destino de informes") { runner.chooseReports() }.disabled(runner.jobInProgress)
                        Button(tool.terminal ? "Abrir expediente en Terminal" : "Ejecutar / abrir guía") {
                            runner.run(tool, host: "", expectedHash: "")
                        }.disabled(runner.jobInProgress || (tool.id == "ios-reset" && !acknowledged))
                    }
                    Text(runner.reportFolder?.path ?? "Seleccione una carpeta escribible para los informes.").font(.caption)
                    Text(runner.notice).font(.caption)
                    ScrollView {
                        Text(runner.output).font(.system(.caption, design: .monospaced))
                            .textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding(10)
                    }.background(Color(NSColor.textBackgroundColor)).cornerRadius(8)
                    Text("Los flujos Finder/Configurator son supervisados. Abrir una guía no significa que el respaldo, actualización o restauración haya terminado.").font(.caption)
                }.padding().frame(minWidth: 560)
            }
            Text("iOS no permite diskutil, reparación APFS, limpieza global de cachés ni lectura del SSD por DFU desde esta Mac.").font(.caption).foregroundColor(.secondary)
        }.padding(20).frame(width: 1050, height: 700)
        .onChange(of: selected) { _ in acknowledged = false }
        .sheet(isPresented: $snippets) { SnippetsView(root: runner.root) }
        .sheet(isPresented: $expert) { ExpertWorkbenchView(runner: runner) }
    }
}
