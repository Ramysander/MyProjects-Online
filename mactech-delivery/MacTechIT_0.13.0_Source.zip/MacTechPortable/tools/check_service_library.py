#!/usr/bin/env python3
"""Synthetic archive/manifest checks and integration inspection. No devices."""
from pathlib import Path
import hashlib
import json
import plistlib
import subprocess
import tempfile
import zipfile

root = Path(__file__).resolve().parents[1]
manifest = {'ProductVersion': '18.0', 'ProductBuildVersion': '22ATEST', 'SupportedProductTypes': ['iPhone15,2', 'iPad14,1']}
with tempfile.TemporaryDirectory(prefix='mactech-fixture-') as temp:
    fixture = Path(temp) / "O'Brien synthetic.ipsw"
    with zipfile.ZipFile(fixture, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('BuildManifest.plist', plistlib.dumps(manifest))
        archive.writestr('payload.txt', 'synthetic, not real firmware')
    result = subprocess.run(['/usr/bin/unzip', '-p', str(fixture), 'BuildManifest.plist'], check=True, capture_output=True)
    assert plistlib.loads(result.stdout) == manifest
    assert 'iPhone99,9' not in plistlib.loads(result.stdout)['SupportedProductTypes']
    digest = hashlib.sha256(fixture.read_bytes()).hexdigest()
    copy = Path(temp) / 'exported.ipsw'
    copy.write_bytes(fixture.read_bytes())
    assert hashlib.sha256(copy.read_bytes()).hexdigest() == digest
    copy.write_bytes(copy.read_bytes() + b'changed')
    assert hashlib.sha256(copy.read_bytes()).hexdigest() != digest
    with zipfile.ZipFile(Path(temp) / 'missing.ipsw', 'w') as archive:
        archive.writestr('unrelated.txt', 'fixture')
    absent = subprocess.run(['/usr/bin/unzip', '-p', str(Path(temp) / 'missing.ipsw'), 'BuildManifest.plist'], capture_output=True)
    assert absent.returncode != 0
builder = (root / 'scripts/build-gui.sh').read_text()
for name in ['DeviceServiceView.swift', 'ServiceLibrary.swift', 'ServiceLibraryCore.swift']:
    assert name in builder
assert 'ServiceLibraryCore.swift' in (root / 'scripts/build.sh').read_text()
assert 'try serviceLibrarySelfTest()' in (root / 'Sources/CaseEngine.swift').read_text()
ui = (root / 'GUI/DeviceServiceView.swift').read_text()
store = (root / 'GUI/ServiceLibrary.swift').read_text()
assert 'compatible' in ui and 'REST' in ui and 'ios-reset' in ui
assert 'serviceFileHash(file)' in ui and 'officialDeviceSession' in ui
assert '.pending-' in store and 'isSymbolicLink' in store
assert 'withIntermediateDirectories: false' in store
assert 'eraseDisk' not in ui + store and 'cfgutil' not in ui + store
assert 'process.arguments = ["-p", url.path, "BuildManifest.plist"]' in store
assert '4_000_000' in store and '60' in store
print('PASS synthetic IPSW extraction (spaces/apostrophe), absent manifest, model mismatch and checksum tampering')
print('PASS library/build integration, bounded metadata reads, staging and official supervised restore routing')
print('NOT RUN: Swift store implementation, GUI, native macOS tools or real firmware/device operations')
