#!/usr/bin/env python3
"""Inspect IT Custom resources and generated Swift grammar, never execute code."""
from pathlib import Path
import json
import re
from tree_sitter import Language, Parser
import tree_sitter_swift

root = Path(__file__).resolve().parents[1]
parser = Parser(Language(tree_sitter_swift.language()))
templates = json.loads((root / 'docs/it-custom-templates.json').read_text())
assert len(templates) == len({item['id'] for item in templates}) == 3
platforms = {'iOS + macOS': '.iOS(.v15), .macOS(.v12)', 'iPhone/iPad': '.iOS(.v15)', 'Macbook': '.macOS(.v12)'}
# Inspect the manifest string actually used by the Swift exporter.
core = (root / 'Sources/ITCustomCore.swift').read_text()
match = re.search(r'let manifest = """\n(.*?)\n        """', core, re.S)
assert match
checked = 0
for template in templates:
    assert set(re.findall(r'\{\{([^}]+)\}\}', template['source'])) <= {'MODULE', 'PLATFORM'}
    for platform, targets in platforms.items():
        source = template['source'].replace('{{MODULE}}', 'LabService').replace('{{PLATFORM}}', platform)
        tests = template['tests'].replace('{{MODULE}}', 'LabService')
        manifest = match[1].replace(r'\(module)', 'LabService').replace(r'\(platforms)', targets)
        for name, text in [('source', source), ('tests', tests), ('manifest', manifest)]:
            assert '{{' not in text
            assert not parser.parse(text.encode()).root_node.has_error, (template['id'], platform, name)
            checked += 1
        assert 'testReportRoundTrip' in tests and 'XCTAssertEqual(decoded, original)' in tests
        assert 'public struct LabServiceRecord' in source
        assert '.library' in manifest and '.testTarget' in manifest
        assert 'dependencies: ["LabService"]' in manifest
# Guards and integration; these checks do not simulate a Swift runtime.
assert '1...5000' in core and 'systemUptime - started > 3' in core
assert 'decodeCustomWorkspace' in core and 'controlCharacters.union(.newlines)' in core
assert 'process.run' not in core and 'Process()' not in core
store = (root / 'GUI/ITCustomStore.swift').read_text()
assert '.pending-' in store and 'isSymbolicLink' in store and 'withoutOverwriting' in store
assert '2_000_001' in store and '16_000_000' in store
assert 'Process()' not in store
assert 'options: [.atomic, .withoutOverwriting]' not in store
for name in ['build.sh', 'build-gui.sh']:
    assert 'ITCustomCore.swift' in (root / 'scripts' / name).read_text()
assert 'ITCustomView.swift' in (root / 'scripts/build-gui.sh').read_text()
assert 'it-custom-templates.json' in (root / 'scripts/build.sh').read_text()
for name in ['MacTechIT.swift', 'IOSSupportView.swift', 'MacBookSupportView.swift']:
    assert 'Button("IT Custom")' in (root / 'GUI' / name).read_text()
assert 'try itCustomSelfTest(templates)' in (root / 'Sources/CaseEngine.swift').read_text()
print(f'PASS 3 templates x 3 platforms; {checked} generated Swift source/test/manifest grammar checks')
print('PASS resource tokens, package targets, limits, text-only export and entry points')
print('NOT RUN: Swift compilation/selftests, fuzz runner implementation, GUI or device operations')
