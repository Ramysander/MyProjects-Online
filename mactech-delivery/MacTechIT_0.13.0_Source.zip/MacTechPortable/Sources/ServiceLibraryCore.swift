import Foundation
import CryptoKit

struct FirmwareIdentity: Codable, Equatable {
    let version: String
    let build: String
    let products: [String]
    static func parse(_ data: Data) throws -> FirmwareIdentity {
        guard data.count <= 4_000_000,
              let manifest = try PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
              let version = manifest["ProductVersion"] as? String,
              let build = manifest["ProductBuildVersion"] as? String,
              let products = manifest["SupportedProductTypes"] as? [String],
              !version.isEmpty, version.count <= 50, !build.isEmpty, build.count <= 50,
              !products.isEmpty, products.count <= 500,
              products.allSatisfy({ $0.range(of: "^(iPhone|iPad)[0-9]+,[0-9]+$", options: .regularExpression) != nil }) else {
            throw libraryError("BuildManifest de iPhone/iPad inválido o no compatible con este repositorio")
        }
        return FirmwareIdentity(version: version, build: build, products: products)
    }
    func validate() throws {
        guard !version.isEmpty, version.count <= 50, !build.isEmpty, build.count <= 50,
              !products.isEmpty, products.count <= 500,
              products.allSatisfy({ $0.range(of: "^(iPhone|iPad)[0-9]+,[0-9]+$", options: .regularExpression) != nil }) else { throw libraryError("Identidad firmware inválida") }
    }
    func matches(_ product: String) -> Bool { products.contains(product) }
}
struct ServiceLibraryRecord: Codable, Identifiable {
    var schema = 1
    let id: String
    let category: String
    let filename: String
    let created: Date
    let bytes: Int64
    let sha256: String?
    let firmware: FirmwareIdentity?
    let deviceLabel: String
    func validate() throws {
        guard schema == 1, UUID(uuidString: id) != nil,
              serviceCategories.contains(category), !filename.isEmpty, filename != ".", filename != "..",
              !filename.contains("/"), !filename.contains("\\"), filename.count <= 255,
              !filename.unicodeScalars.contains(where: { CharacterSet.controlCharacters.union(.newlines).contains($0) }),
              deviceLabel.count <= 200, bytes >= 0 else { throw libraryError("Registro inválido") }
        if let hash = sha256 {
            guard hash.range(of: "^[0-9a-f]{64}$", options: .regularExpression) != nil else { throw libraryError("Checksum inválido") }
        }
        if category == "Firmware" {
            guard filename.lowercased().hasSuffix(".ipsw"), let identity = firmware, sha256 != nil else { throw libraryError("Firmware incompleto") }
            try identity.validate()
        }
    }
}
let serviceCategories = ["Vídeos", "Música", "Aplicaciones", "Documentos", "Firmware", "Respaldos"]
func libraryError(_ message: String) -> NSError {
    NSError(domain: "ServiceLibrary", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
}
func serviceFileHash(_ url: URL) throws -> String {
    let handle = try FileHandle(forReadingFrom: url)
    defer { try? handle.close() }
    var hash = SHA256()
    while let data = try handle.read(upToCount: 1_048_576), !data.isEmpty { hash.update(data: data) }
    return hash.finalize().map { String(format: "%02x", $0) }.joined()
}
func serviceLibrarySelfTest() throws {
    let values: [String: Any] = ["ProductVersion": "18.0", "ProductBuildVersion": "22A000", "SupportedProductTypes": ["iPhone15,2", "iPad14,1"]]
    let data = try PropertyListSerialization.data(fromPropertyList: values, format: .xml, options: 0)
    let firmware = try FirmwareIdentity.parse(data)
    guard firmware.matches("iPhone15,2"), !firmware.matches("iPhone99,9") else { throw libraryError("Compatibilidad de fixture incorrecta") }
    let record = ServiceLibraryRecord(id: UUID().uuidString, category: "Firmware", filename: "test.ipsw", created: Date(), bytes: 1, sha256: String(repeating: "a", count: 64), firmware: firmware, deviceLabel: "Laboratorio")
    try record.validate()
    let decoded = try JSONDecoder().decode(ServiceLibraryRecord.self, from: JSONEncoder().encode(record))
    guard decoded.firmware == firmware else { throw libraryError("Serialización firmware") }
    let bad = ServiceLibraryRecord(id: record.id, category: "Documentos", filename: "../escape", created: Date(), bytes: 0, sha256: nil, firmware: nil, deviceLabel: "")
    func rejected(_ action: () throws -> Void) throws {
        do { try action() } catch { return }
        throw libraryError("Fixture inválido aceptado")
    }
    try rejected { try bad.validate() }
    try rejected { _ = try FirmwareIdentity.parse(Data("not a plist".utf8)) }
    let other = FirmwareIdentity(version: "1", build: "x", products: ["Mac14,1"])
    try rejected { try other.validate() }
}
