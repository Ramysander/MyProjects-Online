import Foundation
import Combine

// Disk work runs off the UI thread. No device commands are issued here.
final class ServiceLibrary: ObservableObject {
    @Published var records: [ServiceLibraryRecord] = []
    @Published var message = "Biblioteca local: importar no transfiere datos a un dispositivo."
    @Published var working = false
    let root: URL
    init() {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        root = documents.appendingPathComponent("MacTech IT Library", isDirectory: true)
    }
    func ensureRoot() throws {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        guard (try root.resourceValues(forKeys: [.isSymbolicLinkKey])).isSymbolicLink != true else { throw libraryError("La raíz no puede ser un enlace") }
    }
    private func checked(_ url: URL, directory: Bool) throws {
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey])
        guard values.isSymbolicLink != true, directory ? values.isDirectory == true : values.isRegularFile == true else { throw libraryError("Seleccione un archivo/carpeta regular, sin enlaces simbólicos") }
    }
    func payload(_ record: ServiceLibraryRecord) throws -> URL {
        try record.validate()
        let folder = root.appendingPathComponent(record.id, isDirectory: true)
        try checked(folder, directory: true)
        let file = folder.appendingPathComponent(record.filename)
        try checked(file, directory: record.category == "Respaldos")
        return file
    }
    private func readManifest(_ url: URL) throws -> FirmwareIdentity {
        let process = Process(); let pipe = Pipe()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/unzip")
        process.arguments = ["-p", url.path, "BuildManifest.plist"]
        process.standardOutput = pipe; process.standardError = FileHandle.nullDevice; process.standardInput = FileHandle.nullDevice
        try process.run()
        DispatchQueue.global().asyncAfter(deadline: .now() + 60) { if process.isRunning { process.terminate() } }
        var data = Data()
        while true {
            let chunk = pipe.fileHandleForReading.readData(ofLength: 65_536)
            if chunk.isEmpty { break }
            data.append(chunk)
            if data.count > 4_000_000 {
                process.terminate(); try? pipe.fileHandleForReading.close(); process.waitUntilExit()
                throw libraryError("BuildManifest excesivo")
            }
        }
        process.waitUntilExit()
        guard process.terminationStatus == 0 else { throw libraryError("IPSW ilegible o sin BuildManifest.plist") }
        return try FirmwareIdentity.parse(data)
    }
    func refresh() throws -> [ServiceLibraryRecord] {
        try ensureRoot()
        let folders = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])
        guard folders.count <= 5000 else { throw libraryError("Más de 5.000 elementos; divida la biblioteca") }
        var rows: [ServiceLibraryRecord] = []; var rejected = 0
        for folder in folders {
            do {
                guard UUID(uuidString: folder.lastPathComponent) != nil else { continue }
                try checked(folder, directory: true)
                let file = folder.appendingPathComponent("record.json")
                try checked(file, directory: false)
                guard ((try file.resourceValues(forKeys: [.fileSizeKey])).fileSize ?? Int.max) <= 1_000_000 else { throw libraryError("Registro demasiado grande") }
                let row = try JSONDecoder().decode(ServiceLibraryRecord.self, from: Data(contentsOf: file))
                guard row.id == folder.lastPathComponent else { throw libraryError("ID discrepante") }
                _ = try payload(row); rows.append(row)
            } catch { rejected += 1 }
        }
        if rejected > 0 { throw libraryError("Hay \(rejected) registros inválidos; revise la biblioteca sin modificarlos. No se ha cargado un listado parcial.") }
        return rows.sorted { $0.created > $1.created }
    }
    func importItem(_ source: URL, category: String, device: String) throws {
        guard serviceCategories.contains(category), device.count <= 200 else { throw libraryError("Categoría o identificación inválida") }
        try ensureRoot()
        let directory = category == "Respaldos"
        try checked(source, directory: directory)
        guard !source.resolvingSymlinksInPath().path.hasPrefix(root.resolvingSymlinksInPath().path + "/"), source.resolvingSymlinksInPath() != root.resolvingSymlinksInPath() else { throw libraryError("No reimporte la propia biblioteca") }
        if directory && root.resolvingSymlinksInPath().path.hasPrefix(source.resolvingSymlinksInPath().path + "/") {
            throw libraryError("La carpeta origen contiene la biblioteca; no se permite copiar dentro de sí misma")
        }
        if directory {
            // Do not traverse aliases/symlinks into unrelated user folders.
            var enumerationFailed = false
            guard let enumerator = FileManager.default.enumerator(at: source, includingPropertiesForKeys: [.isSymbolicLinkKey], errorHandler: { _, _ in enumerationFailed = true; return false }) else { throw libraryError("No se pudo leer el respaldo") }
            var count = 0
            for case let url as URL in enumerator {
                count += 1
                guard count <= 1_000_000, (try url.resourceValues(forKeys: [.isSymbolicLinkKey])).isSymbolicLink != true else { throw libraryError("Respaldo excesivo o con enlaces simbólicos") }
            }
            if enumerationFailed { throw libraryError("No se pudieron inspeccionar todos los archivos del respaldo") }
        }
        if category == "Firmware", source.pathExtension.lowercased() != "ipsw" { throw libraryError("Seleccione un .ipsw oficial descargado por el técnico") }
        let id = UUID().uuidString
        let staging = root.appendingPathComponent(".pending-" + id, isDirectory: true)
        try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        let copy = staging.appendingPathComponent(source.lastPathComponent)
        guard source.lastPathComponent != "record.json" else { throw libraryError("Nombre reservado: record.json") }
        try FileManager.default.copyItem(at: source, to: copy)
        if !directory { try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: copy.path) }
        let firmware = category == "Firmware" ? try readManifest(copy) : nil
        let hash = directory ? nil : try serviceFileHash(copy)
        let bytes = directory ? 0 : Int64((try copy.resourceValues(forKeys: [.fileSizeKey])).fileSize ?? 0)
        let record = ServiceLibraryRecord(id: id, category: category, filename: source.lastPathComponent, created: Date(), bytes: bytes, sha256: hash, firmware: firmware, deviceLabel: device)
        try record.validate()
        let json = staging.appendingPathComponent("record.json")
        try JSONEncoder().encode(record).write(to: json, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: json.path)
        try FileManager.default.moveItem(at: staging, to: root.appendingPathComponent(id, isDirectory: true))
    }
}
