import SwiftUI
import AppKit

struct DeviceServiceView: View {
    @ObservedObject var runner: Runner
    @StateObject private var library = ServiceLibrary()
    @Environment(\.presentationMode) private var presentationMode
    @State private var category = "Documentos"
    @State private var selected: String?
    @State private var search = ""
    @State private var versionFilter = "Todas"
    @State private var device = ""
    @State private var product = ""
    @State private var phrase = ""
    @State private var restoreAcknowledged = false
    private var row: ServiceLibraryRecord? { filtered.first { $0.id == selected } }
    private var blocked: Bool { runner.jobInProgress || library.working }
    private var firmwareVersions: [String] {
        Array(Set(library.records.compactMap { $0.firmware?.version })).sorted { left, right in
            left.compare(right, options: .numeric) == .orderedDescending
        }
    }
    private var filtered: [ServiceLibraryRecord] {
        library.records.filter { item in
            guard item.category == category else { return false }
            if category == "Firmware", versionFilter != "Todas", item.firmware?.version != versionFilter { return false }
            let fields: [String] = [item.filename, item.deviceLabel, item.firmware?.version ?? "", item.firmware?.build ?? ""]
            return search.isEmpty || fields.joined(separator: " ").localizedCaseInsensitiveContains(search)
        }
    }
    private var compatible: Bool {
        guard let item = row, let firmware = item.firmware else { return false }
        return firmware.matches(product) && restoreAcknowledged && phrase == "RESTAURAR " + product
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            filters.disabled(blocked)
            if runner.officialDeviceSession { officialSessionControls }
            HSplitView { records.disabled(blocked); details.disabled(blocked) }
            Text(library.message).font(.caption).textSelection(.enabled)
            Text("Biblioteca local, no un acceso universal al dispositivo. Finder controla confianza, sincronización, respaldos y restauraciones. Activation Lock y MDM no se eliminan.").font(.caption)
        }.padding(20).frame(minWidth: 1100, minHeight: 760)
        .onAppear { refresh() }
        .onChange(of: selected) { _ in phrase = ""; restoreAcknowledged = false }
        .onChange(of: category) { _ in selected = nil; phrase = ""; restoreAcknowledged = false; versionFilter = "Todas" }
        .onChange(of: product) { _ in phrase = ""; restoreAcknowledged = false }
    }
    private var header: some View {
        HStack {
            Text("Centro de dispositivos y biblioteca").font(.title2).bold()
            Spacer()
            Button("Abrir biblioteca") { NSWorkspace.shared.open(library.root) }.disabled(blocked)
            Button("Cerrar") { presentationMode.wrappedValue.dismiss() }.disabled(library.working)
        }
    }
    private var filters: some View {
        VStack(alignment: .leading, spacing: 8) {
            Picker("Biblioteca", selection: $category) { ForEach(serviceCategories, id: \.self) { Text($0).tag($0) } }
            if category == "Firmware" {
                Picker("Versión de firmware", selection: $versionFilter) {
                    ForEach(["Todas"] + firmwareVersions, id: \.self) { Text($0).tag($0) }
                }
            }
            TextField("Buscar archivo, dispositivo, versión o build", text: $search)
            TextField("Etiqueta del dispositivo/cliente (sin contraseñas ni claves)", text: $device)
            HStack {
                Button(category == "Respaldos" ? "Archivar carpeta de respaldo" : "Importar archivo local") { importLocal() }.disabled(blocked)
                Button("Actualizar") { refresh() }.disabled(blocked)
                Button("Abrir Finder para iPhone/iPad") { NSWorkspace.shared.open(URL(fileURLWithPath: "/System/Library/CoreServices/Finder.app")) }.disabled(blocked)
            }
        }
    }
    private var officialSessionControls: some View {
        HStack {
            Text("Sesión Finder reservada: espere a que termine el respaldo/restauración antes de iniciar otras tareas.").font(.caption)
            Button("Confirmar fin de sesión Finder") {
                let alert = NSAlert()
                alert.messageText = "¿Finder terminó o canceló la operación?"
                alert.informativeText = "Sólo libera el bloqueo de la GUI. No cancela ni comprueba procesos o dispositivos."
                alert.addButton(withTitle: "Mantener bloqueo")
                alert.addButton(withTitle: "Confirmo que terminó")
                if alert.runModal() == .alertSecondButtonReturn { runner.officialDeviceSession = false }
            }
        }
    }
    private var records: some View {
        List(selection: $selected) {
            ForEach(filtered) { item in
                LibraryRecordRow(record: item).tag(item.id)
            }
        }.frame(minWidth: 300)
    }
    private var details: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if let item = row {
                    recordDetails(item)
                    HStack {
                        Button("Mostrar en Finder") { reveal(item) }.disabled(blocked)
                        Button("Exportar copia…") { export(item) }.disabled(blocked)
                        if item.sha256 != nil { Button("Verificar SHA-256") { verify(item) }.disabled(blocked) }
                    }
                    if item.firmware != nil { firmwareControls }
                }
                transferGuidance
                backupGuidance
            }.padding()
        }.frame(minWidth: 680)
    }
    private func recordDetails(_ item: ServiceLibraryRecord) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(item.filename).font(.headline)
            Text(item.deviceLabel).font(.caption)
            Text(item.created.formatted()).font(.caption)
            Text(item.category == "Respaldos" ? "Copia archivada; tamaño y restaurabilidad no certificados." : "\(item.bytes) bytes").font(.caption)
            Text("SHA-256: " + (item.sha256 ?? "Sin hash de árbol de respaldo")).font(.caption).textSelection(.enabled)
            if let firmware = item.firmware {
                Text("iOS/iPadOS \(firmware.version) · build \(firmware.build)").bold()
                Text("Productos declarados en el manifiesto: " + firmware.products.joined(separator: ", ")).font(.caption)
                Text("Manifiesto y hash no autentican origen Apple ni estado de firma. La versión puede haber dejado de estar firmada y Finder rechazarla.").font(.caption)
            }
        }
    }
    private var firmwareControls: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Restauración supervisada con IPSW local").font(.headline)
            TextField("ProductType declarado del objetivo, por ejemplo iPhone15,2", text: $product)
            Toggle("Verifiqué objetivo y respaldo; entiendo que Restaurar borra datos", isOn: $restoreAcknowledged)
            TextField("Escriba exactamente: RESTAURAR " + product, text: $phrase)
            Text("Coincidencia sólo contra el manifiesto: no detecta la identidad del equipo conectado. En Finder mantenga Option (⌥) al pulsar Restaurar y elija el IPSW mostrado. Apple valida compatibilidad, firma y activación; no hay flasheo automático ni downgrade forzado.").font(.caption)
            Button("Abrir restauración oficial y mostrar IPSW") { openRestore() }.disabled(blocked || !compatible)
        }
    }
    private var transferGuidance: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Transferir vídeos, música, apps y documentos").font(.headline)
            Text("Importar/Exportar copia sólo trabaja con carpetas accesibles de ESTA Mac. Para iPhone/iPad: Finder > dispositivo > Archivos permite enviar/recibir documentos de apps compatibles; arrastre archivos allí o al Mac. Vídeo/música se sincronizan en sus pestañas o en Música/TV según el contenido. No hay acceso al disco completo del dispositivo.").font(.caption)
            Text("Aplicaciones: .ipa, instaladores Mac o ZIP de .app pueden archivarse localmente. Instalar requiere App Store, Configurator o un despliegue autorizado con firma y permisos válidos; no se instala cualquier IPA ni se exportan apps protegidas desde el teléfono.").font(.caption)
            Link("Guía oficial de archivos en Finder", destination: URL(string: "https://support.apple.com/119585")!)
        }
    }
    private var backupGuidance: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Respaldos de dispositivos").font(.headline)
            Text("Finder crea las copias iPhone/iPad, con cifrado si se selecciona allí. No se capturan contraseñas. Espere a que termine antes de archivar una copia completa; nunca archive mientras Finder escribe. La biblioteca no cambia la ruta de MobileSync ni certifica restauración. MacBook: Time Machine o copia supervisada desde el módulo Macbook.").font(.caption)
            HStack {
                Button("Abrir flujo de respaldo iPhone/iPad") { openBackup() }.disabled(blocked)
                Button("Mostrar respaldos Finder") { showFinderBackups() }.disabled(blocked)
            }
        }
    }
    private func perform(after: (() -> Void)? = nil, _ work: @escaping () throws -> String) {
        guard !blocked else { return }
        library.working = true; runner.busy = true; library.message = "Procesando archivos locales…"
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let message = try work()
                let rows = try library.refresh()
                DispatchQueue.main.async { library.records = rows; library.message = message; library.working = false; runner.busy = false; after?() }
            } catch {
                DispatchQueue.main.async { library.message = error.localizedDescription; library.working = false; runner.busy = false }
            }
        }
    }
    private func refresh() { perform { "Biblioteca actualizada. Los hashes se comprueban sólo al solicitar verificación/exportación." } }
    private func importLocal() {
        let panel = NSOpenPanel(); panel.canChooseFiles = category != "Respaldos"; panel.canChooseDirectories = category == "Respaldos"
        panel.allowsMultipleSelection = false; panel.treatsFilePackagesAsDirectories = false
        guard panel.runModal() == .OK, let url = panel.url else { return }
        let chosenCategory = category; let label = device
        perform { try library.importItem(url, category: chosenCategory, device: label); return "Copia local importada. No se ha transferido al dispositivo ni comprobado su restaurabilidad." }
    }
    private func reveal(_ item: ServiceLibraryRecord) {
        do { NSWorkspace.shared.activateFileViewerSelecting([try library.payload(item)]) }
        catch { library.message = error.localizedDescription }
    }
    private func verify(_ item: ServiceLibraryRecord) {
        perform {
            let file = try library.payload(item)
            guard let expected = item.sha256, try serviceFileHash(file) == expected else { throw libraryError("SHA-256 discrepante; no use este archivo") }
            return "SHA-256 coincide con el registro local; no acredita autoría ni firma Apple."
        }
    }
    private func export(_ item: ServiceLibraryRecord) {
        let panel = NSOpenPanel(); panel.canChooseDirectories = true; panel.canChooseFiles = false
        guard panel.runModal() == .OK, let folder = panel.url else { return }
        perform {
            let file = try library.payload(item)
            let destination = folder.appendingPathComponent(item.filename)
            guard !FileManager.default.fileExists(atPath: destination.path), !folder.resolvingSymlinksInPath().path.hasPrefix(library.root.resolvingSymlinksInPath().path + "/"), folder.resolvingSymlinksInPath() != library.root.resolvingSymlinksInPath() else { throw libraryError("Destino existente o dentro de la biblioteca; no se sobrescribe") }
            if let expected = item.sha256, try serviceFileHash(file) != expected { throw libraryError("Checksum discrepante") }
            guard !folder.resolvingSymlinksInPath().path.hasPrefix(file.resolvingSymlinksInPath().path + "/") else { throw libraryError("Destino dentro del origen") }
            try FileManager.default.copyItem(at: file, to: destination)
            if let expected = item.sha256, try serviceFileHash(destination) != expected { throw libraryError("La copia exportada no coincide con el checksum; no la use") }
            return "Copia exportada al destino elegido. No certifica transferencia a iOS ni restauración de respaldo."
        }
    }
    private func openRestore() {
        guard compatible, !blocked, let item = row else { return }
        perform(after: {
            guard let tool = iosCatalog.first(where: { $0.id == "ios-reset" }) else { return }
            runner.run(tool, host: "", expectedHash: "")
            if runner.busy || runner.terminalOpening { runner.officialDeviceSession = true }
        }) {
            let file = try library.payload(item)
            guard let expected = item.sha256, try serviceFileHash(file) == expected else { throw libraryError("SHA-256 discrepante") }
            DispatchQueue.main.async { NSWorkspace.shared.activateFileViewerSelecting([file]) }
            return "IPSW mostrado y flujo supervisado abierto en Terminal. En Finder use Option + Restaurar y seleccione este IPSW; todavía no se ha verificado ninguna restauración."
        }
    }
    private func openBackup() {
        guard !blocked, let tool = iosCatalog.first(where: { $0.id == "ios-backup" }) else { return }
        runner.run(tool, host: "", expectedHash: "")
        if runner.busy || runner.terminalOpening { runner.officialDeviceSession = true }
    }
    private func showFinderBackups() {
        let folder = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support/MobileSync/Backup", isDirectory: true)
        if FileManager.default.fileExists(atPath: folder.path) { NSWorkspace.shared.open(folder) }
        else { library.message = "No existe la carpeta local de respaldos Finder para este usuario. Cree primero un respaldo desde Finder." }
    }
}
private struct LibraryRecordRow: View {
    let record: ServiceLibraryRecord
    var body: some View {
        VStack(alignment: .leading) {
            Text(record.filename)
            Text(record.firmware?.version ?? record.deviceLabel).font(.caption)
        }
    }
}
