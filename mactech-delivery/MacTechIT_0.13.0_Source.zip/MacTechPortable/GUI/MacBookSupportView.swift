import SwiftUI
import AppKit

struct MacBookSupportView: View {
    @ObservedObject var runner: Runner
    @Environment(\.presentationMode) private var presentationMode
    @State private var category = "Diagnóstico"
    @State private var selected: String? = "diag"
    @State private var scope = "host"
    @State private var family = "MacBook Air"
    @State private var identity = ""
    @State private var host = ""
    @State private var confirmed = false
    @State private var destructivePhrase = ""
    @State private var backupReviewed = false
    @State private var snippets = false
    @State private var custom = false
    @State private var service = false
    @State private var expert = false
    private var action: MacBookAction? { macBookActions.first { $0.id == selected && $0.category == category } }
    private var tool: Tool? { catalog.first { $0.id == selected } }
    private var targetIdentified: Bool { scope == "host" || !identity.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    private var destructive: Bool { selected == "erase" || selected == "reset" }
    private var expectedPhrase: String { selected == "reset" ? "BORRAR ESTA MAC" : "BORRAR DISCO EXTERNO" }
    private var canRun: Bool {
        guard let action = action, let tool = tool else { return false }
        return macBookActionAllowed(action, scope: scope) && targetIdentified && !runner.jobInProgress && (!tool.terminal || confirmed) && (!destructive || (backupReviewed && destructivePhrase == expectedPhrase)) &&
            (action.id != "network" || host.isEmpty || validSnippetParameter(host, kind: "host"))
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            context
            HSplitView {
                navigation
                detail
            }
            Text("MacBook Air / MacBook Pro únicamente. No hay acceso remoto automático a batería, FileVault, sensores o CPU de una MacBook conectada. DFU no expone archivos.").font(.caption)
        }.padding(20).frame(minWidth: 1050, minHeight: 720)
        .onChange(of: selected) { _ in confirmed = false; destructivePhrase = ""; backupReviewed = false }
        .onChange(of: scope) { _ in confirmed = false; destructivePhrase = ""; backupReviewed = false }
        .onChange(of: identity) { _ in confirmed = false; destructivePhrase = ""; backupReviewed = false }
        .onChange(of: family) { _ in confirmed = false; destructivePhrase = ""; backupReviewed = false }
        .sheet(isPresented: $snippets) { SnippetsView(root: runner.root, initialCollection: "macOS experto", runner: runner) }
        .sheet(isPresented: $custom) { ITCustomView(runner: runner) }
        .sheet(isPresented: $service) { DeviceServiceView(runner: runner) }
        .sheet(isPresented: $expert) {
            ExpertWorkbenchView(runner: runner, initialAsset: family + " · " + (scope == "host" ? "ESTA Mac anfitriona (identidad por confirmar)" : "Objetivo declarado: " + identity), initialReport: scope == "host" ? runner.latestReport : nil)
        }
    }
    private var header: some View {
        HStack {
            Text("Macbook · soporte MacBook Air / Pro").font(.title2).bold()
            Spacer()
            Button("Expediente MacBook") { expert = true }.disabled(!targetIdentified)
            Button("Snippets macOS experto") { snippets = true }
            Button("IT Custom") { custom = true }
            Button("Archivos / firmware / respaldos") { service = true }
            Button("Cerrar") { presentationMode.wrappedValue.dismiss() }
        }
    }
    private var context: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Picker("Equipo", selection: $scope) {
                    Text("ESTA Mac anfitriona").tag("host")
                    Text("MacBook objetivo conectada").tag("target")
                }.pickerStyle(.segmented)
                Picker("Familia declarada", selection: $family) {
                    Text("MacBook Air").tag("MacBook Air")
                    Text("MacBook Pro").tag("MacBook Pro")
                }
            }
            if scope == "target" {
                TextField("Identificación manual del objetivo (modelo / etiqueta; nunca contraseñas)", text: $identity)
            }
            Text(scope == "host" ? "Todas las métricas locales corresponden a ESTA Mac. Confirme que es la MacBook declarada; escoger una familia no verifica el modelo." : "Diagnóstico remoto no disponible. El inventario observa buses del anfitrión; identidad y modo del objetivo deben confirmarse en Finder/Configurator.").font(.caption)
        }
    }
    private var visibleActions: [MacBookAction] {
        macBookActions.filter { action in action.category == category }
    }
    private var navigation: some View {
        VStack(alignment: .leading) {
            categoryPicker
            actionList
        }
        .frame(minWidth: 260)
        .onChange(of: category) { value in
            selected = macBookActions.first(where: { action in action.category == value })?.id
        }
    }
    private var categoryPicker: some View {
        Picker("Categoría", selection: $category) {
            ForEach(macBookCategories, id: \.self) { name in
                Text(name).tag(name)
            }
        }
    }
    private var actionList: some View {
        List(selection: $selected) {
            ForEach(visibleActions) { action in
                MacBookActionRow(action: action).tag(action.id)
            }
        }
    }
    private var detail: some View {
        VStack(alignment: .leading, spacing: 10) {
            actionDescription
            controls
            reportOutput
        }.padding().frame(minWidth: 600)
    }
    @ViewBuilder private var actionDescription: some View {
        if let action = action, let tool = tool {
            Text(tool.title).font(.title2).bold()
            Text(action.mode).font(.headline)
            Text(tool.detail)
            if !macBookActionAllowed(action, scope: scope) {
                Text("No disponible para el ámbito elegido. Las consultas locales no miden una MacBook objetivo conectada.").foregroundColor(.orange)
            }
            if category == "Diagnóstico" {
                Text("system_profiler identifica modelo/chip; macOS y ciclos según datos disponibles. pmset ofrece estado térmico, no temperaturas universales. Un sensor ausente no acredita salud.").font(.caption)
            }
            if category == "Firmware" {
                firmwareGuidance
            }
            if category == "Mantenimiento" {
                Text("Cachés: sólo usuario del anfitrión. APFS: verificar la identidad del volumen accesible; reparación desde Recovery. No seleccionar el disco de arranque de otra Mac por suposición.").font(.caption)
            }
        } else { Text("Seleccione una herramienta; para notas y exportación utilice Expediente MacBook.") }
    }
    private var firmwareGuidance: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Revive/Restore oficiales: sólo Apple silicon o Mac con T2, cable/puerto/secuencia DFU correctos y otro Mac compatible. Finder requiere macOS 14+ en el anfitrión. Intel sin T2: Recovery/servicio; no este flujo DFU.").font(.caption)
            Button("Guía oficial de Apple: Revive / Restore") {
                if let url = URL(string: "https://support.apple.com/108900") { NSWorkspace.shared.open(url) }
            }
            Text("La guía no ejecuta Revive/Restore. Revive se intenta primero; Restore borra datos y exige selección y confirmación en la herramienta oficial. El adaptador cfgutil existente sigue experimental y no se ofrece como función validada.").font(.caption)
        }
    }
    @ViewBuilder private var controls: some View {
        if let tool = tool {
            VStack(alignment: .leading, spacing: 8) {
                if tool.id == "network" {
                    TextField("Destino DNS o IPv4 autorizado (opcional; cuatro paquetes)", text: $host)
                }
                if tool.terminal {
                    Toggle("Identifiqué el equipo/volumen y revisaré las confirmaciones del flujo", isOn: $confirmed)
                }
                if destructive { destructiveControls }
                HStack {
                    Button("Destino de informes") { runner.chooseReports() }.disabled(runner.jobInProgress)
                    Button(tool.terminal ? "Abrir flujo supervisado" : "Consultar ESTA Mac") {
                        guard canRun else { return }
                        runner.run(tool, host: host, expectedHash: "")
                    }.disabled(!canRun)
                }
                Text("Una guía abierta no confirma que una copia, recuperación o reparación haya terminado.").font(.caption)
            }
        }
    }
    private var destructiveControls: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(selected == "reset" ? "Se borrarán los datos de ESTA Mac, no de la MacBook conectada. Elegibilidad y autenticación se verifican en Erase Assistant." : "Se borrarán TODAS las particiones del disco físico externo que identifique en Terminal. Elegirá APFS o ExFAT. No es un borrado seguro certificado ni una instalación de macOS.").foregroundColor(.red)
            Toggle("Verifiqué un respaldo recuperable o asumí expresamente la pérdida de datos", isOn: $backupReviewed)
            TextField("Escriba exactamente: " + expectedPhrase, text: $destructivePhrase)
            Text("La confirmación del panel no sustituye la identificación, frase y autenticación del flujo supervisado.").font(.caption)
        }
    }
    private var reportOutput: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(runner.reportFolder?.path ?? "Seleccione una carpeta de informes.").font(.caption)
            Text(runner.notice).font(.caption)
            Text("Salida compartida del Runner: diagnósticos locales = ESTA Mac; identificación del objetivo en sus herramientas oficiales.").font(.caption).bold()
            ScrollView { Text(runner.output).font(.system(.caption, design: .monospaced)).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading) }
            Button("Abrir último informe") { if let url = runner.latestReport { NSWorkspace.shared.open(url) } }.disabled(runner.latestReport == nil)
        }
    }
}


private struct MacBookActionRow: View {
    let action: MacBookAction
    private var title: String {
        catalog.first(where: { tool in tool.id == action.id })?.title ?? action.id
    }
    private var scopeLabel: String {
        switch action.scope {
        case "host": return "ESTA Mac"
        case "target": return "Objetivo / guía"
        default: return "Selección supervisada"
        }
    }
    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
            Text(scopeLabel).font(.caption)
        }
    }
}
