# Centro de dispositivos y biblioteca — 0.12.0

## Qué incorpora
Botón **Dispositivos / archivos** en la ventana principal y **Archivos / firmware / respaldos** en Macbook/iPhone/iPad. Biblioteca local con importación/exportación de copias, metadatos y repositorio de IPSW. No es un reemplazo completo de iTunes: Finder, Música, TV, App Store y Configurator mantienen sus funciones oficiales.

## Archivos y aplicaciones
Seleccione Vídeos, Música, Aplicaciones o Documentos; introduzca una etiqueta sin secretos; importe un archivo local. Queda una copia en `~/Documents/MacTech IT Library/<UUID>/` con registro y SHA-256. Puede buscar, mostrar en Finder, verificar o exportar a una carpeta accesible. Exportar rechaza destinos existentes y no sobrescribe. Los archivos grandes se procesan fuera de UI y el hash usa bloques de 1 MB; no hay indicador porcentual ni cancelación de copia en esta versión. Espere a que finalice.

Para iPhone/iPad conecte, desbloquee y autorice confianza, abra Finder y seleccione el equipo. En **Archivos**, copie hacia/desde aplicaciones que admiten compartir documentos. Para música/vídeo use las pestañas de sincronización y Música/TV según el contenido, permisos y configuración de sincronización en nube. MacTech no lee todo el sistema de archivos iOS. La importación a biblioteca no equivale a subir al dispositivo.

Los IPA, instaladores Mac y ZIP de .app pueden archivarse localmente. Instalación sólo mediante App Store, Configurator o despliegue con firma/autorización válidas. No se instala cualquier IPA ni se extraen aplicaciones protegidas del teléfono. Para .app local, comprima primero el paquete en ZIP; el importador de archivos no copia paquetes/directorios de aplicaciones.

Referencias oficiales:
- Archivos Finder: https://support.apple.com/119585
- Apple Configurator: https://support.apple.com/guide/apple-configurator-mac/welcome/mac

## Repositorio de firmware
Seleccione Firmware e importe un `.ipsw` obtenido por el técnico de una fuente confiable. Se copia y se calcula SHA-256. `unzip -p` lee sólo BuildManifest.plist (máximo 4 MB y proceso limitado a 60 s); no extrae el sistema ni ejecuta el contenido. El registro muestra ProductVersion, ProductBuildVersion y SupportedProductTypes. Filtre por versión y busque por build o etiqueta. No se incluyen firmware ni enlaces de descarga de terceros.

El manifiesto es información del archivo, no prueba de origen Apple. El hash local detecta cambios respecto de esa copia, no autoría. No se comprueba firma Apple ni elegibilidad de downgrade en vivo. Una imagen antigua puede haber dejado de estar firmada. No se certifica la integridad ZIP completa por leer sólo el manifiesto.

Para restaurar:
1. Identifique el ProductType real del objetivo, no sólo su nombre comercial. La entrada es manual; la app no valida que el equipo conectado coincida.
2. Seleccione la imagen compatible según su manifiesto, confirme respaldo/riesgo y escriba `RESTAURAR <ProductType>`.
3. **Abrir restauración oficial y mostrar IPSW** vuelve a comprobar SHA-256, muestra el archivo y abre el launcher supervisado en Terminal.
4. Identifique/confirme el mismo objetivo en Terminal. En Finder, seleccione el dispositivo, mantenga **Option (⌥)** y pulse **Restaurar**; elija el IPSW. Apple valida firma, compatibilidad, activación y confirmaciones. La app no selecciona automáticamente el archivo ni el dispositivo.
5. Espere a que Finder termine o cancele. Después use **Confirmar fin de sesión Finder** para liberar la reserva de tareas de la GUI.

Restaurar borra datos. No se eluden Activation Lock, MDM, confianza, autenticación ni firmas. No hay flasheo automático, custom firmware, jailbreak ni downgrade no autorizado. Para firmware de MacBook utilice los asistentes oficiales del módulo Macbook; este repositorio reconoce IPSW iPhone/iPad, no IPSW de Mac.

Referencia oficial: https://support.apple.com/118107

## Respaldos
**Abrir flujo de respaldo iPhone/iPad** abre el flujo Finder existente. Configure cifrado y contraseña en Finder; MacTech no registra ni custodia esa contraseña. Espere a que la copia termine. **Mostrar respaldos Finder** abre `~/Library/Application Support/MobileSync/Backup` si existe para el usuario actual.

En Respaldos, **Archivar carpeta de respaldo** copia una carpeta completa ya finalizada y añade una etiqueta. No seleccione una carpeta en uso por Finder ni una que contenga la propia biblioteca. Se rechazan enlaces simbólicos, lecturas incompletas y árboles de más de un millón de entradas. Conserve toda la estructura: modificar nombres/archivos puede impedir restaurar. Un respaldo puede contener datos sensibles; la biblioteca no lo cifra ni calcula un hash de árbol, y no certifica que pueda restaurarse. Para MacBook, use Time Machine o copia de documentos supervisada; puede usar esta biblioteca para archivar carpetas ya creadas.

El directorio de biblioteca no reemplaza ni redirige MobileSync. Restaurar una copia archivada requiere el flujo Apple y validación manual; exportarla a una carpeta no la registra automáticamente en Finder.

## Límites y fallos
Raíz/staging con permisos 700, archivos importados y registro con 600 cuando el sistema soporta POSIX. Las carpetas de respaldo conservan la estructura/permisos copiados dentro de la raíz privada. No hay cifrado adicional, sincronización multiusuario ni eliminación automática. Un fallo puede dejar `.pending-*` o una exportación incompleta; no se presentan como completados ni se borran automáticamente. Reserva de sesión Finder sólo protege esta GUI mientras está abierta, no Terminal ajena ni sesiones tras reiniciar la app.

La carga de biblioteca limita a 5.000 entradas y 1 MB por registro. Registros inválidos detienen la actualización con explicación; no se muestran como verificados. La categoría etiqueta el contenido, no verifica códec, licencia, firma de apps ni ausencia de malware. No archive contraseñas ni claves en etiquetas.

## Validación de esta entrega
En Linux: `python3 tools/check_source.py`, `python3 tools/check_macbook_catalog.py`, `python3 tools/check_service_library.py`; inspección opcional `tools/check_swift_structure.py` con tree-sitter 0.25.2/tree-sitter-swift 0.7.4. Los fixtures son ZIP/plist/texto sintéticos, no firmware ni datos de un dispositivo. La prueba Python comprueba la invocación de unzip y los fixtures, no ejecuta el almacén Swift.

En macOS: `/bin/bash Build_DMG.command` compilará y ejecutará selftests puros del motor, incluidos manifiestos/record/paths simulados. Probar GUI/importación/exportación/checksum con archivos ficticios, enlaces rechazados, destinos existentes, backup de laboratorio, manifiestos faltantes y modelos incompatibles; no restaurar ni consultar dispositivos reales durante la verificación. El build, la GUI y los selftests Swift están pendientes en esta entrega. No se entrega un DMG no verificado.
