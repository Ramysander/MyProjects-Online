import SwiftUI
import AppKit

struct ITCustomView: View {
    @ObservedObject var runner: Runner
    @StateObject private var store: ITCustomStore
    @Environment(\.presentationMode) private var presentationMode
    @State private var module = "MyServiceKit"
    @State private var platform = "iOS + macOS"
    @State private var template = "model"
    @State private var tab = "Código"
    @State private var title = "Mi snippet"
    @State private var language = "Swift"
    @State private var snippet = ""
    @State private var snippetBaseline: CustomSnippetDraft?
    private var snippetDraft: CustomSnippetDraft { CustomSnippetDraft(title: title, language: language, body: snippet) }
    @State private var editingSnippet: String?
    @State private var selectedSnippet: String?
    @State private var search = ""
    @State private var iterations = 1000
    @State private var selectedRevision: String?
    @State private var editor = "Fuente"
    init(runner: Runner) {
        self.runner = runner
        _store = StateObject(wrappedValue: ITCustomStore(resources: runner.root))
    }
    private var blocked: Bool { store.working || runner.jobInProgress }
    private var filtered: [CustomCodeSnippet] {
        store.project.snippets.filter { search.isEmpty || ($0.title + " " + $0.language + " " + $0.body).localizedCaseInsensitiveContains(search) }
    }
    private var chosenSnippet: CustomCodeSnippet? { filtered.first { $0.id == selectedSnippet } }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            projectControls
            Picker("Área", selection: $tab) {
                ForEach(["Código", "Mis snippets", "Robustez", "Revisiones"], id: \.self) { Text($0).tag($0) }
            }.pickerStyle(.segmented)
            content
            Text(store.message).font(.caption).textSelection(.enabled)
            Text("Código como texto, sin ejecución ni compilación automática. Para una app instalable necesita Xcode, app anfitriona, firma y autorizaciones válidas. No incluya secretos.").font(.caption)
        }.padding(20).frame(minWidth: 1120, minHeight: 760)
    }
    private var header: some View {
        HStack {
            Text("IT Custom · iPhone/iPad y Macbook").font(.title2).bold()
            Spacer()
            Text(store.dirty ? "Cambios sin guardar" : "Sin cambios de edición").font(.caption)
            Button("Cerrar") { if discard() { presentationMode.wrappedValue.dismiss() } }.disabled(store.working)
        }
    }
    private var projectControls: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                TextField("Nombre del módulo (A–Z inicial, sin espacios)", text: $module)
                Picker("Plataforma", selection: $platform) { ForEach(customPlatforms, id: \.self) { Text($0).tag($0) } }
                Picker("Plantilla", selection: $template) { ForEach(store.templates) { Text($0.title).tag($0.id) } }
                Button("Crear proyecto") { generate() }.disabled(blocked)
            }
            HStack {
                Text("Proyecto activo: \(store.project.module) · \(store.project.platform)").font(.caption)
                Spacer()
                Button("Validar estructura") { attempt { try store.project.validate(); store.message = "Estructura válida; sintaxis/APIs/compilación no comprobadas." } }.disabled(blocked)
                Button("Guardar revisión") { attempt { try snippetDraft.requireIncorporated(comparedTo: snippetBaseline); try store.save() } }.disabled(blocked)
                Button("Importar JSON…") { importJSON() }.disabled(blocked)
                Button("Exportar paquete Swift…") { exportPackage() }.disabled(blocked)
            }
        }
    }
    @ViewBuilder private var content: some View {
        switch tab {
        case "Mis snippets": snippetsArea
        case "Robustez": robustnessArea
        case "Revisiones": revisionsArea
        default: codeArea
        }
    }
    private var codeArea: some View {
        VStack(alignment: .leading, spacing: 8) {
            Picker("Archivo", selection: $editor) { ForEach(["Fuente", "Pruebas", "Notas"], id: \.self) { Text($0).tag($0) } }.pickerStyle(.segmented)
            Text("Edite código Swift y pruebas del módulo activo. Los controles superiores sólo se aplican al crear otro proyecto. Las notas se conservan en la revisión JSON.").font(.caption)
            codeEditor
        }
    }
    @ViewBuilder private var codeEditor: some View {
        switch editor {
        case "Pruebas": TextEditor(text: $store.project.tests).font(.system(.body, design: .monospaced)).disabled(blocked)
        case "Notas": TextEditor(text: $store.project.notes).disabled(blocked)
        default: TextEditor(text: $store.project.source).font(.system(.body, design: .monospaced)).disabled(blocked)
        }
    }
    private var snippetsArea: some View {
        HSplitView {
            snippetEditor
            snippetList
        }
    }
    private var snippetEditor: some View {
        VStack(alignment: .leading, spacing: 8) {
            TextField("Título", text: $title)
            Picker("Lenguaje", selection: $language) { ForEach(["Swift", "Shell", "Texto"], id: \.self) { Text($0).tag($0) } }
            TextEditor(text: $snippet).font(.system(.body, design: .monospaced))
            HStack {
                Button("Crear nueva versión") { attempt { try store.addSnippet(title: title, language: language, body: snippet); snippetBaseline = snippetDraft } }
                Button("Actualizar seleccionado") {
                    guard let id = editingSnippet else { return }
                    attempt { try store.updateSnippet(id, title: title, language: language, body: snippet); snippetBaseline = snippetDraft }
                }.disabled(editingSnippet == nil)
                Button("Usar código del proyecto") { if discardSnippet() { snippet = store.project.source; language = "Swift"; editingSnippet = nil } }
            }
            Text("Snippets propios: texto no auditado. Shell exige una sola línea sin controles, no se ejecuta ni se clasifica automáticamente como lectura segura. Arrastre Swift sólo a un editor de código. Puede añadir otra versión con Crear snippet; conserve la revisión anterior.").font(.caption)
        }.padding().frame(minWidth: 450).disabled(blocked)
    }
    private var snippetList: some View {
        VStack(alignment: .leading, spacing: 8) {
            TextField("Buscar mis snippets", text: $search)
            List(selection: $selectedSnippet) {
                ForEach(filtered) { item in Text(item.title + " · " + item.language).tag(item.id) }
            }
            if let item = chosenSnippet {
                ScrollView { Text(item.body).font(.system(.caption, design: .monospaced)).textSelection(.enabled) }.frame(minHeight: 100, maxHeight: 180)
                HStack {
                    Button("Cargar en editor") {
                        if discardSnippet() { title = item.title; language = item.language; snippet = item.body; editingSnippet = item.id; snippetBaseline = snippetDraft }
                    }.disabled(blocked)
                    Button("Copiar texto") { copy(item) }
                    Text("Arrastrar texto").onDrag { NSItemProvider(object: (item.language == "Shell" ? item.body.trimmingCharacters(in: .newlines) : item.body) as NSString) }
                }
            }
        }.padding().frame(minWidth: 450)
    }
    private var robustnessArea: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Pruebas acotadas de entradas y estructura").font(.headline)
            Stepper("\(iterations) casos sintéticos (máximo 5.000 / 3 s)", value: $iterations, in: 100...5000, step: 100).disabled(blocked)
            HStack {
                Button("Ejecutar casos simulados") { runRobustness() }.disabled(blocked)
                Button("Capturar rendimiento de ESTA Mac") { performance() }.disabled(blocked)
            }
            if let report = store.report {
                Text(report.text).textSelection(.enabled)
                HStack {
                    Button("Añadir informe a notas") { store.project.notes += "\n" + report.text }.disabled(blocked)
                    Button("Exportar informe JSON…") { exportReport(report) }.disabled(blocked)
                }
            }
            Text("La prueba usa entradas deterministas, incluidos proyectos JSON y rutas/hosts inválidos; no fuzzing del código del usuario ni ataques a contraseñas. El límite temporal puede producir un informe parcial. Rendimiento reutiliza una sola captura CPU/memoria/swap/espacio del anfitrión, nunca del iPhone/iPad conectado.").font(.caption)
            Text(runner.notice).font(.caption)
            ScrollView { Text(runner.output).font(.system(.caption, design: .monospaced)).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading) }
        }
    }
    private var revisionsArea: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Button("Actualizar revisiones") { attempt { try store.refresh() } }.disabled(blocked)
                Button("Mostrar carpeta") { NSWorkspace.shared.open(store.root) }
            }
            List(selection: $selectedRevision) {
                ForEach(store.revisions) { item in Text(item.module + " · " + item.platform + " · " + item.url.lastPathComponent).tag(item.id) }
            }
            Button("Abrir revisión seleccionada") {
                guard let row = store.revisions.first(where: { $0.id == selectedRevision }), discard() else { return }
                attempt { try store.load(row.url); syncFields() }
            }.disabled(blocked || selectedRevision == nil)
        }
    }
    private func attempt(_ action: () throws -> Void) { do { try action() } catch { store.message = error.localizedDescription } }
    private func discardSnippet() -> Bool {
        guard snippetDraft.isPending(comparedTo: snippetBaseline) else { return true }
        let alert = NSAlert(); alert.messageText = "¿Descartar el snippet aún no incorporado?"
        alert.addButton(withTitle: "Cancelar"); alert.addButton(withTitle: "Descartar")
        return alert.runModal() == .alertSecondButtonReturn
    }
    private func discard() -> Bool {
        guard store.dirty || snippetDraft.isPending(comparedTo: snippetBaseline) else { return true }
        let alert = NSAlert(); alert.messageText = "¿Descartar el borrador visible?"
        alert.informativeText = "Guarde revisión del proyecto y añada los snippets pendientes. Los archivos ya guardados se conservan."
        alert.addButton(withTitle: "Cancelar"); alert.addButton(withTitle: "Descartar")
        return alert.runModal() == .alertSecondButtonReturn
    }
    private func syncFields() { module = store.project.module; platform = store.project.platform; template = store.project.template; snippet = ""; editingSnippet = nil; snippetBaseline = nil }
    private func generate() {
        guard discard() else { return }
        attempt { try store.make(template, module: module, platform: platform); snippet = ""; editingSnippet = nil; snippetBaseline = nil }
    }
    private func importJSON() {
        let panel = NSOpenPanel(); panel.allowsMultipleSelection = false; panel.canChooseDirectories = false
        guard panel.runModal() == .OK, let url = panel.url, discard() else { return }
        attempt { try store.load(url); syncFields() }
    }
    private func exportPackage() {
        do { try snippetDraft.requireIncorporated(comparedTo: snippetBaseline) }
        catch { store.message = error.localizedDescription; return }
        let panel = NSOpenPanel(); panel.canChooseFiles = false; panel.canChooseDirectories = true
        guard panel.runModal() == .OK, let url = panel.url else { return }
        attempt { let output = try store.export(url); NSWorkspace.shared.activateFileViewerSelecting([output]) }
    }
    private func copy(_ item: CustomCodeSnippet) {
        let text = item.language == "Shell" ? item.body.trimmingCharacters(in: .newlines) : item.body
        NSPasteboard.general.clearContents(); NSPasteboard.general.setString(text, forType: .string)
        store.message = "Texto copiado, no ejecutado. Revise el contenido antes de usarlo."
    }
    private func runRobustness() {
        guard !blocked else { return }
        let count = iterations; store.working = true; runner.busy = true
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let report = try runCustomRobustness(count)
                DispatchQueue.main.async {
                    store.report = report; store.working = false; runner.busy = false
                    store.message = report.failures == 0 ? "Invariantes de los casos ejecutados correctas; no valida código del usuario." : "Fallo de invariantes; revise el informe."
                }
            } catch { DispatchQueue.main.async { store.working = false; runner.busy = false; store.message = error.localizedDescription } }
        }
    }
    private func exportReport(_ report: CustomRobustnessReport) {
        let panel = NSSavePanel(); panel.nameFieldStringValue = "ITCustom-Robustez.json"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        attempt {
            try JSONEncoder().encode(report).write(to: url, options: .atomic)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
            store.message = "Informe sintético exportado; no es una certificación de código ni de dispositivos."
        }
    }
    private func performance() {
        guard !blocked, let tool = catalog.first(where: { $0.id == "performance" }) else { return }
        runner.run(tool, host: "", expectedHash: "")
    }
}
