import Foundation
import Combine

struct CustomRevision: Identifiable {
    let url: URL
    let module: String
    let platform: String
    var id: String { url.path }
}
final class ITCustomStore: ObservableObject {
    @Published var project = CustomWorkspace()
    @Published var templates: [CustomTemplate] = []
    @Published var revisions: [CustomRevision] = []
    @Published var message = ""
    @Published var report: CustomRobustnessReport?
    @Published var working = false
    private var clean = CustomWorkspace()
    private var needsSave = false
    let root: URL
    var dirty: Bool { project != clean || needsSave }
    init(resources: URL) {
        root = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent("MacTech IT Custom", isDirectory: true)
        do {
            templates = try JSONDecoder().decode([CustomTemplate].self, from: Data(contentsOf: resources.appendingPathComponent("docs/it-custom-templates.json")))
            guard let initial = templates.first(where: { $0.id == "model" }) else { throw customError("Falta plantilla inicial") }
            project = try CustomWorkspace.generate(initial, module: project.module, platform: project.platform)
            clean = project
            try refresh()
        } catch { message = error.localizedDescription }
    }
    func make(_ id: String, module: String, platform: String) throws {
        guard let template = templates.first(where: { $0.id == id }) else { throw customError("Plantilla desconocida") }
        project = try CustomWorkspace.generate(template, module: module, platform: platform)
        clean = project; needsSave = true; report = nil; message = "Nuevo proyecto generado en memoria; guarde una revisión. No está compilado."
    }
    private func ensureRoot() throws {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        guard (try root.resourceValues(forKeys: [.isSymbolicLinkKey])).isSymbolicLink != true else { throw customError("La raíz no puede ser un enlace simbólico") }
    }
    private func read(_ url: URL) throws -> CustomWorkspace {
        let metadata = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
        guard metadata.isRegularFile == true, metadata.isSymbolicLink != true, (metadata.fileSize ?? Int.max) <= 2_000_000 else { throw customError("Seleccione un JSON regular de hasta 2 MB") }
        let handle = try FileHandle(forReadingFrom: url); defer { try? handle.close() }
        let data = try readBoundedCustomData { requested in try handle.read(upToCount: requested) ?? Data() }
        return try decodeCustomWorkspace(data)
    }
    func load(_ url: URL) throws {
        project = try read(url); clean = project; needsSave = false; report = nil
        message = "Proyecto cargado como texto. No se ha ejecutado ni compilado."
    }
    func save() throws {
        try project.validate(); try ensureRoot()
        let data = try JSONEncoder().encode(project)
        guard data.count <= 2_000_000 else { throw customError("Proyecto superior a 2 MB") }
        let id = UUID().uuidString
        let staged = root.appendingPathComponent(".pending-" + id)
        let path = root.appendingPathComponent("revision-" + id + ".json")
        try data.write(to: staged, options: .withoutOverwriting)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: staged.path)
        try FileManager.default.moveItem(at: staged, to: path)
        clean = project; needsSave = false
        do {
            try refresh(); message = "Revisión guardada: " + path.lastPathComponent
        } catch {
            message = "Revisión guardada: " + path.lastPathComponent + ". No se pudo actualizar el listado: " + error.localizedDescription
        }
    }
    func refresh() throws {
        try ensureRoot()
        let files = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.fileSizeKey], options: [.skipsHiddenFiles])
        guard files.count <= 1000 else { throw customError("Límite de 1.000 entradas; archive revisiones en otra carpeta") }
        var result: [CustomRevision] = []; var rejected = 0; var bytes = 0; var partial = false
        for file in files.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) where file.pathExtension == "json" {
            let size = (try? file.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
            if size > 2_000_000 { rejected += 1; continue }
            if bytes + size > 16_000_000 { partial = true; break }
            bytes += size
            do {
                let project = try read(file)
                result.append(CustomRevision(url: file, module: project.module, platform: project.platform))
            } catch { rejected += 1 }
        }
        revisions = result
        message = "\(result.count) revisiones; \(rejected) rechazadas." + (partial ? " Listado parcial: límite de 16 MB." : "")
    }
    func export(_ destination: URL) throws -> URL {
        let files = try project.packageFiles()
        let suffix = UUID().uuidString
        let staging = destination.appendingPathComponent(".pending-" + suffix, isDirectory: true)
        let output = destination.appendingPathComponent(project.module + "-" + suffix, isDirectory: true)
        try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        for (relative, text) in files {
            let file = staging.appendingPathComponent(relative)
            try FileManager.default.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
            try Data(text.utf8).write(to: file, options: .withoutOverwriting)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: file.path)
        }
        // Snippets remain text assets, not executable build plugins/scripts.
        let snippets = staging.appendingPathComponent("Snippets.json")
        try JSONEncoder().encode(project.snippets).write(to: snippets, options: .withoutOverwriting)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: snippets.path)
        try FileManager.default.moveItem(at: staging, to: output)
        message = "Paquete exportado; ábralo y revíselo en Xcode. No se ejecutó ni compiló."
        return output
    }
    func updateSnippet(_ id: String, title: String, language: String, body: String) throws {
        guard let index = project.snippets.firstIndex(where: { $0.id == id }) else { throw customError("Snippet seleccionado ya no existe") }
        var draft = project
        draft.snippets[index] = CustomCodeSnippet(id: id, title: title, language: language, body: body)
        try draft.validate(); project = draft; message = "Snippet actualizado en memoria; guarde una revisión."
    }
    func addSnippet(title: String, language: String, body: String) throws {
        var draft = project
        draft.snippets.append(CustomCodeSnippet(title: title, language: language, body: body))
        try draft.validate(); project = draft
        message = "Snippet añadido al proyecto en memoria; guarde revisión."
    }
}
