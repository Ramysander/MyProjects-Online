# MacTech IT 0.13.1 — Centro TI profesional (fuentes en desarrollo)

Herramienta nativa para macOS 12+ con diagnóstico, catálogo de utilidades, snippets y expedientes para Mac/iPhone/iPad.

Esta entrega contiene código fuente y constructor; no incluye una app ni un DMG compilados. Las nuevas funciones requieren validación en macOS. Lea `AGENTS.md` y `docs/PROJECT_STATUS.md` antes de modificar o verificar el proyecto.

## Macbook y Snippets
Botón **Macbook** junto a iPhone / iPad; panel para MacBook Air/Pro con ámbitos anfitrión/objetivo y ocho categorías. Reutiliza diagnósticos y flujos supervisados; no promete métricas remotas por USB/DFU. [Guía Macbook](docs/MACBOOK_SUPPORT.md).

Snippets incluye 71 entradas macOS experto y 10 iPhone/iPad, filtros, requisitos, parámetros, riesgos, interpretación y vista previa. Copiar/arrastrar sólo entrega texto sin salto final ni ejecución. [Guía Snippets](docs/SNIPPETS.md).

## Centro TI
- Seguimiento por ticket, técnico, prioridad y fecha objetivo.
- Checklist de cierre y bitácora manual con técnico y fecha.
- Biblioteca de revisiones con búsqueda, filtro por resultado y aviso de fecha objetivo vencida.
- Exportación JSON/HTML por revisión, Print/PDF y CSV de los resultados filtrados.
- Checksums SHA-256 de los archivos exportados y comprobación de integridad.
- Importación de expedientes 0.9.0; inventario conservador y comprobación de dependencias.

Consulte [la guía del Centro TI](docs/EXPERT_WORKBENCH.md) para el uso y las limitaciones. El historial es editable, no una auditoría inmutable. Los checksums no autentican al autor; los expedientes no están cifrados.

## Verificar y compilar

En cualquier entorno con Python 3 y Bash: `python3 tools/check_source.py` y `python3 tools/check_macbook_catalog.py` (fuentes/catálogos/argumentos sintéticos; no ejecutan snippets).

En una Mac con Apple Command Line Tools, desde la raíz: `/bin/bash Build_DMG.command`. Compila, ejecuta los selftests sintéticos, verifica firmas y arquitecturas y genera el DMG y su SHA-256. No ejecute flujos operativos ni pruebas sobre dispositivos durante la verificación.

La firma ad hoc es para uso local; la distribución pública requiere Developer ID y notarización.

## Centro de dispositivos y biblioteca — 0.13.1
Abra **Dispositivos / archivos** o **Archivos / firmware / respaldos** en los módulos Macbook e iPhone/iPad. Biblioteca local de vídeos, música, paquetes de aplicaciones, documentos, IPSW y carpetas de respaldos. Importación/exportación sin sobrescribir y SHA-256 para archivos; IPSW indexado por ProductVersion/build/ProductType.

Las transferencias iOS y la sincronización siguen las capacidades oficiales de Finder/Música/TV y apps compatibles; no hay acceso universal al disco iOS ni instalación arbitraria de IPA. La restauración abre el flujo supervisado existente y requiere selección manual del IPSW con Option + Restaurar en Finder. Apple verifica firma, compatibilidad y activación.

Lea [la guía de biblioteca y dispositivos](docs/DEVICE_SERVICE.md). Los respaldos archivados no están certificados como restaurables ni cifrados por la biblioteca. No se ha compilado esta versión en macOS.

## IT Custom — 0.13.1
Módulo para crear/editar Swift, pruebas y snippets propios, guardar revisiones y exportar paquetes de biblioteca para Xcode. Tres plantillas y destinos iOS 15+/macOS 12+. Robustez con entradas simuladas y límites; captura de rendimiento reutilizada de ESTA Mac. No ejecuta código del usuario. [Guía IT Custom](docs/IT_CUSTOM.md).
