import Foundation

let customPlatforms = ["iOS + macOS", "iPhone/iPad", "Macbook"]
func customError(_ text: String) -> NSError { NSError(domain: "ITCustom", code: 1, userInfo: [NSLocalizedDescriptionKey: text]) }
func validCustomModule(_ value: String) -> Bool {
    let bytes = Array(value.utf8)
    guard let first = bytes.first, (65...90).contains(first), bytes.count <= 40 else { return false }
    let ascii = bytes.allSatisfy { byte -> Bool in
        switch byte {
        case 65...90, 97...122, 48...57: return true
        default: return false
        }
    }
    return ascii && !["Self", "Any", "Type", "Protocol"].contains(value)
}
struct CustomSnippetDraft: Equatable {
    let title: String
    let language: String
    let body: String
    func isPending(comparedTo baseline: CustomSnippetDraft?) -> Bool {
        guard !body.isEmpty else { return false }
        guard let baseline = baseline else { return true }
        return self != baseline
    }
    func requireIncorporated(comparedTo baseline: CustomSnippetDraft?) throws {
        guard !isPending(comparedTo: baseline) else {
            throw customError("Hay un snippet pendiente: use Crear nueva versión o Actualizar seleccionado antes de guardar/exportar")
        }
    }
}
func readBoundedCustomData(limit: Int = 2_000_000, reader: (Int) throws -> Data) throws -> Data {
    guard (1...2_000_000).contains(limit) else { throw customError("Límite de lectura inválido") }
    var result = Data()
    while true {
        let requested = min(65_536, limit + 1 - result.count)
        let chunk = try reader(requested)
        guard chunk.count <= requested else { throw customError("Proveedor de lectura inválido") }
        if chunk.isEmpty { return result }
        result.append(chunk)
        guard result.count <= limit else { throw customError("Proyecto excesivo") }
    }
}
struct CustomCodeSnippet: Codable, Identifiable, Equatable {
    var id = UUID().uuidString
    var title: String
    var language: String
    var body: String
    func validate() throws {
        guard UUID(uuidString: id) != nil, !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              title.count <= 200, ["Swift", "Shell", "Texto"].contains(language), !body.isEmpty,
              body.utf8.count <= 64_000, !body.contains("\0") else { throw customError("Snippet inválido o excesivo") }
        if language == "Shell", body.unicodeScalars.contains(where: { CharacterSet.controlCharacters.union(.newlines).contains($0) }) {
            throw customError("Shell requiere una sola línea sin caracteres de control")
        }
    }
}
struct CustomTemplate: Codable, Identifiable {
    let id: String
    let title: String
    let detail: String
    let source: String
    let tests: String
}
struct CustomWorkspace: Codable, Equatable {
    var schema = 1
    var id = UUID().uuidString
    var module = "MyServiceKit"
    var platform = "iOS + macOS"
    var template = "model"
    var source = ""
    var tests = ""
    var notes = ""
    var snippets: [CustomCodeSnippet] = []
    func validate() throws {
        let total = source.utf8.count + tests.utf8.count + notes.utf8.count + snippets.reduce(0) { $0 + $1.body.utf8.count }
        guard total <= 1_500_000 else { throw customError("Contenido total superior a 1,5 MB") }
        guard schema == 1, UUID(uuidString: id) != nil, validCustomModule(module), customPlatforms.contains(platform) else {
            throw customError("Nombre, plataforma o identidad de proyecto inválidos")
        }
        guard !source.isEmpty, source.utf8.count <= 256_000, tests.utf8.count <= 128_000, notes.utf8.count <= 20_000,
              !source.contains("\0"), !tests.contains("\0"), snippets.count <= 100 else { throw customError("Código o límites inválidos") }
        guard Set(snippets.map { $0.id }).count == snippets.count else { throw customError("IDs de snippets duplicados") }
        for snippet in snippets { try snippet.validate() }
    }
    static func generate(_ template: CustomTemplate, module: String, platform: String) throws -> CustomWorkspace {
        guard validCustomModule(module), customPlatforms.contains(platform) else { throw customError("Nombre de módulo o plataforma inválidos") }
        var result = CustomWorkspace()
        result.module = module; result.platform = platform; result.template = template.id
        result.source = template.source.replacingOccurrences(of: "{{MODULE}}", with: module).replacingOccurrences(of: "{{PLATFORM}}", with: platform)
        result.tests = template.tests.replacingOccurrences(of: "{{MODULE}}", with: module)
        try result.validate(); return result
    }
    func packageFiles() throws -> [String: String] {
        try validate()
        let platforms: String
        switch platform {
        case "iPhone/iPad": platforms = ".iOS(.v15)"
        case "Macbook": platforms = ".macOS(.v12)"
        default: platforms = ".iOS(.v15), .macOS(.v12)"
        }
        let manifest = """
        // swift-tools-version:5.5
        import PackageDescription
        let package = Package(
            name: "\(module)",
            platforms: [\(platforms)],
            products: [.library(name: "\(module)", targets: ["\(module)"])],
            targets: [.target(name: "\(module)"), .testTarget(name: "\(module)Tests", dependencies: ["\(module)"])])

        """
        return ["Package.swift": manifest, "Sources/\(module)/Custom.swift": source,
                "Tests/\(module)Tests/CustomTests.swift": tests,
                "README.md": "# \(module)\n\nPaquete de biblioteca Swift para \(platform). Abra Package.swift en Xcode y revise fuentes/tests antes de compilar. No es una app instalable ni un proyecto .xcodeproj. Necesita una app anfitriona y firma válida para distribuir.\n\nLas pruebas se derivan de la plantilla; si modifica las APIs, actualícelas. IT Custom no ejecutó ni compiló este código.\n"]
    }
}
func decodeCustomWorkspace(_ data: Data) throws -> CustomWorkspace {
    guard data.count <= 2_000_000 else { throw customError("JSON superior a 2 MB") }
    let project = try JSONDecoder().decode(CustomWorkspace.self, from: data)
    try project.validate(); return project
}
struct CustomRobustnessReport: Codable {
    let requested: Int
    let completed: Int
    let rejected: Int
    let accepted: Int
    let failures: Int
    let elapsed: Double
    var text: String { "Casos: \(completed)/\(requested) · rechazados: \(rejected) · aceptados: \(accepted) · fallos de invariantes: \(failures) · \(String(format: "%.3f", elapsed)) s. Sólo entradas sintéticas; no comandos, red, contraseñas ni dispositivos." }
}
func runCustomRobustness(_ count: Int) throws -> CustomRobustnessReport {
    guard (1...5000).contains(count) else { throw customError("Límite de 1 a 5.000 casos") }
    let started = ProcessInfo.processInfo.systemUptime; var completed = 0; var rejected = 0; var accepted = 0; var failures = 0
    let hosts: [(String, Bool)] = [("support.example.com", true), ("192.168.1.1", true), ("999.2.3.4", false), ("a..com", false), ("$(not_executed)", false), ("host;id", false), ("a\n.com", false), ("-option", false), ("a_b.com", false)]
    let names: [(String, Bool)] = [("ServiceKit", true), ("../escape", false), ("Bad-Name", false), ("A\nB", false), ("A\n", false), ("A\r", false), ("Self", false), (String(repeating: "A", count: 41), false)]
    var fixture = CustomWorkspace(); fixture.source = "public struct Lab {}"
    let validData = try JSONEncoder().encode(fixture)
    let jsonInputs: [(Data, Bool)] = [(validData, true), (Data("{}".utf8), false), (Data("[]".utf8), false), (Data("{broken".utf8), false)]
    for index in 0..<count {
        if ProcessInfo.processInfo.systemUptime - started > 3 { break }
        let result: Bool; let expected: Bool
        switch index % 3 {
        case 0:
            let item = hosts[(index / 3) % hosts.count]; result = validSnippetParameter(item.0, kind: "host"); expected = item.1
        case 1:
            let item = names[(index / 3) % names.count]; result = validCustomModule(item.0); expected = item.1
        default:
            let item = jsonInputs[(index / 3) % jsonInputs.count]
            result = (try? decodeCustomWorkspace(item.0)) != nil; expected = item.1
        }
        if result { accepted += 1 } else { rejected += 1 }
        if result != expected { failures += 1 }
        completed += 1
    }
    return CustomRobustnessReport(requested: count, completed: completed, rejected: rejected, accepted: accepted, failures: failures, elapsed: ProcessInfo.processInfo.systemUptime - started)
}
func itCustomSelfTest(_ templates: [CustomTemplate]) throws {
    guard templates.count == 3, Set(templates.map { $0.id }).count == templates.count else { throw customError("Plantillas incompletas o duplicadas") }
    for template in templates {
        for platform in customPlatforms {
            let project = try CustomWorkspace.generate(template, module: "LabService", platform: platform)
            let files = try project.packageFiles()
            guard files.count == 4, files["Sources/LabService/Custom.swift"] != nil,
                  !project.source.contains("{{"), files["Package.swift"]?.contains(".library") == true else { throw customError("Estructura o marcadores incorrectos") }
            let decoded = try JSONDecoder().decode(CustomWorkspace.self, from: JSONEncoder().encode(project))
            guard decoded == project else { throw customError("Proyecto no conserva su contenido") }
        }
    }
    let draft = CustomSnippetDraft(title: "Fixture", language: "Swift", body: "struct Lab {}")
    guard draft.isPending(comparedTo: nil), !draft.isPending(comparedTo: draft) else { throw customError("Estado de borrador incorrecto") }
    let changed = CustomSnippetDraft(title: "Título nuevo", language: draft.language, body: draft.body)
    guard changed.isPending(comparedTo: draft) else { throw customError("Cambio de título perdido") }
    var pendingBlocked = false
    do { try draft.requireIncorporated(comparedTo: nil) } catch { pendingBlocked = true }
    guard pendingBlocked else { throw customError("Pendiente no bloqueado") }
    try draft.requireIncorporated(comparedTo: draft)
    let input = Data("{\"text\":\"á\"}".utf8)
    var offset = 0
    let assembled = try readBoundedCustomData(limit: input.count) { requested in
        let end = min(input.count, offset + min(requested, 3))
        let chunk = input.subdata(in: offset..<end); offset = end; return chunk
    }
    guard assembled == input else { throw customError("Lectura fragmentada truncada") }
    var overflow = false
    do {
        _ = try readBoundedCustomData(limit: 4) { requested in Data(repeating: 65, count: requested) }
    } catch { overflow = true }
    guard overflow else { throw customError("Lectura excesiva aceptada") }
    let report = try runCustomRobustness(200)
    guard report.completed == 200, report.failures == 0, report.accepted > 0, report.rejected > 0 else { throw customError("Prueba sintética fallida") }
    do { _ = try runCustomRobustness(5001) } catch { return }
    throw customError("Límite de casos ignorado")
}
