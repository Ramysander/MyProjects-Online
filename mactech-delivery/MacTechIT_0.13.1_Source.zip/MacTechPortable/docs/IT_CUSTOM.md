# IT Custom — 0.13.1, build 23

## Crear y desarrollar código
Abra **IT Custom** desde la ventana principal, iPhone/iPad o Macbook; también desde **IT Custom / mis snippets** en Snippets TI. El módulo es un editor/generador local, no un sustituto del compilador/Xcode ni un modelo IA de programación.

Escriba un nombre de módulo que comience con A–Z, seguido de letras ASCII/dígitos (máximo 40). Seleccione destino **iOS + macOS**, **iPhone/iPad** o **Macbook** y una plantilla:
- Vista SwiftUI con modelo Codable.
- Modelo de expediente con UUID.
- Lector de informes JSON limitado a 1 MB.

Pulse **Crear proyecto**. Edite Fuente, Pruebas y Notas. Los controles superiores se aplican al crear otro proyecto, no renombran automáticamente el activo ni reescriben APIs. La cabecera muestra módulo/plataforma activos. Una nueva generación pide confirmar si descarta cambios. Las plantillas de biblioteca requieren iOS 15+ / macOS 12+, mientras la aplicación MacTech conserva macOS 12 mínimo.

**Validar estructura** comprueba esquema, nombres, IDs, tamaños y formatos. No verifica sintaxis Swift, APIs, seguridad del código ni que compile. Edite las pruebas cuando cambie el modelo/API; las pruebas generadas comprueban una serialización Codable real y no se ejecutan desde el editor.

## Guardar y exportar
**Guardar revisión** conserva JSON en `~/Documents/MacTech IT Custom`. **Importar JSON** abre un proyecto de este módulo, no cualquier catálogo de shell. **Revisiones** permite volver a abrir una copia guardada; el nombre UUID distingue cada revisión. No hay autoguardado ni cifrado. No guarde claves, contraseñas ni datos de clientes en muestras.

**Exportar paquete Swift** crea una carpeta única con:
- Package.swift (biblioteca sin plugins ni scripts de build generados).
- Sources/<módulo>/Custom.swift.
- Tests/<módulo>Tests/CustomTests.swift.
- README.md y Snippets.json.

Revise los archivos y abra Package.swift en Xcode. Integre la biblioteca en su app anfitriona iOS/macOS y ejecute sus pruebas allí. No se crea una app instalable, un .xcodeproj ni firma de distribución; no se instala código en dispositivos. Las notas sólo se guardan en la revisión JSON. Snippets.json se exporta como datos, no se ejecuta durante build.

Exportación y revisiones usan staging/carpeta UUID y no sobrescriben. Un fallo puede dejar `.pending-*` oculto para inspección, sin eliminarlo automáticamente. Permisos 700 para carpetas y 600 para archivos cuando POSIX lo permite. Importación JSON limitada a 2 MB, sólo archivo regular sin enlace; fuente 256 KB, pruebas 128 KB, notas 20 KB, 100 snippets de hasta 64 KB y contenido total hasta 1,5 MB. El listado inspecciona hasta 1.000 entradas/16 MB y comunica rechazos o parcialidad. El guardado también comprueba el tamaño JSON real.

## Snippets propios
En **Mis snippets**, elija Swift, Shell o Texto, escriba título/código y pulse **Crear nueva versión**. **Usar código del proyecto** carga el Swift activo como borrador. Seleccione uno guardado y **Cargar en editor** para editarlo; **Actualizar seleccionado** cambia esa entrada en memoria. Guarde una revisión para conservarla. Las revisiones anteriores no se sustituyen.

Búsqueda por título/lenguaje/contenido; vista previa completa, copiar o arrastrar texto. Swift se arrastra a un editor de código. Shell sólo admite una línea sin controles ni salto final. El receptor puede interpretar el texto: revise siempre antes de pegar en Terminal. MacTech no ejecuta ni compila el contenido y no clasifica código propio como lectura segura. El código no revisado puede ser peligroso si lo ejecuta fuera de la app.

Estos snippets pertenecen al proyecto IT Custom, separados del catálogo de comandos de confianza y sus wrappers supervisados. No se añaden dinámicamente al Runner ni se convierten en plugins del programa.

## Robustez, rendimiento y resultados
**Ejecutar casos simulados** usa entradas deterministas de nombres de host, módulos y proyectos JSON. Máximo 5.000 casos y aproximadamente 3 segundos; si vence el plazo, informa cuántos completó. No hay procesos de sistema, red, contraseñas, dispositivos ni ejecución de código del proyecto. Repetir casos sirve para comprobar invariantes y tiempo del validador, no constituye una campaña exhaustiva de fuzzing ni certifica seguridad.

El informe distingue aceptados/rechazados/fallos de invariantes y duración. Puede añadirlo a Notas o exportarlo como JSON. Un informe sin fallos sólo se refiere a los casos completados; no certifica el código del usuario, memoria ni hardware.

**Capturar rendimiento de ESTA Mac** reutiliza la captura existente: top de una muestra, vm_stat, swap, espacio y estado térmico. Requiere carpeta de informes; usa Runner y sus bloqueos. Esa acción lee el anfitrión, nunca el iPhone/iPad/MacBook conectado. No se ejecuta automáticamente al abrir el módulo ni realiza estrés continuo. El resultado comparte el visor/salida del Runner.

## Verificación de la entrega
Linux: checks existentes de scripts/catálogos/fixtures; `tools/check_it_custom.py` con tree-sitter 0.25.2 y tree-sitter-swift 0.7.4 inspecciona recursos, integración y 27 archivos Swift generados (tres plantillas por tres destinos). `tools/check_swift_structure.py` inspecciona gramática/contendedores. Nada de esto equivale a swiftc ni ejecuta los validators Swift.

En macOS, compile desde la raíz con `/bin/bash Build_DMG.command`. El constructor compila el core y ejecuta `caseengine selftest docs/snippets.json docs/it-custom-templates.json`, incluidos tests puros de plantillas/roundtrip/casos inválidos y límites. Verifique GUI con archivos sintéticos: nuevo proyecto, cambios sin guardar, revisión/importación, Shell multilínea rechazado, búsqueda/edición, exportación sin sobrescribir y pruebas parciales/completas. Abra los paquetes generados en Xcode y ejecute sus tests en destinos compatibles. No ejecute snippets propios ni operaciones sobre dispositivos durante la verificación.

Compilación Swift, selftests, GUI y Xcode están pendientes en esta entrega Linux. No se entrega DMG ni se afirma app lista para producción.


## Correcciones 0.13.1
Guardar/exportar exige incorporar el borrador de snippet mediante Crear nueva versión o Actualizar seleccionado. El aviso identifica lo pendiente, sin borrar el texto. Cargar un snippet limpio no bloquea; cambiar título, lenguaje o contenido sí cuenta. Se mantienen las confirmaciones al descartar.

La lectura JSON admite fragmentación de lectura y UTF-8 sin perder el límite de 2 MB. Un guardado correcto seguido de fallo del listado se comunica como guardado con actualización pendiente. En macOS, pruebe estas regresiones con JSON y texto sintéticos; no necesita dispositivos.
