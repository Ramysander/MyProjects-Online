import Foundation
import AppKit

struct Finding: Codable {
    let key: String
    let state: String
    let evidence: String
    let next: String
}
struct Measurement: Codable {
    let value: Double
    let unit: String
}
struct Snapshot: Codable {
    let version: Int
    let date: Date
    let identity: String?
    let symptom: String
    let metrics: [String: Measurement]
    let findings: [Finding]
    let providers: [String: Int32]
}
struct ServiceCase: Codable {
    let id: String
    let created: Date
    let asset: String
    let symptom: String
    var events: [String]
}
func engineError(_ message: String) -> NSError { NSError(domain: message, code: 1) }
func saveJSON<T: Encodable>(_ value: T, _ url: URL) throws {
    let enc = JSONEncoder(); enc.outputFormatting = [.prettyPrinted, .sortedKeys]; enc.dateEncodingStrategy = .iso8601
    try enc.encode(value).write(to: url, options: .atomic)
    try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
}
func loadJSON<T: Decodable>(_ type: T.Type, _ url: URL) throws -> T {
    let dec = JSONDecoder(); dec.dateDecodingStrategy = .iso8601
    return try dec.decode(type, from: Data(contentsOf: url))
}
func command(_ path: String, _ args: [String]) throws -> (String, Int32) {
    let p = Process(); let out = Pipe()
    p.executableURL = URL(fileURLWithPath: path); p.arguments = args
    p.standardOutput = out; p.standardError = out; p.standardInput = FileHandle.nullDevice
    try p.run(); let bytes = out.fileHandleForReading.readDataToEndOfFile(); p.waitUntilExit()
    return (String(decoding: bytes, as: UTF8.self), p.terminationStatus)
}
func captureValue(_ text: String, pattern: String) -> String? {
    guard let r = try? NSRegularExpression(pattern: pattern),
          let match = r.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
          let range = Range(match.range(at: 1), in: text) else { return nil }
    return String(text[range])
}
func diskFinding(_ percent: Double?) -> Finding {
    guard let n = percent, n >= 0, n <= 100 else {
        return Finding(key: "disk", state: "No disponible", evidence: "Lectura df no interpretable", next: "Revisar proveedor; no inferir estado sano")
    }
    return Finding(key: "disk", state: n >= 97 ? "Fallo" : n >= 90 ? "Atención" : "Correcto", evidence: "Ocupación del volumen /: \(n)%", next: n >= 90 ? "Revisar espacio; no borrar automáticamente" : "Espacio dentro del umbral configurable de esta versión")
}
func comparable(_ a: Snapshot, _ b: Snapshot) throws {
    guard let id = a.identity, !id.isEmpty, id == b.identity else { throw engineError("Identidades distintas o desconocidas") }
    guard a.version == b.version, a.symptom == b.symptom, a.date <= b.date else { throw engineError("Sesiones incompatibles") }
}
func htmlEscape(_ s: String) -> String {
    s.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;").replacingOccurrences(of: ">", with: "&gt;").replacingOccurrences(of: "\"", with: "&quot;")
}
func report(_ folder: URL) throws -> String {
    let c = try loadJSON(ServiceCase.self, folder.appendingPathComponent("case.json"))
    var text = "MacTech IT — expediente \(c.id)\nEquipo declarado: \(c.asset)\nSíntoma: \(c.symptom)\n\n"
    for phase in ["before", "after"] {
        let file = folder.appendingPathComponent(phase + ".json")
        if let s = try? loadJSON(Snapshot.self, file) {
            text += "\(phase) — \(s.date) — HOST medido: \(s.identity ?? "desconocido")\n"
            for f in s.findings { text += "\(f.key): \(f.state)\nEvidencia: \(f.evidence)\nPróximo paso: \(f.next)\n\n" }
        }
    }
    text += "Intervenciones declaradas:\n" + c.events.joined(separator: "\n") + "\n\n"
    let aURL = folder.appendingPathComponent("before.json"), bURL = folder.appendingPathComponent("after.json")
    if FileManager.default.fileExists(atPath: aURL.path), FileManager.default.fileExists(atPath: bURL.path) {
        let a = try loadJSON(Snapshot.self, aURL), b = try loadJSON(Snapshot.self, bURL)
        do {
            try comparable(a, b)
            text += "Comparación — cambios de medición, NO prueba causal de reparación:\n"
            for key in a.metrics.keys.sorted() {
                if let x = a.metrics[key], let y = b.metrics[key], x.unit == y.unit {
                    text += "\(key): \(x.value) → \(y.value) \(x.unit); diferencia \(y.value-x.value)\n"
                }
            }
        } catch { text += "Comparación RECHAZADA: \(error)\n" }
    }
    text += "\nNo certificado de salud. Mediciones de ESTA Mac; no del objetivo DFU. Datos personales: revisar antes de compartir.\n"
    return text
}
func takeSnapshot(_ symptom: String, _ folder: URL) throws -> Snapshot {
    var providers = [String: Int32](), findings = [Finding](), metrics = [String: Measurement]()
    func collect(_ name: String, _ path: String, _ args: [String]) -> String? {
        do {
            let (out, code) = try command(path, args); providers[name] = code
            try out.write(to: folder.appendingPathComponent(name + ".txt"), atomically: true, encoding: .utf8)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: folder.appendingPathComponent(name + ".txt").path)
            return code == 0 ? out : nil
        } catch { providers[name] = -1; return nil }
    }
    let registry = collect("identity", "/usr/sbin/ioreg", ["-rd1", "-c", "IOPlatformExpertDevice"])
    let id = registry.flatMap { captureValue($0, pattern: "\"IOPlatformUUID\"\\s*=\\s*\"([^\"]+)\"") }
    let disk = collect("disk", "/bin/df", ["-Pk", "/"])
    let row = disk?.split(separator: "\n").last?.split(whereSeparator: { $0.isWhitespace })
    let percent = row.flatMap { $0.count >= 5 ? Double($0[4].replacingOccurrences(of: "%", with: "")) : nil }
    findings.append(diskFinding(percent))
    if let percent { metrics["disk_used"] = Measurement(value: percent, unit: "%") }
    if let row, row.count >= 4, let free = Double(row[3]) { metrics["disk_free"] = Measurement(value: free, unit: "KiB") }
    let fv = collect("filevault", "/usr/bin/fdesetup", ["status"])
    let fvState = fv?.contains("FileVault is On.") == true ? "Correcto" : fv?.contains("FileVault is Off.") == true ? "Atención" : "No disponible"
    findings.append(Finding(key: "filevault", state: fvState, evidence: fv ?? "Proveedor sin datos", next: "Revisar política de cifrado; no cambiar sin respaldo y recuperación de claves"))
    let sip = collect("sip", "/usr/bin/csrutil", ["status"])
    let sipState = sip?.contains("status: enabled.") == true ? "Correcto" : sip?.contains("status: disabled.") == true ? "Atención" : "No disponible"
    findings.append(Finding(key: "sip", state: sipState, evidence: sip ?? "Proveedor sin datos", next: "Validar configuración con el administrador"))
    if symptom == "slow" {
        _ = collect("memory", "/usr/bin/vm_stat", [])
        _ = collect("cpu", "/usr/bin/top", ["-l", "1", "-n", "10", "-o", "cpu"])
        _ = collect("thermal", "/usr/bin/pmset", ["-g", "therm"])
        findings.append(Finding(key: "performance", state: "Atención", evidence: "Muestras CPU/memoria/térmica guardadas; pendiente de interpretación", next: "Repetir bajo carga similar; comprobar espacio y procesos antes de intervenir"))
    } else if symptom == "network" {
        _ = collect("dns", "/usr/sbin/scutil", ["--dns"])
        _ = collect("route", "/sbin/route", ["-n", "get", "default"])
        findings.append(Finding(key: "network", state: "Atención", evidence: "Configuración recopilada; no prueba acceso a Internet", next: "Comprobar enlace, gateway y resolución del destino autorizado por separado"))
    } else {
        findings.append(Finding(key: "startup", state: "No disponible", evidence: "Esta sesión se ejecuta en el host; no diagnostica remotamente un objetivo que no arranca", next: "Usar asistente de recuperación; identificar familia, alimentación y DFU"))
    }
    return Snapshot(version: 1, date: Date(), identity: id, symptom: symptom, metrics: metrics, findings: findings, providers: providers)
}
func engineMain() throws {
    let args = Array(CommandLine.arguments.dropFirst())
    guard let action = args.first else { throw engineError("Acción requerida") }
    if action == "selftest" {
        try supportCoreSelfTest()
        precondition(diskFinding(nil).state == "No disponible")
        precondition(diskFinding(98).state == "Fallo")
        precondition(diskFinding(-1).state == "No disponible")
        precondition(htmlEscape("<script>") == "&lt;script&gt;")
        let a = Snapshot(version: 1, date: Date(), identity: nil, symptom: "slow", metrics: [:], findings: [], providers: [:])
        do { try comparable(a, a); throw engineError("Test identidad no rechazó") } catch { if (error as NSError).domain == "Test identidad no rechazó" { throw error } }
        print("PASS reglas: ausentes, umbrales, identidad desconocida y escape HTML"); return
    }
    if action == "parse-inventory" {
        guard args.count == 2 else { throw engineError("parse-inventory JSON_FILE") }
        let rows = try parseConnectedDevices(Data(contentsOf: URL(fileURLWithPath: args[1])))
        func clean(_ value: String) -> String { value.replacingOccurrences(of: "\t", with: " ").replacingOccurrences(of: "\n", with: " ").replacingOccurrences(of: "\r", with: " ") }
        if rows.isEmpty { print("NO_RECORDS\tNo hay registros; no descarta conexiones") }
        for row in rows { print([row.name, row.transport, row.state, row.serial, row.location].map(clean).joined(separator: "\t")) }
        return
    }
    guard args.count >= 2 else { throw engineError("Carpeta requerida") }
    let folder = URL(fileURLWithPath: args[1], isDirectory: true)
    guard args[1].hasPrefix("/") else { throw engineError("Ruta absoluta requerida") }
    if action == "new" {
        guard args.count == 4, ["slow", "network", "startup"].contains(args[3]) else { throw engineError("new BASE EQUIPO SÍNTOMA") }
        let id = UUID().uuidString; let child = folder.appendingPathComponent("case-" + id)
        try FileManager.default.createDirectory(at: child, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        try saveJSON(ServiceCase(id: id, created: Date(), asset: args[2], symptom: args[3], events: []), child.appendingPathComponent("case.json"))
        print(child.path); return
    }
    var c = try loadJSON(ServiceCase.self, folder.appendingPathComponent("case.json"))
    if action == "capture" {
        guard args.count == 3, ["before", "after"].contains(args[2]) else { throw engineError("capture CASE before|after") }
        let file = folder.appendingPathComponent(args[2] + ".json")
        guard !FileManager.default.fileExists(atPath: file.path) else { throw engineError("Captura ya existe; crear otro expediente para repetir") }
        let evidence = folder.appendingPathComponent(args[2] + "-evidence")
        try FileManager.default.createDirectory(at: evidence, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        try saveJSON(takeSnapshot(c.symptom, evidence), file)
    } else if action == "note" {
        guard args.count == 3, !args[2].isEmpty, args[2].count <= 4000 else { throw engineError("Nota requerida, hasta 4000 caracteres") }
        c.events.append("\(Date()): \(args[2])")
        try saveJSON(c, folder.appendingPathComponent("case.json"))
    } else if action != "report" && action != "print" { throw engineError("Acción desconocida") }
    let text = try report(folder)
    try text.write(to: folder.appendingPathComponent("report.txt"), atomically: true, encoding: .utf8)
    try ("<!doctype html><meta charset='utf-8'><title>MacTech expediente</title><pre>" + htmlEscape(text) + "</pre>").write(to: folder.appendingPathComponent("report.html"), atomically: true, encoding: .utf8)
    for name in ["report.txt", "report.html"] { try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: folder.appendingPathComponent(name).path) }
    if action == "print" {
        let app = NSApplication.shared
        app.setActivationPolicy(.accessory)
        app.activate(ignoringOtherApps: true)
        let view = NSTextView(frame: NSRect(x: 0, y: 0, width: 500, height: 700))
        view.string = text
        view.font = NSFont.monospacedSystemFont(ofSize: 10, weight: .regular)
        if let container = view.textContainer, let layout = view.layoutManager {
            container.containerSize = NSSize(width: 480, height: CGFloat.greatestFiniteMagnitude)
            layout.ensureLayout(for: container)
            view.setFrameSize(NSSize(width: 500, height: max(700, layout.usedRect(for: container).height + 40)))
        }
        let operation = NSPrintOperation(view: view)
        operation.showsPrintPanel = true
        operation.run()
        print("Use PDF > Guardar como PDF en el diálogo. Compruebe el archivo guardado.")
    }
    print(text)
}
@main
struct CaseEngineEntry {
    static func main() {
        do { try engineMain() } catch { FileHandle.standardError.write(Data("ERROR: \(error)\n".utf8)); exit(1) }
    }
}
