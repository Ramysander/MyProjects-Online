import SwiftUI
import AppKit
import Foundation

struct ITSnippet: Codable, Identifiable {
    let id: String
    let title: String
    let category: String
    let detail: String
    let command: String
    let kind: String
    let risk: String
}
func quoteForShell(_ value: String) -> String {
    "'" + value.replacingOccurrences(of: "'", with: "'\\''") + "'"
}
struct SnippetsView: View {
    let root: URL
    let snippets: [ITSnippet]
    let loadError: String?
    @Environment(\.presentationMode) var presentationMode
    @State private var search = ""
    @State private var selected: String? = "os"
    @State private var parameter = ""
    @State private var showAdvanced = false
    @State private var acknowledged = false
    @State private var message = ""
    init(root: URL) {
        self.root = root
        do {
            snippets = try JSONDecoder().decode([ITSnippet].self, from: Data(contentsOf: root.appendingPathComponent("docs/snippets.json")))
            loadError = nil
        } catch { snippets = []; loadError = "No se pudo leer el catálogo: \(error.localizedDescription)" }
    }
    var current: ITSnippet? { snippets.first { $0.id == selected } }
    var filtered: [ITSnippet] {
        snippets.filter { item in
            (showAdvanced || item.risk != "Modifica" && item.risk != "Destructivo") &&
            (search.isEmpty || (item.title + " " + item.category + " " + item.detail).localizedCaseInsensitiveContains(search))
        }
    }
    var prepared: String? {
        guard let item = current else { return nil }
        if item.risk == "Modifica" || item.risk == "Destructivo" {
            guard showAdvanced, acknowledged else { return nil }
        }
        let value = parameter.trimmingCharacters(in: .whitespaces)
        guard value.count <= 4096, !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else { return nil }
        func matches(_ pattern: String) -> Bool { value.range(of: pattern, options: .regularExpression) != nil }
        switch item.kind {
        case "none": break
        case "host": guard value.count <= 253, matches("^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$") else { return nil }
        case "disk": guard matches("^disk[0-9]+(s[0-9]+)*$") else { return nil }
        case "wholeDisk": guard matches("^disk[0-9]+$") else { return nil }
        case "volume": guard matches("^disk[0-9]+s[0-9]+$") else { return nil }
        case "bundle": guard matches("^[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)+$") else { return nil }
        case "file": guard value.hasPrefix("/") else { return nil }
        case "app": guard value.hasPrefix("/"), value.hasSuffix(".app") else { return nil }
        default: return nil
        }
        let result = item.command.replacingOccurrences(of: "{{target}}", with: quoteForShell(value)).replacingOccurrences(of: "{{toolkit}}", with: quoteForShell(root.path))
        guard !result.contains("{{"), !result.contains("\n"), !result.contains("\r") else { return nil }
        return result
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Snippets macOS TI").font(.title.bold())
                Spacer(); Button("Cerrar") { presentationMode.wrappedValue.dismiss() }
            }
            TextField("Buscar por herramienta, categoría o necesidad", text: $search)
            Toggle("Mostrar comandos que modifican el equipo", isOn: $showAdvanced)
            if let error = loadError { Text(error).foregroundColor(.red) }
            HSplitView {
                List(selection: $selected) {
                    ForEach(filtered) { item in
                        VStack(alignment: .leading) {
                            Text(item.title)
                            Text(item.category + " · " + item.risk).font(.caption).foregroundColor(.secondary)
                        }.tag(item.id)
                    }
                }.frame(minWidth: 270, idealWidth: 310)
                VStack(alignment: .leading, spacing: 12) {
                    if let item = current {
                        Text(item.title).font(.title2.bold())
                        Text(item.detail)
                        Text("Tipo: " + item.risk + " · Se ejecutará en la sesión de Terminal donde lo suelte.").font(.caption)
                        if item.kind != "none" {
                            TextField("Parámetro requerido: " + item.kind, text: $parameter)
                            if item.kind == "file" || item.kind == "app" {
                                Button("Seleccionar archivo o aplicación") {
                                    let panel = NSOpenPanel()
                                    panel.canChooseFiles = item.kind == "file"
                                    panel.canChooseDirectories = item.kind == "app"
                                    panel.treatsFilePackagesAsDirectories = false
                                    if panel.runModal() == .OK, let url = panel.url { parameter = url.path }
                                }
                            }
                        }
                        if item.risk == "Modifica" || item.risk == "Destructivo" {
                            Toggle("Comprendo la acción y he identificado el objetivo", isOn: $acknowledged)
                        }
                        if let command = prepared {
                            Text(command).font(.system(.body, design: .monospaced)).textSelection(.enabled).padding(12).background(Color(NSColor.textBackgroundColor)).cornerRadius(8)
                            HStack {
                                Label("Arrastrar comando a Terminal", systemImage: "hand.draw")
                                    .padding(10).background(Color.accentColor.opacity(0.15)).cornerRadius(8)
                                    .onDrag { NSItemProvider(object: command as NSString) }
                                Button("Copiar") {
                                    NSPasteboard.general.clearContents()
                                    NSPasteboard.general.setString(command, forType: .string)
                                    message = "Copiado sin salto de línea. Revise el destino y pulse Enter."
                                }
                            }
                        } else { Text("Complete un parámetro válido y las confirmaciones para preparar el comando.").foregroundColor(.secondary) }
                        Button("Abrir Terminal") {
                            let terminalURL = URL(fileURLWithPath: "/System/Applications/Utilities/Terminal.app")
                            NSWorkspace.shared.open(terminalURL)
                        }
                        Text(message).font(.caption)
                        Spacer()
                        Text("Arrastre al prompt vacío, revise el texto y pulse Enter. No se añade un salto de línea ni se pulsa Enter automáticamente. Si Terminal escapa caracteres, use Copiar/Pegar y vuelva a revisar.").font(.caption)
                    } else { Text("Seleccione un snippet.") }
                }.padding().frame(minWidth: 540)
            }
            Text("Los wrappers de mantenimiento conservan validación y confirmaciones. Los comandos nativos de lectura fuera de la app no participan en su bloqueo de trabajos.").font(.caption).foregroundColor(.secondary)
        }.padding(20).frame(width: 1000, height: 680)
        .onChange(of: selected) { _ in parameter = ""; acknowledged = false; message = "" }
        .onChange(of: showAdvanced) { value in if !value { acknowledged = false } }
    }
}
