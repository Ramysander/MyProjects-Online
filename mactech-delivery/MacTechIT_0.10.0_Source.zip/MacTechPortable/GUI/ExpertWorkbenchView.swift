import SwiftUI
import AppKit
import Foundation
import UniformTypeIdentifiers

struct DependencyRow: Identifiable {
    let id: String
    let available: Bool
    let detail: String
}
struct SavedCaseRow: Identifiable {
    var id: String { url.path }
    let url: URL
    let draft: UnifiedServiceCase
}
final class ExpertWorkbench: ObservableObject {
    @Published var devices: [ConnectedDevice] = []
    @Published var inventoryDate: Date?
    @Published var dependencies: [DependencyRow] = []
    @Published var serviceCase = UnifiedServiceCase()
    @Published var message = "Escanee para observar los dispositivos conectados a esta Mac."
    @Published var savedFolder: URL?
    @Published var revisions: [SavedCaseRow] = []
    @Published var loadingLibrary = false
    @Published var libraryMessage = "Seleccione la carpeta de informes y actualice la biblioteca."
    @Published var eventNote = ""
    private var cleanCase = UnifiedServiceCase()
    init() { cleanCase = serviceCase }
    func dependenciesAt(_ root: URL) {
        let fm = FileManager.default
        dependencies = [
            DependencyRow(id: "Inventario nativo", available: fm.isExecutableFile(atPath: "/usr/sbin/system_profiler"), detail: "USB y Thunderbolt/USB4; no prueba confianza ni acceso a datos"),
            DependencyRow(id: "Helper macprobe", available: fm.isExecutableFile(atPath: root.appendingPathComponent("bin/macprobe").path), detail: "Compilado e incluido al construir la aplicación"),
            DependencyRow(id: "Motor de expedientes", available: fm.isExecutableFile(atPath: root.appendingPathComponent("bin/caseengine").path), detail: "Capturas de diagnóstico de la Mac anfitriona"),
            DependencyRow(id: "Configurator CLI", available: fm.isExecutableFile(atPath: "/usr/local/bin/cfgutil"), detail: "Opcional; instalar Automation Tools de Apple Configurator para los adaptadores cfgutil")
        ]
    }
    func scan(_ runner: Runner) {
        guard !runner.busy else { return }
        runner.busy = true; devices = []; inventoryDate = nil
        message = "Consultando inventario USB y Thunderbolt…"
        DispatchQueue.global(qos: .userInitiated).async {
            let process = Process(); let pipe = Pipe(); let errors = Pipe()
            process.executableURL = URL(fileURLWithPath: "/usr/sbin/system_profiler")
            process.arguments = ["SPUSBDataType", "SPThunderboltDataType", "-json"]
            process.standardOutput = pipe; process.standardError = errors; process.standardInput = FileHandle.nullDevice
            // Drain stderr concurrently so a full pipe cannot block the process.
            let group = DispatchGroup(); group.enter()
            DispatchQueue.global().async { _ = errors.fileHandleForReading.readDataToEndOfFile(); group.leave() }
            do {
                try process.run()
                DispatchQueue.global().asyncAfter(deadline: .now() + 30) {
                    if process.isRunning { process.terminate() }
                }
                let data = pipe.fileHandleForReading.readDataToEndOfFile()
                process.waitUntilExit(); group.wait()
                guard process.terminationStatus == 0 else { throw NSError(domain: "Inventario", code: Int(process.terminationStatus), userInfo: [NSLocalizedDescriptionKey: "system_profiler no completó la consulta"]) }
                let rows = try parseConnectedDevices(data)
                DispatchQueue.main.async {
                    self.devices = rows; self.inventoryDate = Date(); runner.busy = false
                    self.message = rows.isEmpty ? "No se encontraron dispositivos en los datos disponibles. Esto no descarta un equipo conectado." : "\(rows.count) registros observados. Confirme DFU/Recovery en las herramientas de Apple."
                }
            } catch {
                // Close write ends if launch failed to release the drain reader.
                try? errors.fileHandleForWriting.close(); try? pipe.fileHandleForWriting.close()
                DispatchQueue.main.async { runner.busy = false; self.message = "Inventario no disponible: \(error.localizedDescription)" }
            }
        }
    }
    func save(_ base: URL?) {
        do {
            guard eventNote.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw NSError(domain: "Bitácora", code: 1, userInfo: [NSLocalizedDescriptionKey: "Añada la nota pendiente a la bitácora antes de guardar"])
            }
            guard let base = base else { throw NSError(domain: "Expediente", code: 1, userInfo: [NSLocalizedDescriptionKey: "Seleccione una carpeta de informes en la ventana principal"]) }
            var draft = serviceCase; draft.updated = Date(); try draft.validate()
            if draft.outcome == "Resuelto", !draft.closureIssues.isEmpty {
                throw NSError(domain: "Cierre", code: 1, userInfo: [NSLocalizedDescriptionKey: "Complete el cierre: " + draft.closureIssues.joined(separator: "; ")])
            }
            let folder = base.appendingPathComponent("unified-cases", isDirectory: true).appendingPathComponent("case-" + draft.id, isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
            // Every save is a revision, so imported or previous evidence is not overwritten.
            let revision = "revision-" + UUID().uuidString
            // Publish the complete bundle with one directory rename. Failed exports
            // remain hidden and cannot appear as complete revisions in the library.
            let staging = folder.appendingPathComponent(".pending-" + revision, isDirectory: true)
            let destination = folder.appendingPathComponent(revision, isDirectory: true)
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let json = staging.appendingPathComponent(revision + ".json")
            let html = staging.appendingPathComponent(revision + ".html")
            let jsonData = try encoder.encode(draft)
            guard jsonData.count <= 2_000_000 else {
                throw NSError(domain: "Expediente", code: 1, userInfo: [NSLocalizedDescriptionKey: "La revisión supera el límite de importación de 2 MB"])
            }
            let htmlData = Data(("<!doctype html><meta charset='utf-8'><title>MacTech IT</title><pre>" + supportHTMLEscape(draft.reportText) + "</pre>").utf8)
            try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
            try jsonData.write(to: json, options: .atomic)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: json.path)
            try htmlData.write(to: html, options: .atomic)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: html.path)
            let manifest = staging.appendingPathComponent(revision + ".sha256")
            let checksums = checksum(jsonData) + "  " + json.lastPathComponent + "\n" + checksum(htmlData) + "  " + html.lastPathComponent + "\n"
            try Data(checksums.utf8).write(to: manifest, options: .atomic)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: manifest.path)
            try FileManager.default.moveItem(at: staging, to: destination)
            serviceCase = draft; cleanCase = draft; savedFolder = folder; message = "Revisión JSON y HTML guardada: \(folder.path)"
        } catch { message = "No se completó el guardado: \(error.localizedDescription)" }
    }
    func confirmDiscard() -> Bool {
        guard serviceCase != cleanCase || !eventNote.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return true }
        let alert = NSAlert()
        alert.messageText = "¿Ha guardado los cambios del expediente?"
        alert.informativeText = "Continuar descartará el borrador visible. Las revisiones ya guardadas se conservan."
        alert.addButton(withTitle: "Cancelar"); alert.addButton(withTitle: "Continuar")
        return alert.runModal() == .alertSecondButtonReturn
    }
    func newCase() {
        guard confirmDiscard() else { return }
        serviceCase = UnifiedServiceCase(); cleanCase = serviceCase; eventNote = ""; savedFolder = nil; message = "Nuevo borrador."
    }
    func addEvent() {
        let note = eventNote.trimmingCharacters(in: .whitespacesAndNewlines)
        let technician = serviceCase.workflow.technician.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !note.isEmpty, note.count <= 10000, !technician.isEmpty, technician.count <= 500,
              serviceCase.workflow.events.count < 500 else {
            message = "Indique técnico y nota (máximo 10.000 caracteres y 500 entradas)."; return
        }
        serviceCase.workflow.events.append(ServiceEvent(technician: technician, note: note))
        eventNote = ""; message = "Entrada añadida al borrador; guarde una revisión para conservarla."
    }
    private func readCase(_ url: URL) throws -> UnifiedServiceCase {
        let values = try url.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true,
              let size = values.fileSize, size <= 2_000_000 else {
            throw NSError(domain: "Expediente", code: 1, userInfo: [NSLocalizedDescriptionKey: "Seleccione un archivo regular de hasta 2 MB"])
        }
        let data = try Data(contentsOf: url)
        guard data.count <= 2_000_000 else { throw NSError(domain: "Expediente demasiado grande", code: 1) }
        let manifest = url.deletingPathExtension().appendingPathExtension("sha256")
        if FileManager.default.fileExists(atPath: manifest.path) {
            let metadata = try manifest.resourceValues(forKeys: [.fileSizeKey, .isSymbolicLinkKey, .isRegularFileKey])
            guard metadata.isRegularFile == true, metadata.isSymbolicLink != true, (metadata.fileSize ?? Int.max) <= 4096 else {
                throw NSError(domain: "Integridad", code: 1, userInfo: [NSLocalizedDescriptionKey: "Manifiesto de integridad inválido"])
            }
            let lines = try String(contentsOf: manifest, encoding: .utf8).split(separator: "\n").map(String.init)
            let expected = checksum(data) + "  " + url.lastPathComponent
            guard lines.count == 2, lines[0] == expected else {
                throw NSError(domain: "Integridad", code: 2, userInfo: [NSLocalizedDescriptionKey: "El JSON no coincide con su checksum SHA-256"])
            }
        }
        let draft = try JSONDecoder().decode(UnifiedServiceCase.self, from: data)
        try draft.validate(); return draft
    }
    private func checksum(_ data: Data) -> String {
        supportSHA256(data)
    }
    func verifyRevision(_ url: URL) {
        do {
            _ = try readCase(url)
            let manifest = url.deletingPathExtension().appendingPathExtension("sha256")
            guard FileManager.default.fileExists(atPath: manifest.path) else {
                message = "JSON válido, pero sin manifiesto SHA-256. No se ha comprobado integridad."; return
            }
            let html = url.deletingPathExtension().appendingPathExtension("html")
            let values = try html.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey, .isSymbolicLinkKey])
            guard values.isRegularFile == true, values.isSymbolicLink != true, (values.fileSize ?? Int.max) <= 12_000_000 else {
                throw NSError(domain: "Integridad", code: 3, userInfo: [NSLocalizedDescriptionKey: "HTML ausente o no válido"])
            }
            let lines = try String(contentsOf: manifest, encoding: .utf8).split(separator: "\n").map(String.init)
            guard lines.count == 2, lines[1] == checksum(try Data(contentsOf: html)) + "  " + html.lastPathComponent else {
                throw NSError(domain: "Integridad", code: 4, userInfo: [NSLocalizedDescriptionKey: "El HTML no coincide con su checksum SHA-256"])
            }
            message = "JSON y HTML coinciden con el manifiesto SHA-256. No acredita autoría ni firma digital."
        } catch { message = "Verificación fallida: \(error.localizedDescription)" }
    }
    func openRevision(_ url: URL) {
        guard confirmDiscard() else { return }
        do {
            let draft = try readCase(url)
            serviceCase = draft; cleanCase = draft; eventNote = ""; savedFolder = nil
            message = "Expediente cargado. Guardar creará una nueva revisión en su carpeta de informes."
        } catch { message = "No se pudo abrir el expediente: \(error.localizedDescription)" }
    }
    func refreshLibrary(_ base: URL?) {
        guard !loadingLibrary else { return }
        guard let base = base else { libraryMessage = "Seleccione una carpeta de informes en la ventana principal."; return }
        loadingLibrary = true; revisions = []
        let folder = base.appendingPathComponent("unified-cases", isDirectory: true)
        DispatchQueue.global(qos: .userInitiated).async {
            var rows: [SavedCaseRow] = []; var rejected = 0; var examined = 0; var failures = 0
            var bytes = 0; var limited = false
            let fm = FileManager.default
            let enumerator = fm.enumerator(at: folder, includingPropertiesForKeys: [.isSymbolicLinkKey], options: [.skipsHiddenFiles], errorHandler: { _, _ in failures += 1; return true })
            while let url = enumerator?.nextObject() as? URL {
                examined += 1
                if examined > 5000 { limited = true; break }
                if (try? url.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink) == true {
                    enumerator?.skipDescendants(); continue
                }
                guard url.pathExtension.lowercased() == "json" else { continue }
                let size = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                if size > 2_000_000 { rejected += 1; continue }
                if rows.count >= 500 || bytes + size > 32_000_000 { limited = true; break }
                bytes += size
                do { rows.append(SavedCaseRow(url: url, draft: try self.readCase(url))) }
                catch { rejected += 1 }
            }
            rows.sort { $0.draft.updated > $1.draft.updated }
            let loaded = rows; let count = rejected; let partial = limited; let errors = failures; let missingFolder = enumerator == nil
            DispatchQueue.main.async {
                self.revisions = loaded; self.loadingLibrary = false
                self.libraryMessage = "\(loaded.count) revisiones · \(count) archivos rechazados · \(errors) errores de lectura. " + (partial ? "Listado parcial: límite de 500 revisiones, 32 MB o 5.000 entradas alcanzado." : "") + (missingFolder ? "Carpeta ausente o no accesible." : "")
            }
        }
    }
    func load() {
        let panel = NSOpenPanel(); panel.allowedContentTypes = [.json]; panel.allowsMultipleSelection = false; panel.canChooseDirectories = false
        guard panel.runModal() == .OK, let url = panel.url else { return }
        openRevision(url)
    }
    func printReport() {
        guard eventNote.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            message = "Añada la nota pendiente a la bitácora antes de imprimir."; return
        }
        do { try serviceCase.validate() }
        catch { message = "No se puede imprimir: \(error.localizedDescription)"; return }
        let text = NSTextView(frame: NSRect(x: 0, y: 0, width: 500, height: 700))
        text.string = serviceCase.reportText; text.font = NSFont.systemFont(ofSize: 11)
        if let container = text.textContainer, let layout = text.layoutManager {
            container.widthTracksTextView = false
            container.containerSize = NSSize(width: 480, height: CGFloat.greatestFiniteMagnitude)
            layout.ensureLayout(for: container)
            text.setFrameSize(NSSize(width: 500, height: max(700, layout.usedRect(for: container).height + 40)))
        }
        let operation = NSPrintOperation(view: text)
        operation.showsPrintPanel = true; operation.showsProgressPanel = true
        operation.run()
    }
    func exportCSV(_ rows: [SavedCaseRow]) {
        guard !rows.isEmpty else { message = "No hay revisiones filtradas para exportar."; return }
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.commaSeparatedText]; panel.nameFieldStringValue = "MacTech-revisiones.csv"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        let formatter = ISO8601DateFormatter()
        var table = [["Expediente", "Ticket", "Equipo", "Plataforma", "Técnico", "Prioridad", "Resultado", "Actualizado", "Fecha objetivo", "Revisión"]]
        for row in rows {
            let draft = row.draft
            table.append([draft.id, draft.workflow.ticket, draft.asset, draft.platform, draft.workflow.technician,
                          draft.workflow.priority, draft.outcome, formatter.string(from: draft.updated),
                          draft.workflow.due.map { formatter.string(from: $0) } ?? "", row.url.lastPathComponent])
        }
        let csv = table.map { $0.map(supportCSVField).joined(separator: ",") }.joined(separator: "\r\n") + "\r\n"
        do {
            try Data(csv.utf8).write(to: url, options: .atomic)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
            message = "CSV exportado: \(rows.count) revisiones filtradas. Contiene datos del servicio; protéjalo."
        } catch { message = "No se completó la exportación CSV: \(error.localizedDescription)" }
    }
}
struct ExpertWorkbenchView: View {
    @ObservedObject var runner: Runner
    @StateObject private var model = ExpertWorkbench()
    @State private var search = ""
    @State private var outcomeFilter = "Todos"
    @Environment(\.presentationMode) private var presentationMode
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Centro TI experto").font(.title2).bold()
                Spacer()
                Button("Cerrar") { if model.confirmDiscard() { presentationMode.wrappedValue.dismiss() } }.disabled(runner.busy)
            }
            TabView {
                inventory.tabItem { Text("Dispositivos") }
                dependencies.tabItem { Text("Dependencias") }
                caseEditor.tabItem { Text("Expediente") }
                workflow.tabItem { Text("Seguimiento") }
                library.tabItem { Text("Biblioteca") }
            }
            Text(model.message).font(.caption).textSelection(.enabled)
        }.padding().frame(minWidth: 840, minHeight: 640)
            .onAppear { model.dependenciesAt(runner.root) }
    }
    private var inventory: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Button(runner.busy ? "Consultando…" : "Escanear conexiones") { model.scan(runner) }.disabled(runner.busy)
                Button("Añadir inventario al expediente") {
                    model.serviceCase.devices = model.devices
                    model.serviceCase.inventoryDate = model.inventoryDate
                    model.message = "Inventario adjunto; indique manualmente qué equipo corresponde al expediente."
                }.disabled(model.inventoryDate == nil || runner.busy)
            }
            Text("Datos de la Mac técnica. DFU no permite leer archivos; un registro USB no confirma desbloqueo, confianza o salud.").font(.caption)
            List(model.devices) { row in
                VStack(alignment: .leading) {
                    Text(row.name).bold()
                    Text("\(row.transport) · \(row.state)")
                    Text("Serie: \(row.serial) · Ubicación: \(row.location)").font(.caption)
                }.textSelection(.enabled)
            }
        }.padding()
    }
    private var dependencies: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button("Comprobar de nuevo") { model.dependenciesAt(runner.root) }
            Text("Comprobación de presencia y permisos de ejecución. No valida versiones, conectividad ni compatibilidad de Restore/Revive.").font(.caption)
            List(model.dependencies) { row in
                VStack(alignment: .leading) {
                    Text("\(row.available ? "Disponible" : "Ausente") — \(row.id)").bold()
                    Text(row.detail).font(.caption)
                }
            }
        }.padding()
    }
    private var workflow: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                workflowDetails
                closureChecklist
                Divider()
                eventLog
            }.padding()
        }
    }
    @ViewBuilder
    private var workflowDetails: some View {
        HStack {
            TextField("Ticket / referencia", text: $model.serviceCase.workflow.ticket)
            TextField("Técnico responsable", text: $model.serviceCase.workflow.technician)
            Picker("Prioridad", selection: $model.serviceCase.workflow.priority) {
                ForEach(["Baja", "Normal", "Alta", "Crítica"], id: \.self) { Text($0).tag($0) }
            }
        }
        Toggle("Definir fecha objetivo", isOn: Binding(
            get: { model.serviceCase.workflow.due != nil },
            set: { model.serviceCase.workflow.due = $0 ? Date() : nil }
        ))
        if model.serviceCase.workflow.due != nil {
            DatePicker("Fecha objetivo", selection: Binding(
                get: { model.serviceCase.workflow.due ?? Date() },
                set: { model.serviceCase.workflow.due = $0 }
            ))
        }
    }
    @ViewBuilder
    private var closureChecklist: some View {
        Text("Checklist de cierre").font(.headline)
        Text("Declaraciones del técnico; no ejecutan ni certifican operaciones. Si el respaldo no aplica, explique el motivo en la bitácora.").font(.caption)
        Toggle("Servicio autorizado", isOn: $model.serviceCase.workflow.authorizationConfirmed)
        Toggle("Respaldo revisado / no aplica documentado", isOn: $model.serviceCase.workflow.backupReviewed)
        Toggle("Verificación final realizada", isOn: $model.serviceCase.workflow.finalVerification)
        Toggle("Entrega o resultado comunicado", isOn: $model.serviceCase.workflow.handoffConfirmed)
        if model.serviceCase.closureIssues.isEmpty {
            Text("Documentación de cierre completa. Puede guardar el resultado Resuelto.").foregroundColor(.green)
        } else {
            Text("Pendiente para guardar como Resuelto: " + model.serviceCase.closureIssues.joined(separator: "; ")).font(.caption)
        }
    }
    @ViewBuilder
    private var eventLog: some View {
        Text("Bitácora de intervenciones").font(.headline)
        Text("Entradas manuales con fecha y técnico. Las revisiones conservan el historial; el JSON es editable y no constituye una auditoría inmutable.").font(.caption)
        TextEditor(text: $model.eventNote).frame(height: 80).border(Color.secondary.opacity(0.3))
        HStack {
            Button("Añadir entrada") { model.addEvent() }
            Button("Guardar revisión") { model.save(runner.reportFolder) }
        }
        ForEach(model.serviceCase.workflow.events.reversed()) { event in
            VStack(alignment: .leading) {
                Text("\(event.date.formatted()) · \(event.technician)").font(.caption).bold()
                Text(event.note).textSelection(.enabled)
            }.padding(.vertical, 4)
        }
    }
    private var filteredRevisions: [SavedCaseRow] {
        model.revisions.filter { row in
            let draft = row.draft
            let matchesOutcome = outcomeFilter == "Todos" || draft.outcome == outcomeFilter
            let searchable = [draft.id, draft.asset, draft.symptom, draft.platform, draft.workflow.ticket, draft.workflow.technician].joined(separator: " ")
            return matchesOutcome && (search.isEmpty || searchable.localizedStandardContains(search))
        }
    }
    private var library: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                TextField("Buscar ticket, equipo, técnico o síntoma", text: $search)
                Picker("Resultado", selection: $outcomeFilter) {
                    ForEach(["Todos", "Pendiente", "Resuelto", "Parcial", "Escalado"], id: \.self) { Text($0).tag($0) }
                }
                Button(model.loadingLibrary ? "Leyendo…" : "Actualizar") { model.refreshLibrary(runner.reportFolder) }.disabled(model.loadingLibrary)
            }
            Text(model.libraryMessage).font(.caption)
            HStack {
                Text("Mostrando \(filteredRevisions.count) revisiones de \(Set(filteredRevisions.map { $0.draft.id }).count) expedientes.").font(.caption)
                Spacer()
                Button("Exportar CSV filtrado") { model.exportCSV(filteredRevisions) }.disabled(filteredRevisions.isEmpty || model.loadingLibrary)
            }
            Text("Revisiones locales, ordenadas por fecha declarada de actualización. Una misma incidencia puede tener varias revisiones. Actualice después de guardar.").font(.caption)
            List(filteredRevisions) { row in
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(row.draft.asset.isEmpty ? row.draft.id : row.draft.asset).bold()
                        Text("\(row.draft.platform) · \(row.draft.outcome) · \(row.draft.workflow.priority) · \(row.draft.updated.formatted())").font(.caption)
                        Text("Ticket: \(row.draft.workflow.ticket) · Técnico: \(row.draft.workflow.technician)").font(.caption)
                        if let due = row.draft.workflow.due, due < Date(), row.draft.outcome != "Resuelto" {
                            Text("Fecha objetivo vencida").font(.caption).foregroundColor(.orange)
                        }
                        Text(row.url.lastPathComponent).font(.caption2)
                    }
                    Spacer()
                    Button("Abrir revisión") { model.openRevision(row.url) }
                    Button("Verificar integridad") { model.verifyRevision(row.url) }
                }
            }
        }.padding()
    }
    private var caseEditor: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Picker("Plataforma", selection: $model.serviceCase.platform) {
                    ForEach(["Mac", "iPhone", "iPad"], id: \.self) { Text($0).tag($0) }
                }
                Picker("Resultado", selection: $model.serviceCase.outcome) {
                    ForEach(["Pendiente", "Resuelto", "Parcial", "Escalado"], id: \.self) { Text($0).tag($0) }
                }
            }
            TextField("Identificación del equipo, declarada por el técnico", text: $model.serviceCase.asset)
            TextField("Síntoma / motivo de servicio", text: $model.serviceCase.symptom)
            HStack(alignment: .top) {
                note("Antes", text: $model.serviceCase.before)
                note("Intervención realizada", text: $model.serviceCase.action)
                note("Después", text: $model.serviceCase.after)
            }
            Text("Notas del técnico; no son capturas automáticas. No incluya contraseñas ni claves de recuperación. Inventario adjunto: \(model.serviceCase.devices.count) registros.").font(.caption)
            HStack {
                Button("Nuevo") { model.newCase() }
                Button("Abrir JSON") { model.load() }
                Button("Guardar revisión") { model.save(runner.reportFolder) }
                Button("Imprimir / PDF") { model.printReport() }
                Button("Mostrar archivos") { if let url = model.savedFolder { NSWorkspace.shared.open(url) } }.disabled(model.savedFolder == nil)
            }
        }.padding()
    }
    private func note(_ title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading) { Text(title).bold(); TextEditor(text: text).border(Color.secondary.opacity(0.3)) }
    }
}
