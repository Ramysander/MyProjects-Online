# Snippets macOS TI — 0.6

La interfaz añade el botón **Snippets TI**, con 42 comandos buscables, categoría, explicación, nivel de acción, parámetro validado, vista previa, copiar y arrastrar a Terminal.

## Uso

1. Compilar/reconstruir con Build_DMG.command en una Mac con Command Line Tools.
2. Abrir la app → Snippets TI.
3. Buscar por nombre o necesidad.
4. Completar un parámetro cuando corresponda: diskN, diskNsM, host DNS/IPv4, ruta absoluta de archivo/.app o bundle ID.
5. Abrir Terminal y usar un prompt vacío en el equipo correcto, sin un comando parcial ya escrito.
6. Arrastrar «Arrastrar comando a Terminal» al prompt, revisar el comando y pulsar Enter.

El proveedor de arrastre entrega texto plano mediante NSItemProvider; no envía teclas, no usa AppleScript para ejecutar y no añade salto de línea. No puede garantizar el comportamiento de cualquier aplicación/shell receptora. Si Terminal añade escapes que alteran el comando, usar Copiar/Pegar y revisar. Apple documenta arrastre de ejecutables y recortes de texto a Terminal, y advierte sobre escapes en recortes.

## Niveles

- Lectura: consultas. Algunos comandos generan tráfico DNS/ping o muestran datos privados.
- Supervisado: consultas largas, verificación de volumen y asistentes que conservan sus diálogos.
- Modifica: caché por aplicación y reparación APFS. Se muestran sólo al habilitar avanzados y reconocer la acción.
- Destructivo: formateo de disco externo mediante el wrapper protegido. Requiere parámetros y sus confirmaciones en Terminal.

No se incorporan scripts de desbloqueo, rm recursivo indiscriminado, desactivación de SIP/Gatekeeper ni restauración DFU automática. Los snippets destructivos no incluyen eraseDisk directo: llaman erase-external.sh, que inspecciona y confirma objetivo.

## Tratamiento de parámetros

Rutas se convierten en un argumento shell entre comillas simples, escapando apóstrofes. Los tipos disk/volume/host/bundle tienen validación adicional. Se rechazan controles y saltos de línea. Las rutas sólo se validan sintácticamente en la vista; el comando verifica existencia/permisos o falla al ejecutarse. No hay eval ni sustitución de comandos de entrada del usuario. El catálogo incluido es código confiable del paquete; editarlo cambia la herramienta y debe considerarse modificación de código, no configuración inocua.

Los comandos se ejecutan en LA SESIÓN TERMINAL RECEPTORA: si está conectada por SSH, no necesariamente es el host de la app. Los wrappers referencian la ruta local de la app y no existen automáticamente en un host remoto. No arrastrar comandos locales de mantenimiento a una sesión SSH ajena.

## Compatibilidad y resultados

Baseline GUI macOS 12 de diseño; cada proveedor depende de versión/hardware/permisos. No asumir que una consulta devuelve datos en todos los modelos. SMART no disponible no es estado sano. Los comandos nativos de lectura arrastrados no participan en el lock de la herramienta; wrappers sí lo adquieren. Mantener tareas de disco/firmware separadas.

Validaciones aquí: catálogo JSON (42 entradas únicas), parámetros/plantillas, ausencia de saltos de línea, sintaxis de comandos renderizados y scripts Bash. No se compiló Swift ni se probó el arrastre real a Terminal, copiar, diálogos o comandos en macOS. No se generó una app/DMG binario. Probar parámetros con espacios/apóstrofes y Terminal zsh/bash antes de distribuir.

## Referencias

- https://support.apple.com/guide/terminal/drag-items-into-a-terminal-window-trml106/mac
- https://developer.apple.com/documentation/swiftui/view/ondrag(_:)
- https://developer.apple.com/documentation/foundation/nsitemprovider
- Ayuda y man pages del macOS de laboratorio para cada comando del catálogo.
