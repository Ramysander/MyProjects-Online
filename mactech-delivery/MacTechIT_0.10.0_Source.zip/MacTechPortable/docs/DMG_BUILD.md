# Generar la aplicación y el DMG — 0.10.0

Este ZIP contiene un constructor, NO un DMG precompilado. Se requiere una Mac con Command Line Tools y SDK compatible. El entorno que generó estas fuentes es Linux, por lo que no se ha compilado Swift ni ejecutado hdiutil.

## Construcción

1. Descomprimir la carpeta completa en una carpeta escribible de la Mac.
2. Si falta el compilador, en Terminal ejecutar `xcode-select --install` y esperar a que termine.
3. Abrir `Build_DMG.command`, o desde Terminal en la carpeta ejecutar `/bin/bash scripts/build-dmg.sh`.
4. Si falla, revisar `BUILD_DMG_LOG.txt` (cuando se usa el launcher).
5. Resultado esperado: `dist/MacTech_IT_v0.10.0.dmg`, hash SHA-256 y .app universal dentro del directorio build.

No borrar ni renombrar fuentes antes de compilar. Si ya existe el DMG, moverlo antes de otra construcción. El constructor genera directorios únicos y conserva app/staging para inspección.

## Aplicación integrada

25 herramientas accesibles desde el catálogo GUI, con descripción y salida. Diagnósticos se ejecutan fuera del hilo de interfaz. Flujos que requieren interacción administrativa utilizan Terminal. El asistente Revivir MacBook guía Finder/DFU o Recovery; no promete botones de recuperación totalmente autónoma. cfgutil continúa experimental y requiere Configurator Automation Tools en el host. No se incorpora un bypass de seguridad.

La app empaqueta scripts, launchers, documentos y sólo el helper universal, evitando copiar binarios de compilación auxiliares como recursos. Su baseline es macOS 12; Finder DFU requiere host macOS 14+. Estas compatibilidades de diseño deben probarse en los modelos/versiones concretos.

## Firma y publicación

El constructor genera firma ad hoc para el laboratorio y verifica esa firma. Una firma ad hoc no garantiza aceptación Gatekeeper en otro equipo. Para distribución externa: firmar el helper y la app con Developer ID y hardened runtime según requisitos de Apple; crear el DMG; enviarlo a notarización con notarytool usando credenciales almacenadas en Keychain; tras aceptación, staplear y verificar el ticket. No incluir credenciales en scripts. No afirmar que un artefacto esté notarizado sin verificar la respuesta de Apple.

Referencia oficial: https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution

## Verificación real pendiente

Compilación Swift arm64/x86_64; firma y apertura de app desde USB; hdiutil verify; montaje y apertura en host limpio; prueba de selección de carpeta y cada botón; lectura/escritura TCC; procedimientos destructivos únicamente en equipos desechables y autorizados. Las validaciones Linux son sólo sintaxis/plist/estructura, no ejecución macOS.
