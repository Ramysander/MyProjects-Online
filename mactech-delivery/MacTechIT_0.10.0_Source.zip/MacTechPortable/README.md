# MacTech IT 0.10.0 — Centro TI profesional (fuentes en desarrollo)

Herramienta nativa para macOS 12+ con diagnóstico, catálogo de utilidades, snippets y expedientes para Mac/iPhone/iPad.

Esta entrega contiene código fuente y constructor; no incluye una app ni un DMG compilados. Las nuevas funciones requieren validación en macOS. Lea `AGENTS.md` y `docs/PROJECT_STATUS.md` antes de modificar o verificar el proyecto.

## Centro TI
- Seguimiento por ticket, técnico, prioridad y fecha objetivo.
- Checklist de cierre y bitácora manual con técnico y fecha.
- Biblioteca de revisiones con búsqueda, filtro por resultado y aviso de fecha objetivo vencida.
- Exportación JSON/HTML por revisión, Print/PDF y CSV de los resultados filtrados.
- Checksums SHA-256 de los archivos exportados y comprobación de integridad.
- Importación de expedientes 0.9.0; inventario conservador y comprobación de dependencias.

Consulte [la guía del Centro TI](docs/EXPERT_WORKBENCH.md) para el uso y las limitaciones. El historial es editable, no una auditoría inmutable. Los checksums no autentican al autor; los expedientes no están cifrados.

## Verificar y compilar

En cualquier entorno con Python 3 y Bash: `python3 tools/check_source.py` (sólo inspección estática).

En una Mac con Apple Command Line Tools, desde la raíz: `/bin/bash Build_DMG.command`. Compila, ejecuta los selftests sintéticos, verifica firmas y arquitecturas y genera el DMG y su SHA-256. No ejecute flujos operativos ni pruebas sobre dispositivos durante la verificación.

La firma ad hoc es para uso local; la distribución pública requiere Developer ID y notarización.
